import * as _angular_forms from '@angular/forms';
import { ValidatorFn, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import * as _angular_core from '@angular/core';
import { OnInit, QueryList, EventEmitter, OnChanges, SimpleChanges, AfterViewInit, ElementRef, PipeTransform, AfterContentInit, TemplateRef } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import * as _angular_platform_browser from '@angular/platform-browser';
import { DomSanitizer } from '@angular/platform-browser';
import * as rxjs from 'rxjs';
import { Subject, Observable } from 'rxjs';
import { ComponentType } from '@angular/cdk/portal';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe, KeyValue } from '@angular/common';

declare enum DynamicComponentsTypes {
    INPUT = "input",
    SELECT = "select",
    AUTO_COMPLETE = "autoComplete",
    DATE = "date",
    FILE = "file",
    CHECKBOX = "checkbox"
}
declare enum subInputType {
    TEXT = "text",
    EMAIL = "email",
    PASSWORD = "password",
    NUMBER = "number",
    DATE = "date",
    FILE = "file",
    TEXT_AREA = "textArea"
}

type FormField = {
    alias: string;
    name: string;
    dynamicComponent?: DynamicComponentsTypes;
    updateOn?: 'blur' | 'change';
    subInputType?: subInputType;
    options?: Option[];
    validators: ValidatorFormField;
    errorMsg?: string;
    value?: any;
    disabled?: boolean;
    hidden?: boolean;
};
type ValidatorFormField = {
    [key: string]: {
        validatorFn: ValidatorFn;
        errorMsg: string;
        isAsync?: boolean;
        hint?: {
            maximumLength?: number;
        };
    };
};
type Option = {
    alias: string;
    value: string;
};
type DateFormField = FormField & {
    minDate?: Date;
};
type CheckboxField = FormField & {
    checked: boolean;
};

declare class GenericFormComponent {
    private formBuilder;
    formFields: _angular_core.InputSignal<FormField[]>;
    formValidators: _angular_core.InputSignal<ValidatorFormField | undefined>;
    title: _angular_core.InputSignal<string | undefined>;
    isLoading: _angular_core.InputSignal<boolean | null | undefined>;
    additionalTemplate: _angular_core.InputSignal<any>;
    isSubmitted: _angular_core.WritableSignal<boolean>;
    shouldCheckForErrors: _angular_core.WritableSignal<boolean>;
    form: _angular_core.Signal<FormGroup<{
        [x: string]: _angular_forms.FormControl<unknown>;
    }>>;
    formSubmit: _angular_core.OutputEmitterRef<FormGroup<any>>;
    requiredMap: any;
    constructor(formBuilder: FormBuilder);
    onSubmit(): void;
    private createFormValidatorsArray;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GenericFormComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GenericFormComponent, "app-generic-form", never, { "formFields": { "alias": "formFields"; "required": true; "isSignal": true; }; "formValidators": { "alias": "formValidators"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "isLoading": { "alias": "isLoading"; "required": false; "isSignal": true; }; "additionalTemplate": { "alias": "additionalTemplate"; "required": false; "isSignal": true; }; }, { "formSubmit": "formSubmit"; }, never, never, true, never>;
}

declare class ValidatorsService {
    constructor();
    deleteError(control: any, error: string): void;
    setError(control: any, error: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ValidatorsService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ValidatorsService>;
}

declare const genericValidators: {
    positiveNumber: {
        min: {
            validatorFn: _angular_forms.ValidatorFn;
            errorMsg: string;
        };
    };
    required: {
        required: {
            validatorFn: typeof Validators.required;
            errorMsg: string;
        };
    };
};

type FileFormField = FormField & {
    fileSize: number;
    allowedTypes: string[];
};

type DialogContent = {
    width?: number;
    height?: number;
    description?: string;
    confirmBtn?: string;
    title?: string;
    extraData?: any;
    errorMessage?: string;
    formData?: {
        form: FormGroup;
        field: FileFormField;
    };
};

declare enum DialogResponse {
    CONFIRM = "confirm",
    SEARCH = "search",
    CANCEL = "cancel"
}

declare class ConfirmModalComponent {
    data: DialogContent;
    constructor(data: DialogContent);
    get confirmResponse(): DialogResponse;
    get cancelResponse(): DialogResponse;
    get submitTitle(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ConfirmModalComponent, "app-confirm-modal", never, {}, {}, never, never, true, never>;
}

declare class SearchModalComponent {
    data: DialogContent;
    searchOptions: _angular_core.WritableSignal<string[]>;
    selectControl: _angular_core.Signal<FormControl<string | null>>;
    constructor(data: DialogContent);
    get errorMessage(): string;
    get isSearchOptionsExist(): boolean;
    get cancelResponse(): DialogResponse;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SearchModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SearchModalComponent, "app-search-modal", never, {}, {}, never, never, true, never>;
}

interface MediaPreviewDataModel extends DialogContent {
    media: {
        type: 'image' | 'video';
        url: string;
    };
}
declare class MediaPreviewModalComponent {
    readonly data: MediaPreviewDataModel;
    openFullscreen(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MediaPreviewModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MediaPreviewModalComponent, "lib-media-preview-modal", never, {}, {}, never, never, true, never>;
}

declare class inputModal {
    data: DialogContent;
    inputControl: _angular_core.WritableSignal<FormControl<any>>;
    constructor(data: DialogContent);
    get confirmTitle(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<inputModal, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<inputModal, "app-input-modal", never, {}, {}, never, never, true, never>;
}

type NavigationItem = {
    alias: string;
    link: string;
    show: boolean;
    type: NavigationItemType;
    modalData?: {
        extraData?: any;
        title?: string;
        errorMessage?: string;
    };
};
type LandingPageNavigationItem = {
    alias: string;
    link: string;
    hide?: boolean;
    disabled?: boolean;
    tooltip?: string;
    type: NavigationItemType;
    modalData?: {
        extraData?: any;
        title?: string;
        errorMessage?: string;
    };
};
declare enum NavigationItemType {
    LINK = "link",
    MODAL = "modal"
}

type MenuItem = {
    action: MenuAction;
    alias: string;
    actionType?: MenuActionType;
    show: boolean;
    link?: string;
};
declare enum MenuActionType {
    LINK = "link",
    MODAL = "modal",
    DOWNLOAD = "download",
    GENERATE_PDF = "generatePdf"
}
declare enum MenuAction {
    NAVIGATE = "navigate",
    TRANSFER = "transfer",
    CANCEL_TRANSFER = "cancelTransfer",
    DELETE = "delete",
    DOWNLOAD = "download",
    GENERATE_PDF = "generatePdf"
}

declare class NavigationBarComponent {
    private sanitizer;
    navItems: _angular_core.InputSignal<MenuItem[]>;
    showMenuInSmallScreens: _angular_core.InputSignal<boolean>;
    title: _angular_core.InputSignal<string | undefined>;
    logo: _angular_core.InputSignal<string | undefined>;
    redirectBrandLink: _angular_core.InputSignal<string | undefined>;
    sanitizedLogo: _angular_core.Signal<_angular_platform_browser.SafeHtml>;
    showLogo: _angular_core.Signal<boolean>;
    get menuIcon(): string;
    constructor(sanitizer: DomSanitizer);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationBarComponent, "app-navigation-bar", never, { "navItems": { "alias": "navItems"; "required": true; "isSignal": true; }; "showMenuInSmallScreens": { "alias": "showMenuInSmallScreens"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "logo": { "alias": "logo"; "required": false; "isSignal": true; }; "redirectBrandLink": { "alias": "redirectBrandLink"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type Popup = {
    message: string;
    type?: PopupType;
};
declare enum PopupType {
    SUCCESS = "success",
    ALERT = "alert",
    WARNING = "warning"
}
type PopupsStyle = {
    top?: string;
    bottom?: string;
    right?: string;
    left?: string;
};

declare class PopupsService {
    popupSubject: Subject<Popup>;
    openPopup(data: Popup): void;
    addErrorPopOut(msg: string): void;
    addSuccessPopOut(msg: string): void;
    addWarningPopOut(msg: string): void;
    getPopup(): rxjs.Observable<Popup>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PopupsService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PopupsService>;
}

declare class PopupsComponent {
    customStyle: _angular_core.InputSignal<PopupsStyle | undefined>;
    popups: _angular_core.WritableSignal<Popup[]>;
    popupService: PopupsService;
    getStyleComputed: _angular_core.Signal<PopupsStyle | undefined>;
    constructor();
    ngOnInit(): void;
    private subscribePopups;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PopupsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PopupsComponent, "lib-popups", never, { "customStyle": { "alias": "customStyle"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type DownloadEvent = {
    fileId: string;
    entity: string;
};

declare class AttachmentsService {
    private _isDownloadClicked;
    private isDownloadClicked;
    emitDownloadEvent(event: DownloadEvent): void;
    getIsDownloadClicked(): Observable<DownloadEvent>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AttachmentsService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AttachmentsService>;
}

declare class AttachmentsModalComponent implements OnInit {
    data: DialogContent;
    private domSanitizer;
    private popupsService;
    private attachmentsService;
    private maxFileSize;
    private allowedTypes;
    private shouldRemoveExistingFileOnSave;
    field: FileFormField;
    form: _angular_core.WritableSignal<FormGroup<any>>;
    existingFileName: _angular_core.WritableSignal<string>;
    isPrevFileExist: _angular_core.WritableSignal<boolean>;
    chosenFileDetails: _angular_core.WritableSignal<File | null>;
    shouldShowRemoveButton: _angular_core.Signal<string | true | File>;
    inputFile: QueryList<any>;
    constructor(data: DialogContent, domSanitizer: DomSanitizer, popupsService: PopupsService, attachmentsService: AttachmentsService);
    ngOnInit(): void;
    onRemoveClicked(): void;
    onFileSelected(event: any): void;
    private isAllowed;
    confirmFile(): void;
    onPreviewClicked(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AttachmentsModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AttachmentsModalComponent, "lib-attachments-modal", never, {}, {}, never, never, true, never>;
}

declare class ModalsService {
    private dialog;
    constructor(dialog: MatDialog);
    openConfirmModal(dialogContent: DialogContent): MatDialogRef<ConfirmModalComponent>;
    openSearchModal(page: NavigationItem, dialogContent: DialogContent): MatDialogRef<SearchModalComponent>;
    openInputModal(dialogContent: DialogContent): MatDialogRef<inputModal, any>;
    openAttachmentsModal(dialogContent: DialogContent): MatDialogRef<AttachmentsModalComponent, any>;
    openComponentModal(component: ComponentType<unknown>, dialogContent: DialogContent): MatDialogRef<unknown, any>;
    openMediaPreviewModal(dialogContent: DialogContent): MatDialogRef<MediaPreviewModalComponent, any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalsService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ModalsService>;
}

declare const defaultModalProperties: {
    width: string;
    height: string;
    description: string;
    confirmBtn: string;
    title: string;
};
declare const modalHeights: {
    small: number;
    medium: number;
};

declare const uploadFileDefaultValues: {
    fileSize: number;
    allowedTypes: string[];
};

declare class LandingPageService {
    private modalsService;
    private router;
    constructor(modalsService: ModalsService, router: Router);
    openNavigationModal(page: NavigationItem, dialogContent: DialogContent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LandingPageService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<LandingPageService>;
}

declare class LandingPageComponent {
    pages: _angular_core.InputSignal<LandingPageNavigationItem[]>;
    openModalClicked: _angular_core.OutputEmitterRef<LandingPageNavigationItem>;
    get navigationItemType(): typeof NavigationItemType;
    constructor();
    openModal(page: LandingPageNavigationItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LandingPageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LandingPageComponent, "app-landing-page", never, { "pages": { "alias": "pages"; "required": true; "isSignal": true; }; }, { "openModalClicked": "openModalClicked"; }, never, never, true, never>;
}

declare enum GridActionType {
    'EDIT' = "edit",
    'DELETE' = "delete",
    'NAVIGATE' = "navigate",
    'DOWNLOAD' = "download"
}
type GridAction = {
    action: GridActionType;
    alias: string;
    tooltip?: string;
    extra?: any;
};

type GridColumn = {
    alias: string;
    property: string;
    isFilterDisabled?: boolean;
    isSortDisabled?: boolean;
};

type GridEvent = GridAction & {
    data: any;
};

type GridRowValue = {
    value: any;
    isHidden?: boolean;
    icon?: string;
};
type GridRow = {
    [key: string]: GridRowValue;
};

declare type SortDirection = 'asc' | 'desc' | '';
declare const compare: (val1: string | number | Date, val2: string | number | Date) => 0 | 1 | -1;
declare class SortableHeaderDirective {
    sortable: _angular_core.InputSignal<string>;
    direction: _angular_core.WritableSignal<SortDirection>;
    isSortable: _angular_core.InputSignal<boolean>;
    sort: EventEmitter<SortEvent>;
    rotate(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SortableHeaderDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SortableHeaderDirective, "[appSortableHeader]", never, { "sortable": { "alias": "sortable"; "required": true; "isSignal": true; }; "isSortable": { "alias": "isSortable"; "required": false; "isSignal": true; }; }, { "sort": "sort"; }, never, never, true, never>;
}

type SortEvent = {
    column: string;
    direction: SortDirection;
};

type PageEvent = {
    pageNumber: number;
    itemsPerPage: number;
};

declare class PaginatorComponent {
    currentPage: _angular_core.InputSignal<number>;
    totalItems: _angular_core.InputSignal<number>;
    itemsPerPage: _angular_core.WritableSignal<number>;
    sizeOptions: number[];
    pageNumbers: number[];
    visiblePagesRange: number;
    startVisiblePage: _angular_core.Signal<number>;
    endVisiblePage: _angular_core.Signal<number>;
    getVisiblePageNumbers: _angular_core.Signal<number[]>;
    lastPageNumber: _angular_core.Signal<number>;
    currentPageIndex: _angular_core.WritableSignal<number>;
    pageEvent: _angular_core.OutputEmitterRef<PageEvent>;
    get firstPageNumber(): number;
    constructor();
    onPageChanged(index: number): void;
    onPageSizeChanged(itemsPerPage: any): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PaginatorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PaginatorComponent, "app-paginator", never, { "currentPage": { "alias": "currentPage"; "required": true; "isSignal": true; }; "totalItems": { "alias": "totalItems"; "required": true; "isSignal": true; }; }, { "pageEvent": "pageEvent"; }, never, never, true, never>;
}

type GridFilters = {
    [key: string]: string;
};

declare class GridComponent implements OnInit, OnChanges {
    private datePipe;
    columns: _angular_core.InputSignal<GridColumn[]>;
    dataRows: _angular_core.InputSignal<GridRow[]>;
    actions: _angular_core.InputSignal<GridAction[]>;
    config: _angular_core.InputSignal<any>;
    isLoading: _angular_core.InputSignal<boolean | null | undefined>;
    title: _angular_core.InputSignal<string | undefined>;
    showPaginator: _angular_core.InputSignal<boolean>;
    changeToListInSmallScreens: _angular_core.InputSignal<boolean>;
    currentPageIndex: _angular_core.WritableSignal<number>;
    pageSize: _angular_core.WritableSignal<number>;
    lastSort: _angular_core.WritableSignal<SortEvent>;
    filters: _angular_core.WritableSignal<GridFilters>;
    filteredData: _angular_core.WritableSignal<GridRow[]>;
    slicedData: _angular_core.Signal<GridRow[]>;
    refineColumns: _angular_core.Signal<GridColumn[]>;
    numberOfColumns: _angular_core.Signal<any>;
    actionClicked: _angular_core.OutputEmitterRef<GridEvent>;
    sortClicked: _angular_core.OutputEmitterRef<GridEvent>;
    headers: QueryList<SortableHeaderDirective>;
    constructor(datePipe: DatePipe);
    ngOnInit(): void;
    isDisabledActionButton(disabledActions: any, action: any): boolean;
    originalOrder: (a: KeyValue<any, any>, b: KeyValue<any, any>) => number;
    onActionClicked(action: GridAction, data: any): void;
    sortColumn(event: SortEvent): void;
    ngOnChanges(changes: SimpleChanges): void;
    onFilterChange(event: any, column: GridColumn): void;
    onPageChanged(pageEvent: PageEvent): void;
    private filterData;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GridComponent, "app-grid", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "dataRows": { "alias": "dataRows"; "required": true; "isSignal": true; }; "actions": { "alias": "actions"; "required": true; "isSignal": true; }; "config": { "alias": "config"; "required": false; "isSignal": true; }; "isLoading": { "alias": "isLoading"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "showPaginator": { "alias": "showPaginator"; "required": false; "isSignal": true; }; "changeToListInSmallScreens": { "alias": "changeToListInSmallScreens"; "required": false; "isSignal": true; }; }, { "actionClicked": "actionClicked"; "sortClicked": "sortClicked"; }, never, never, true, never>;
}

declare class GridRowValueDirective implements AfterViewInit {
    private el;
    private datePipe;
    appGridRow: _angular_core.InputSignal<any>;
    config: _angular_core.InputSignal<any>;
    constructor(el: ElementRef, datePipe: DatePipe);
    ngAfterViewInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridRowValueDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<GridRowValueDirective, "[appGridRow]", never, { "appGridRow": { "alias": "appGridRow"; "required": false; "isSignal": true; }; "config": { "alias": "config"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FilterDataRowsPipe implements PipeTransform {
    private datePipe;
    constructor(datePipe: DatePipe);
    transform(currentGridRows: GridRow[], filters: any, config: any, ...args: unknown[]): any[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FilterDataRowsPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<FilterDataRowsPipe, "filterDataRows", true>;
}

declare class DeleteHiddenColumnsPipe implements PipeTransform {
    transform(currentGridRow: GridRow, ...args: unknown[]): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DeleteHiddenColumnsPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<DeleteHiddenColumnsPipe, "deleteHiddenColumns", true>;
}

type Notification = {
    title: string;
    description: string;
    alias: string;
    type: NotificationType;
    actionType: NotificationActionType;
    link?: string;
    _id?: string;
};
declare enum NotificationActionType {
    LINK = "link",// directly go to link
    NAVIGATE = "navigateTo",// go through the perform notification action
    INFO = "info"
}
declare enum NotificationType {
    CAR_SWAP = "carSwap",
    INFO = "info"
}
declare const notificationBasedColor: {
    carSwap: string;
    info: string;
};

type NotificationBarItems = Record<string, Notification>;
type NotificationBarItemClicked = {
    key: string;
    value: Notification;
};

declare class NotificationComponent {
    protected readonly notificationBasedColor: {
        carSwap: string;
        info: string;
    };
    notification: _angular_core.InputSignal<Notification>;
    notificationId: _angular_core.InputSignal<string>;
    newNotificationClicked: _angular_core.OutputEmitterRef<NotificationBarItemClicked>;
    onNotificationClicked(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NotificationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NotificationComponent, "app-notification", never, { "notification": { "alias": "notification"; "required": true; "isSignal": true; }; "notificationId": { "alias": "notificationId"; "required": true; "isSignal": true; }; }, { "newNotificationClicked": "newNotificationClicked"; }, never, never, true, never>;
}

declare class NotificationsBarComponent {
    icon: _angular_core.InputSignal<string>;
    items: _angular_core.InputSignal<NotificationBarItems>;
    notify: _angular_core.InputSignal<boolean | undefined>;
    isItemsEmpty: _angular_core.Signal<boolean>;
    notificationClicked: _angular_core.OutputEmitterRef<NotificationBarItemClicked>;
    onNotificationActionClicked(item: NotificationBarItemClicked): void;
    protected readonly notificationBasedColor: {
        carSwap: string;
        info: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NotificationsBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NotificationsBarComponent, "app-notifications-bar", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "items": { "alias": "items"; "required": true; "isSignal": true; }; "notify": { "alias": "notify"; "required": false; "isSignal": true; }; }, { "notificationClicked": "notificationClicked"; }, never, never, true, never>;
}

declare class MenuComponent {
    menuTrigger: ElementRef<HTMLElement>;
    icon: _angular_core.InputSignal<string>;
    items: _angular_core.InputSignal<MenuItem[]>;
    menuOpen: _angular_core.WritableSignal<boolean>;
    menuPosition: _angular_core.WritableSignal<{
        top: number;
        left: number;
    }>;
    menuActionClicked: _angular_core.OutputEmitterRef<MenuItem>;
    onMenuActionClicked(item: MenuItem): void;
    toggleMenu(): void;
    closeMenu(): void;
    setMenuPosition(): void;
    onDocumentClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuComponent, "app-menu", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "items": { "alias": "items"; "required": true; "isSignal": true; }; }, { "menuActionClicked": "menuActionClicked"; }, never, never, true, never>;
}

type AuthenticationButton = {
    alias: string;
    link: string;
};

declare class AuthenticationButtonsComponent {
    authenticationButtons: _angular_core.InputSignal<AuthenticationButton[]>;
    isAuthenticated: _angular_core.InputSignal<boolean>;
    userMenuButtons: _angular_core.InputSignal<MenuItem[]>;
    userName: _angular_core.InputSignal<string | undefined>;
    menuItemClicked: _angular_core.OutputEmitterRef<MenuItem>;
    get userIcon(): string;
    constructor();
    performAuthAction(item: MenuItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AuthenticationButtonsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AuthenticationButtonsComponent, "app-authentication-buttons", never, { "authenticationButtons": { "alias": "authenticationButtons"; "required": true; "isSignal": true; }; "isAuthenticated": { "alias": "isAuthenticated"; "required": true; "isSignal": true; }; "userMenuButtons": { "alias": "userMenuButtons"; "required": true; "isSignal": true; }; "userName": { "alias": "userName"; "required": false; "isSignal": true; }; }, { "menuItemClicked": "menuItemClicked"; }, never, never, true, never>;
}

declare class IconComponent {
    private domSanitizer;
    icon: _angular_core.InputSignal<string>;
    sanitizedIcon: _angular_core.Signal<_angular_platform_browser.SafeHtml>;
    constructor(domSanitizer: DomSanitizer);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconComponent, "app-icon", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const userIcon = "<svg width=\"20px\" height=\"20px\" viewBox=\"0 0 20 20\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" fill=\"#000000\"><g id=\"SVGRepo_bgCarrier\" stroke-width=\"0\"></g><g id=\"SVGRepo_tracerCarrier\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></g><g id=\"SVGRepo_iconCarrier\"> <title>profile_round [#1342]</title> <desc>Created with Sketch.</desc> <defs> </defs> <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\"> <g id=\"Dribbble-Light-Preview\" transform=\"translate(-140.000000, -2159.000000)\" fill=\"#000000\"> <g id=\"icons\" transform=\"translate(56.000000, 160.000000)\"> <path d=\"M100.562548,2016.99998 L87.4381713,2016.99998 C86.7317804,2016.99998 86.2101535,2016.30298 86.4765813,2015.66198 C87.7127655,2012.69798 90.6169306,2010.99998 93.9998492,2010.99998 C97.3837885,2010.99998 100.287954,2012.69798 101.524138,2015.66198 C101.790566,2016.30298 101.268939,2016.99998 100.562548,2016.99998 M89.9166645,2004.99998 C89.9166645,2002.79398 91.7489936,2000.99998 93.9998492,2000.99998 C96.2517256,2000.99998 98.0830339,2002.79398 98.0830339,2004.99998 C98.0830339,2007.20598 96.2517256,2008.99998 93.9998492,2008.99998 C91.7489936,2008.99998 89.9166645,2007.20598 89.9166645,2004.99998 M103.955674,2016.63598 C103.213556,2013.27698 100.892265,2010.79798 97.837022,2009.67298 C99.4560048,2008.39598 100.400241,2006.33098 100.053171,2004.06998 C99.6509769,2001.44698 97.4235996,1999.34798 94.7348224,1999.04198 C91.0232075,1998.61898 87.8750721,2001.44898 87.8750721,2004.99998 C87.8750721,2006.88998 88.7692896,2008.57398 90.1636971,2009.67298 C87.1074334,2010.79798 84.7871636,2013.27698 84.044024,2016.63598 C83.7745338,2017.85698 84.7789973,2018.99998 86.0539717,2018.99998 L101.945727,2018.99998 C103.221722,2018.99998 104.226185,2017.85698 103.955674,2016.63598\" id=\"profile_round-[#1342]\"> </path> </g> </g> </g> </g></svg>";
declare const menuIcon = "<svg width=\"30px\" height=\"30px\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><g id=\"SVGRepo_bgCarrier\" stroke-width=\"0\"></g><g id=\"SVGRepo_tracerCarrier\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></g><g id=\"SVGRepo_iconCarrier\"> <path d=\"M4 6H20M4 12H20M4 18H20\" stroke=\"#000000\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path> </g></svg>";

declare class SpinnerComponent implements OnInit, AfterContentInit {
    private elRef;
    additionalTemplate: _angular_core.InputSignal<TemplateRef<ElementRef<any>> | undefined>;
    additioanlTemplateRef: _angular_core.Signal<TemplateRef<ElementRef<any>>>;
    isLoaded: _angular_core.WritableSignal<boolean>;
    autoLocate: _angular_core.InputSignal<boolean>;
    constructor(elRef: ElementRef);
    ngOnInit(): void;
    get spinnerContainerSizeStyle(): {
        width: string;
        height: string;
    } | {
        width?: undefined;
        height?: undefined;
    };
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SpinnerComponent, "app-spinner", never, { "additionalTemplate": { "alias": "additionalTemplate"; "required": false; "isSignal": true; }; "autoLocate": { "alias": "autoLocate"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type TimeLineEvent = {
    date: Date;
    name: string;
    status?: EventStatus;
    type?: EventType;
};
declare enum EventStatus {
    DONE = "done",
    PENDING = "pending"
}
declare enum EventType {
    CIRCLE = "circle",
    LINE = "line"
}

declare class TimelineComponent {
    events: _angular_core.InputSignal<TimeLineEvent[]>;
    get eventTypes(): typeof EventType;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimelineComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TimelineComponent, "app-timeline", never, { "events": { "alias": "events"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class HighlightSearchResultPipe implements PipeTransform {
    constructor();
    transform(value: string, searchTerm: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HighlightSearchResultPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<HighlightSearchResultPipe, "highlightSearchResult", true>;
}

type AutoCompleteOption = {
    alias: string;
    value: string;
};

declare class AutoCompleteComponent implements OnInit, OnChanges {
    private elementRef;
    options: _angular_core.InputSignal<AutoCompleteOption[]>;
    inputValue: _angular_core.InputSignal<string>;
    isDisabled: _angular_core.InputSignal<boolean>;
    filteredOptions: _angular_core.WritableSignal<AutoCompleteOption[]>;
    shouldShowOptions: _angular_core.WritableSignal<boolean>;
    freeText: _angular_core.WritableSignal<string>;
    textValue: _angular_core.WritableSignal<String>;
    activeIndex: _angular_core.WritableSignal<number>;
    firstTimeEntered: boolean;
    toched: boolean;
    optionSelected: _angular_core.OutputEmitterRef<AutoCompleteOption & {
        isDirty: boolean;
    }>;
    optionCleaned: _angular_core.OutputEmitterRef<void>;
    constructor(elementRef: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    onKeyDown(event: KeyboardEvent): void;
    ngOnInit(): void;
    updateSearchFilter(val: string): void;
    onOptionClicked(option: AutoCompleteOption): void;
    handleClicks(event: Event): void;
    private handleOutsideClick;
    private handleInsideClick;
    private setValue;
    private showOptionsIfExist;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AutoCompleteComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AutoCompleteComponent, "app-auto-complete", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "inputValue": { "alias": "inputValue"; "required": true; "isSignal": true; }; "isDisabled": { "alias": "isDisabled"; "required": false; "isSignal": true; }; }, { "optionSelected": "optionSelected"; "optionCleaned": "optionCleaned"; }, never, never, true, never>;
}

type NavPanel = {
    alias: string;
    link?: string;
};

declare class InnerNavPanelComponent {
    private router;
    private activatedRoute;
    constructor(router: Router, activatedRoute: ActivatedRoute);
    selectedIndex: _angular_core.WritableSignal<number>;
    horizontal: _angular_core.InputSignal<boolean>;
    items: _angular_core.InputSignal<NavPanel[]>;
    itemClicked: _angular_core.OutputEmitterRef<NavPanel>;
    currentIndex: _angular_core.WritableSignal<number>;
    onItemClicked(item: NavPanel, index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InnerNavPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InnerNavPanelComponent, "app-inner-nav-panel", never, { "horizontal": { "alias": "horizontal"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": true; "isSignal": true; }; }, { "itemClicked": "itemClicked"; }, never, never, true, never>;
}

declare class FlipCardComponent {
    isFlipped: _angular_core.WritableSignal<boolean>;
    width: _angular_core.InputSignal<string | undefined>;
    height: _angular_core.InputSignal<string | undefined>;
    frontStyle: _angular_core.InputSignal<any>;
    backStyle: _angular_core.InputSignal<any>;
    frontContent: _angular_core.InputSignal<string | Record<string, string> | undefined>;
    backContent: _angular_core.InputSignal<string | Record<string, string> | undefined>;
    constructor();
    isFrontDataObject: _angular_core.Signal<boolean>;
    isBackDataObject: _angular_core.Signal<boolean>;
    flipCard(isFlipped: any): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FlipCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FlipCardComponent, "lib-flip-card", never, { "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "frontStyle": { "alias": "frontStyle"; "required": false; "isSignal": true; }; "backStyle": { "alias": "backStyle"; "required": false; "isSignal": true; }; "frontContent": { "alias": "frontContent"; "required": false; "isSignal": true; }; "backContent": { "alias": "backContent"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface ChatMessage {
    text: string;
    createdAt: any;
    senderId: string;
    senderName: string;
}
interface Location {
    top?: string;
    bottom?: string;
    right?: string;
    left?: string;
}
interface ChatLocation {
    normalScreen: Location;
    smallScreen: Location;
}
declare class ChatComponent {
    private elementRef;
    customStyle: _angular_core.InputSignal<ChatLocation | undefined>;
    messages: _angular_core.InputSignal<ChatMessage[] | undefined>;
    notify: _angular_core.InputSignal<boolean>;
    showChat: _angular_core.WritableSignal<boolean>;
    newMessage: string;
    normalScreenStyle: _angular_core.Signal<Location>;
    smallScreenStyle: _angular_core.Signal<Location>;
    scrollAnchor: ElementRef;
    messageSent: _angular_core.OutputEmitterRef<string>;
    constructor(elementRef: ElementRef);
    openChat(): void;
    private scrollBottom;
    sendMessage(): void;
    handleClicks(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChatComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChatComponent, "lib-chat", never, { "customStyle": { "alias": "customStyle"; "required": false; "isSignal": true; }; "messages": { "alias": "messages"; "required": false; "isSignal": true; }; "notify": { "alias": "notify"; "required": false; "isSignal": true; }; }, { "messageSent": "messageSent"; }, never, never, true, never>;
}

interface Breadcrumb {
    label: string;
    url: string;
}
declare class BreadcrumbsComponent {
    breadcrumbs: _angular_core.InputSignal<Breadcrumb[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BreadcrumbsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BreadcrumbsComponent, "lib-breadcrumbs", never, { "breadcrumbs": { "alias": "breadcrumbs"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { AttachmentsModalComponent, AttachmentsService, AuthenticationButtonsComponent, AutoCompleteComponent, BreadcrumbsComponent, ChatComponent, ConfirmModalComponent, DeleteHiddenColumnsPipe, DialogResponse, DynamicComponentsTypes, EventStatus, EventType, FilterDataRowsPipe, FlipCardComponent, GenericFormComponent, GridActionType, GridComponent, GridRowValueDirective, HighlightSearchResultPipe, IconComponent, InnerNavPanelComponent, LandingPageComponent, LandingPageService, MediaPreviewModalComponent, MenuAction, MenuActionType, MenuComponent, ModalsService, NavigationBarComponent, NavigationItemType, NotificationActionType, NotificationComponent, NotificationType, NotificationsBarComponent, PaginatorComponent, PopupType, PopupsComponent, PopupsService, SearchModalComponent, SortableHeaderDirective, SpinnerComponent, TimelineComponent, ValidatorsService, compare, defaultModalProperties, genericValidators, inputModal, menuIcon, modalHeights, notificationBasedColor, subInputType, uploadFileDefaultValues, userIcon };
export type { AuthenticationButton, AutoCompleteOption, Breadcrumb, ChatLocation, ChatMessage, CheckboxField, DateFormField, DownloadEvent, FileFormField, FormField, GridAction, GridColumn, GridEvent, GridRow, GridRowValue, LandingPageNavigationItem, Location, MediaPreviewDataModel, MenuItem, NavPanel, NavigationItem, Notification, NotificationBarItemClicked, NotificationBarItems, Option, PageEvent, Popup, PopupsStyle, SortDirection, TimeLineEvent, ValidatorFormField };
