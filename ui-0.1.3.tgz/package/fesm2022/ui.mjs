import * as i0 from '@angular/core';
import { input, computed, signal, Component, HostListener, Directive, Pipe, Inject, inject, Injectable, SecurityContext, ViewChildren, output, ViewContainerRef, ViewChild, ViewEncapsulation, EventEmitter, Output, effect, ChangeDetectionStrategy } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule, ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import * as i1$2 from '@angular/common';
import { NgStyle, NgTemplateOutlet, NgClass, CommonModule, JsonPipe, KeyValuePipe, DatePipe } from '@angular/common';
import { MatDatepickerInput, MatDatepickerToggle, MatDatepicker } from '@angular/material/datepicker';
import * as i1$3 from '@angular/material/dialog';
import { MatDialogActions, MatDialogClose, MAT_DIALOG_DATA, MatDialogTitle, MatDialogContent } from '@angular/material/dialog';
import { CdkScrollable } from '@angular/cdk/scrolling';
import * as i1$1 from '@angular/platform-browser';
import { Subject, take } from 'rxjs';
import * as i1$4 from '@angular/router';
import { RouterLinkActive, RouterLink, RouterModule } from '@angular/router';
import { MatMenuTrigger, MatMenu, MatMenuItem } from '@angular/material/menu';
import { MatTooltip } from '@angular/material/tooltip';

var DynamicComponentsTypes;
(function (DynamicComponentsTypes) {
    DynamicComponentsTypes["INPUT"] = "input";
    DynamicComponentsTypes["SELECT"] = "select";
    DynamicComponentsTypes["AUTO_COMPLETE"] = "autoComplete";
    DynamicComponentsTypes["DATE"] = "date";
    DynamicComponentsTypes["FILE"] = "file";
    DynamicComponentsTypes["CHECKBOX"] = "checkbox";
})(DynamicComponentsTypes || (DynamicComponentsTypes = {}));
var subInputType;
(function (subInputType) {
    subInputType["TEXT"] = "text";
    subInputType["EMAIL"] = "email";
    subInputType["PASSWORD"] = "password";
    subInputType["NUMBER"] = "number";
    subInputType["DATE"] = "date";
    subInputType["FILE"] = "file";
    subInputType["TEXT_AREA"] = "textArea";
})(subInputType || (subInputType = {}));

class SpinnerComponent {
    constructor(elRef) {
        this.elRef = elRef;
        this.additionalTemplate = input(...(ngDevMode ? [undefined, { debugName: "additionalTemplate" }] : /* istanbul ignore next */ []));
        this.additioanlTemplateRef = computed(() => {
            const additionalTemplateRef = this.additionalTemplate();
            return additionalTemplateRef ? additionalTemplateRef : {};
        }, ...(ngDevMode ? [{ debugName: "additioanlTemplateRef" }] : /* istanbul ignore next */ []));
        this.isLoaded = signal(false, ...(ngDevMode ? [{ debugName: "isLoaded" }] : /* istanbul ignore next */ []));
        this.autoLocate = input(true, ...(ngDevMode ? [{ debugName: "autoLocate" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        // this.elRef.nativeElement.parentNode.style.position = 'relative';
    }
    get spinnerContainerSizeStyle() {
        return this.autoLocate() ? {
            width: this.elRef.nativeElement.parentNode.offsetWidth + 'px',
            height: this.elRef.nativeElement.parentNode.offsetHeight + 'px'
        } : {};
    }
    ngAfterContentInit() {
        window.setTimeout(() => {
            // wait async to finish to calculate accurate height and width
            this.isLoaded.set(true);
        }, 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SpinnerComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: SpinnerComponent, isStandalone: true, selector: "app-spinner", inputs: { additionalTemplate: { classPropertyName: "additionalTemplate", publicName: "additionalTemplate", isSignal: true, isRequired: false, transformFunction: null }, autoLocate: { classPropertyName: "autoLocate", publicName: "autoLocate", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "  @if(isLoaded()) {\r\n    <div class=\"spinner-outer-container\">\r\n      <div [ngStyle]=\"spinnerContainerSizeStyle\" class=\"spinner-container\">\r\n        @if(additionalTemplate()) {\r\n          <ng-container *ngTemplateOutlet=\"additioanlTemplateRef()\"></ng-container>\r\n        }\r\n        <div class=\"spinner\">\r\n          @for(item of [].constructor(12); let idx = $index; track idx) {\r\n            <div >\r\n            </div>\r\n          }\r\n        </div>\r\n      </div>\r\n      </div>\r\n  }\r\n\r\n", styles: [".spinner-outer-container{display:block;height:100%}.spinner-container{justify-content:center;align-items:center;display:flex;flex-direction:column}.spinner{margin-left:-80px;margin-top:1rem}.spinner div{transform-origin:40px 40px;animation:spinner-animation 1.2s linear infinite}.spinner div:after{content:\" \";display:block;position:absolute;top:3px;left:37px;width:6px;height:18px;border-radius:20%;background:#046079}.spinner div:nth-child(1){transform:rotate(0);animation-delay:-1.1s}.spinner div:nth-child(2){transform:rotate(30deg);animation-delay:-1s}.spinner div:nth-child(3){transform:rotate(60deg);animation-delay:-.9s}.spinner div:nth-child(4){transform:rotate(90deg);animation-delay:-.8s}.spinner div:nth-child(5){transform:rotate(120deg);animation-delay:-.7s}.spinner div:nth-child(6){transform:rotate(150deg);animation-delay:-.6s}.spinner div:nth-child(7){transform:rotate(180deg);animation-delay:-.5s}.spinner div:nth-child(8){transform:rotate(210deg);animation-delay:-.4s}.spinner div:nth-child(9){transform:rotate(240deg);animation-delay:-.3s}.spinner div:nth-child(10){transform:rotate(270deg);animation-delay:-.2s}.spinner div:nth-child(11){transform:rotate(300deg);animation-delay:-.1s}.spinner div:nth-child(12){transform:rotate(330deg);animation-delay:0s}@keyframes spinner-animation{0%{opacity:1}to{opacity:0}}\n"], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-spinner', imports: [NgStyle, NgTemplateOutlet], template: "  @if(isLoaded()) {\r\n    <div class=\"spinner-outer-container\">\r\n      <div [ngStyle]=\"spinnerContainerSizeStyle\" class=\"spinner-container\">\r\n        @if(additionalTemplate()) {\r\n          <ng-container *ngTemplateOutlet=\"additioanlTemplateRef()\"></ng-container>\r\n        }\r\n        <div class=\"spinner\">\r\n          @for(item of [].constructor(12); let idx = $index; track idx) {\r\n            <div >\r\n            </div>\r\n          }\r\n        </div>\r\n      </div>\r\n      </div>\r\n  }\r\n\r\n", styles: [".spinner-outer-container{display:block;height:100%}.spinner-container{justify-content:center;align-items:center;display:flex;flex-direction:column}.spinner{margin-left:-80px;margin-top:1rem}.spinner div{transform-origin:40px 40px;animation:spinner-animation 1.2s linear infinite}.spinner div:after{content:\" \";display:block;position:absolute;top:3px;left:37px;width:6px;height:18px;border-radius:20%;background:#046079}.spinner div:nth-child(1){transform:rotate(0);animation-delay:-1.1s}.spinner div:nth-child(2){transform:rotate(30deg);animation-delay:-1s}.spinner div:nth-child(3){transform:rotate(60deg);animation-delay:-.9s}.spinner div:nth-child(4){transform:rotate(90deg);animation-delay:-.8s}.spinner div:nth-child(5){transform:rotate(120deg);animation-delay:-.7s}.spinner div:nth-child(6){transform:rotate(150deg);animation-delay:-.6s}.spinner div:nth-child(7){transform:rotate(180deg);animation-delay:-.5s}.spinner div:nth-child(8){transform:rotate(210deg);animation-delay:-.4s}.spinner div:nth-child(9){transform:rotate(240deg);animation-delay:-.3s}.spinner div:nth-child(10){transform:rotate(270deg);animation-delay:-.2s}.spinner div:nth-child(11){transform:rotate(300deg);animation-delay:-.1s}.spinner div:nth-child(12){transform:rotate(330deg);animation-delay:0s}@keyframes spinner-animation{0%{opacity:1}to{opacity:0}}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { additionalTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "additionalTemplate", required: false }] }], autoLocate: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoLocate", required: false }] }] } });

class PreventEnterPropogationDirective {
    onEnter(event) {
        event.stopPropagation();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PreventEnterPropogationDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: PreventEnterPropogationDirective, isStandalone: true, selector: "[libPreventEnterPropogation]", host: { listeners: { "keyup.enter": "onEnter($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PreventEnterPropogationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[libPreventEnterPropogation]',
                    standalone: true
                }]
        }], propDecorators: { onEnter: [{
                type: HostListener,
                args: ['keyup.enter', ['$event']]
            }] } });

class DynamicInputComponent {
    get subTypes() {
        return subInputType;
    }
    constructor(formGroupDirective) {
        this.formGroupDirective = formGroupDirective;
        this.field = input.required(...(ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []));
        this.form = signal({}, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
        this.currentLength = signal(0, ...(ngDevMode ? [{ debugName: "currentLength" }] : /* istanbul ignore next */ []));
        this.maxValue = computed(() => {
            return this.field().validators['maxlength']?.hint?.maximumLength;
        }, ...(ngDevMode ? [{ debugName: "maxValue" }] : /* istanbul ignore next */ []));
        this.hasLengthError = computed(() => {
            // @ts-ignore
            return this.maxValue() && this.currentLength() > this.maxValue();
        }, ...(ngDevMode ? [{ debugName: "hasLengthError" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.form.set(this.formGroupDirective.control);
        this.currentLength.set(this.form().get(this.field().name)?.value?.length || 0);
        this.form().get(this.field().name)?.valueChanges.subscribe((val) => {
            val ? this.currentLength.set(val.length) : this.currentLength.set(0);
        });
    }
    onChange($event) {
        this.currentLength.set($event.target?.value.length || 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicInputComponent, deps: [{ token: i1.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: DynamicInputComponent, isStandalone: true, selector: "app-dynamic-input", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<form [formGroup]=\"form()\">\r\n  <label class=\"form-label\">{{field().alias}}</label>\r\n  @if(field().subInputType ===  subTypes.TEXT_AREA) {\r\n    <textarea  libPreventEnterPropogation [rows]=\"5\" class=\"form-field\" [formControlName]=\"field().name\" (change)=\"onChange($event)\"></textarea>\r\n\r\n  } @else {\r\n    <input class=\"form-field\" [type]=\"field().subInputType\" [formControlName]=\"field().name\" (input)=\"onChange($event)\"/>\r\n  }\r\n  @if(maxValue()) {\r\n    <small [ngClass]=\"{'err': hasLengthError()}\">{{currentLength()}} / {{maxValue()}}</small>\r\n  }\r\n\r\n</form>\r\n", styles: [".err{color:red}textarea{width:170px;height:50px;resize:none}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: PreventEnterPropogationDirective, selector: "[libPreventEnterPropogation]" }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-dynamic-input', imports: [FormsModule, ReactiveFormsModule, PreventEnterPropogationDirective, NgClass], template: "<form [formGroup]=\"form()\">\r\n  <label class=\"form-label\">{{field().alias}}</label>\r\n  @if(field().subInputType ===  subTypes.TEXT_AREA) {\r\n    <textarea  libPreventEnterPropogation [rows]=\"5\" class=\"form-field\" [formControlName]=\"field().name\" (change)=\"onChange($event)\"></textarea>\r\n\r\n  } @else {\r\n    <input class=\"form-field\" [type]=\"field().subInputType\" [formControlName]=\"field().name\" (input)=\"onChange($event)\"/>\r\n  }\r\n  @if(maxValue()) {\r\n    <small [ngClass]=\"{'err': hasLengthError()}\">{{currentLength()}} / {{maxValue()}}</small>\r\n  }\r\n\r\n</form>\r\n", styles: [".err{color:red}textarea{width:170px;height:50px;resize:none}\n"] }]
        }], ctorParameters: () => [{ type: i1.FormGroupDirective }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: true }] }] } });

class DynamicSelectComponent {
    constructor(formGroupDirective) {
        this.formGroupDirective = formGroupDirective;
        this.field = input.required(...(ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []));
        this.form = signal({}, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
        this.options = computed(() => this.field().options ? this.field().options : [], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
        this.isMultiOptionsMode = computed(() => this.field() && this.options() && this.options.length > 1, ...(ngDevMode ? [{ debugName: "isMultiOptionsMode" }] : /* istanbul ignore next */ []));
        this.isSingleOptionMode = computed(() => this.field() && this.options() && this.options.length === 1, ...(ngDevMode ? [{ debugName: "isSingleOptionMode" }] : /* istanbul ignore next */ []));
        this.firstOption = computed(() => this.options()?.length === 0 ? { alias: '', value: '' } : this.options()[0], ...(ngDevMode ? [{ debugName: "firstOption" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.form.set(this.formGroupDirective.control);
        if (this.isSingleOptionMode()) {
            this.form().get(this.field.name)?.setValue(this.options()[0].value);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicSelectComponent, deps: [{ token: i1.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: DynamicSelectComponent, isStandalone: true, selector: "app-dynamic-select", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<form [formGroup]=\"form()\">\r\n\r\n  <label class=\"form-label\">{{field().alias}}:</label>\r\n  <select [formControlName]=\"field().name\" class=\"form-field\">\r\n    @if(isMultiOptionsMode()) {\r\n      @for (option of field().options; track option) {\r\n        <option [value]=\"option.value\">{{ option.alias }} </option>\r\n      }      \r\n    }\r\n    @if(isSingleOptionMode()) {\r\n      <option [value]=\"firstOption().value\" disabled [selected]=true>{{ firstOption().alias }}</option>\r\n    }\r\n  </select>\r\n</form>\r\n", styles: [""], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-dynamic-select', imports: [FormsModule, ReactiveFormsModule], template: "<form [formGroup]=\"form()\">\r\n\r\n  <label class=\"form-label\">{{field().alias}}:</label>\r\n  <select [formControlName]=\"field().name\" class=\"form-field\">\r\n    @if(isMultiOptionsMode()) {\r\n      @for (option of field().options; track option) {\r\n        <option [value]=\"option.value\">{{ option.alias }} </option>\r\n      }      \r\n    }\r\n    @if(isSingleOptionMode()) {\r\n      <option [value]=\"firstOption().value\" disabled [selected]=true>{{ firstOption().alias }}</option>\r\n    }\r\n  </select>\r\n</form>\r\n" }]
        }], ctorParameters: () => [{ type: i1.FormGroupDirective }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: true }] }] } });

class DynamicDatePickerComponent {
    constructor(formGroupDirective) {
        this.formGroupDirective = formGroupDirective;
        this.field = input.required(...(ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []));
        this.form = signal({}, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
        this.minDate = computed(() => this.field().minDate || null, ...(ngDevMode ? [{ debugName: "minDate" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.form.set(this.formGroupDirective.control);
    }
    onClosed($event) {
        console.log($event.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicDatePickerComponent, deps: [{ token: i1.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.23", type: DynamicDatePickerComponent, isStandalone: true, selector: "app-dynamic-date-picker", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<form [formGroup]=\"form()\">\r\n  <label class=\"form-label\">Choose a date</label>\r\n  <div class=\"in-row\">\r\n    <input class=\"form-field\"\r\n           [formControlName]=\"field().name\"\r\n           [matDatepicker]=\"picker\"\r\n           [min]=\"minDate()\"\r\n           (dateChange)=\"onClosed($event)\">\r\n    <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n    <mat-datepicker #picker></mat-datepicker>\r\n  </div>\r\n</form>\r\n", styles: [""], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "component", type: MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicDatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-dynamic-date-picker', imports: [FormsModule, ReactiveFormsModule, MatDatepickerInput, MatDatepickerToggle, MatDatepicker], template: "<form [formGroup]=\"form()\">\r\n  <label class=\"form-label\">Choose a date</label>\r\n  <div class=\"in-row\">\r\n    <input class=\"form-field\"\r\n           [formControlName]=\"field().name\"\r\n           [matDatepicker]=\"picker\"\r\n           [min]=\"minDate()\"\r\n           (dateChange)=\"onClosed($event)\">\r\n    <mat-datepicker-toggle matIconSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n    <mat-datepicker #picker></mat-datepicker>\r\n  </div>\r\n</form>\r\n" }]
        }], ctorParameters: () => [{ type: i1.FormGroupDirective }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: true }] }] } });

var DialogResponse;
(function (DialogResponse) {
    DialogResponse["CONFIRM"] = "confirm";
    DialogResponse["SEARCH"] = "search";
    DialogResponse["CANCEL"] = "cancel";
})(DialogResponse || (DialogResponse = {}));

class ModalFooterActionsComponent {
    constructor() {
        this.confirmAction = input(DialogResponse.CONFIRM, ...(ngDevMode ? [{ debugName: "confirmAction" }] : /* istanbul ignore next */ []));
        this.onConfirmClick = input(...(ngDevMode ? [undefined, { debugName: "onConfirmClick" }] : /* istanbul ignore next */ []));
        this.closeAction = input(...(ngDevMode ? [undefined, { debugName: "closeAction" }] : /* istanbul ignore next */ []));
        this.confirmTitle = input('confirm', ...(ngDevMode ? [{ debugName: "confirmTitle" }] : /* istanbul ignore next */ []));
        this.cancelTitle = input('cancel', ...(ngDevMode ? [{ debugName: "cancelTitle" }] : /* istanbul ignore next */ []));
        /** Red confirm button, for actions that delete or throw something away. */
        this.danger = input(false, ...(ngDevMode ? [{ debugName: "danger" }] : /* istanbul ignore next */ []));
    }
    get onConfirmClickHandler() {
        return this.onConfirmClick() != null ? this.onConfirmClick()?.apply(this) : () => { };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ModalFooterActionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: ModalFooterActionsComponent, isStandalone: true, selector: "lib-modal-footer-actions", inputs: { confirmAction: { classPropertyName: "confirmAction", publicName: "confirmAction", isSignal: true, isRequired: false, transformFunction: null }, onConfirmClick: { classPropertyName: "onConfirmClick", publicName: "onConfirmClick", isSignal: true, isRequired: false, transformFunction: null }, closeAction: { classPropertyName: "closeAction", publicName: "closeAction", isSignal: true, isRequired: false, transformFunction: null }, confirmTitle: { classPropertyName: "confirmTitle", publicName: "confirmTitle", isSignal: true, isRequired: false, transformFunction: null }, cancelTitle: { classPropertyName: "cancelTitle", publicName: "cancelTitle", isSignal: true, isRequired: false, transformFunction: null }, danger: { classPropertyName: "danger", publicName: "danger", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"dialog-actions\" mat-dialog-actions>\n  <button class=\"active-btn cancel-btn\" [mat-dialog-close]=closeAction()>{{cancelTitle()}}</button>\n  @if(!onConfirmClick()) {\n    <button class=\"active-btn\" [class.submit-btn]=\"!danger()\" [class.alert-btn]=\"danger()\" [mat-dialog-close]=confirmAction() cdkFocusInitial>{{confirmTitle()}}</button>\n  } @else {\n    <button class=\"active-btn\" [class.submit-btn]=\"!danger()\" [class.alert-btn]=\"danger()\" (click)=\"onConfirmClickHandler\" mat-dialog-close cdkFocusInitial>{{confirmTitle()}}</button>\n  }\n</div>\n", styles: [".dialog-actions.mat-mdc-dialog-actions{display:flex;justify-content:flex-end;gap:8px;min-height:0;padding:18px 0 0}.dialog-actions button{margin:0;padding:.5rem 1rem;border-radius:var(--ui-radius-md);font-weight:600}.dialog-actions button:first-letter{text-transform:uppercase}.cancel-btn{--btn-color: var(--ui-surface);--btn-text: var(--ui-text);--btn-border: var(--ui-border);--btn-glow: rgba(0, 0, 0, .12);text-shadow:none}\n"], dependencies: [{ kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ModalFooterActionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-modal-footer-actions', imports: [MatDialogActions, MatDialogClose], template: "<div class=\"dialog-actions\" mat-dialog-actions>\n  <button class=\"active-btn cancel-btn\" [mat-dialog-close]=closeAction()>{{cancelTitle()}}</button>\n  @if(!onConfirmClick()) {\n    <button class=\"active-btn\" [class.submit-btn]=\"!danger()\" [class.alert-btn]=\"danger()\" [mat-dialog-close]=confirmAction() cdkFocusInitial>{{confirmTitle()}}</button>\n  } @else {\n    <button class=\"active-btn\" [class.submit-btn]=\"!danger()\" [class.alert-btn]=\"danger()\" (click)=\"onConfirmClickHandler\" mat-dialog-close cdkFocusInitial>{{confirmTitle()}}</button>\n  }\n</div>\n", styles: [".dialog-actions.mat-mdc-dialog-actions{display:flex;justify-content:flex-end;gap:8px;min-height:0;padding:18px 0 0}.dialog-actions button{margin:0;padding:.5rem 1rem;border-radius:var(--ui-radius-md);font-weight:600}.dialog-actions button:first-letter{text-transform:uppercase}.cancel-btn{--btn-color: var(--ui-surface);--btn-text: var(--ui-text);--btn-border: var(--ui-border);--btn-glow: rgba(0, 0, 0, .12);text-shadow:none}\n"] }]
        }], propDecorators: { confirmAction: [{ type: i0.Input, args: [{ isSignal: true, alias: "confirmAction", required: false }] }], onConfirmClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "onConfirmClick", required: false }] }], closeAction: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeAction", required: false }] }], confirmTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "confirmTitle", required: false }] }], cancelTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelTitle", required: false }] }], danger: [{ type: i0.Input, args: [{ isSignal: true, alias: "danger", required: false }] }] } });

class SafeHtmlPipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(value) {
        return this.sanitizer.bypassSecurityTrustHtml(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SafeHtmlPipe, deps: [{ token: i1$1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SafeHtmlPipe, isStandalone: true, name: "safeHtml" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SafeHtmlPipe, decorators: [{
            type: Pipe,
            args: [{ standalone: true, name: 'safeHtml' }]
        }], ctorParameters: () => [{ type: i1$1.DomSanitizer }] });

class ConfirmModalComponent {
    constructor(data) {
        this.data = data;
    }
    get confirmResponse() {
        return DialogResponse.CONFIRM;
    }
    get cancelResponse() {
        return DialogResponse.CANCEL;
    }
    get submitTitle() {
        return this.data.confirmBtn || '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfirmModalComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ConfirmModalComponent, isStandalone: true, selector: "app-confirm-modal", ngImport: i0, template: "<h1 class=\"dialog-header\" mat-dialog-title>{{data.title}}</h1>\r\n<div mat-dialog-content>\r\n    <p [innerHTML]=\"(data.description || '') | safeHtml\"></p>\r\n</div>\r\n\r\n<lib-modal-footer-actions\r\n[confirmTitle]=\"submitTitle\"\r\n[danger]=\"!!data.danger\">\r\n</lib-modal-footer-actions>\r\n", styles: [":host{display:block}.dialog-header.mat-mdc-dialog-title{margin:0;padding:0 0 6px;font-size:1.25rem;font-weight:700;line-height:1.3;color:var(--ui-text)}.dialog-header.mat-mdc-dialog-title:before{display:none}.mat-mdc-dialog-content.mat-mdc-dialog-content{padding:0;color:var(--ui-text-muted);font-size:.95rem;line-height:1.45}.mat-mdc-dialog-content.mat-mdc-dialog-content p{margin:0}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: ModalFooterActionsComponent, selector: "lib-modal-footer-actions", inputs: ["confirmAction", "onConfirmClick", "closeAction", "confirmTitle", "cancelTitle", "danger"] }, { kind: "pipe", type: SafeHtmlPipe, name: "safeHtml" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfirmModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-confirm-modal', imports: [MatDialogTitle, CdkScrollable, MatDialogContent, ModalFooterActionsComponent, SafeHtmlPipe], template: "<h1 class=\"dialog-header\" mat-dialog-title>{{data.title}}</h1>\r\n<div mat-dialog-content>\r\n    <p [innerHTML]=\"(data.description || '') | safeHtml\"></p>\r\n</div>\r\n\r\n<lib-modal-footer-actions\r\n[confirmTitle]=\"submitTitle\"\r\n[danger]=\"!!data.danger\">\r\n</lib-modal-footer-actions>\r\n", styles: [":host{display:block}.dialog-header.mat-mdc-dialog-title{margin:0;padding:0 0 6px;font-size:1.25rem;font-weight:700;line-height:1.3;color:var(--ui-text)}.dialog-header.mat-mdc-dialog-title:before{display:none}.mat-mdc-dialog-content.mat-mdc-dialog-content{padding:0;color:var(--ui-text-muted);font-size:.95rem;line-height:1.45}.mat-mdc-dialog-content.mat-mdc-dialog-content p{margin:0}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class SearchModalComponent {
    constructor(data) {
        this.data = data;
        this.searchOptions = signal([], ...(ngDevMode ? [{ debugName: "searchOptions" }] : /* istanbul ignore next */ []));
        this.selectControl = computed(() => new FormControl(this.searchOptions()[0] || ''), ...(ngDevMode ? [{ debugName: "selectControl" }] : /* istanbul ignore next */ []));
        this.searchOptions.set(data.extraData || []);
    }
    get errorMessage() {
        return this.data.errorMessage || 'There are no options to select from';
    }
    get isSearchOptionsExist() {
        return this.searchOptions().length > 0;
    }
    get cancelResponse() {
        return DialogResponse.CANCEL;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SearchModalComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: SearchModalComponent, isStandalone: true, selector: "app-search-modal", ngImport: i0, template: "<h1 class=\"dialog-header\" mat-dialog-title>{{data.title}}</h1>\r\n<div class=\"modal-content\" mat-dialog-content>\r\n  @if(isSearchOptionsExist) {\r\n    <select [formControl]=\"selectControl()\">\r\n      @for(option of searchOptions(); track option) {\r\n        <option>{{option}}</option>\r\n      }\r\n    </select>\r\n  } @else {\r\n    <div>\r\n      {{errorMessage}}\r\n    </div>\r\n  }\r\n</div>\r\n\r\n<div class=\"dialog-actions\" mat-dialog-actions>\r\n  @if(isSearchOptionsExist) {\r\n    <button \r\n      class=\"active-btn submit-btn\" \r\n      mat-dialog-close=\"{{selectControl().getRawValue()}}\" \r\n      cdkFocusInitial>{{data.confirmBtn}}\r\n    </button>\r\n  }\r\n  <button class=\"active-btn alert-btn\" [mat-dialog-close]=cancelResponse>cancel</button>\r\n</div>", styles: [".dialog-actions{justify-content:space-evenly}.modal-content{display:flex;justify-content:center;min-height:8vh;align-items:center}select{padding:10px;border-radius:var(--ui-radius-md);border:1px solid var(--ui-border);box-shadow:var(--ui-shadow-sm);transition:box-shadow var(--ui-transition),border-color var(--ui-transition)}select:focus{outline:none;border-color:var(--ui-primary);box-shadow:var(--ui-focus-ring)}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SearchModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-search-modal', imports: [MatDialogTitle, CdkScrollable, MatDialogContent, FormsModule, ReactiveFormsModule, MatDialogActions, MatDialogClose], template: "<h1 class=\"dialog-header\" mat-dialog-title>{{data.title}}</h1>\r\n<div class=\"modal-content\" mat-dialog-content>\r\n  @if(isSearchOptionsExist) {\r\n    <select [formControl]=\"selectControl()\">\r\n      @for(option of searchOptions(); track option) {\r\n        <option>{{option}}</option>\r\n      }\r\n    </select>\r\n  } @else {\r\n    <div>\r\n      {{errorMessage}}\r\n    </div>\r\n  }\r\n</div>\r\n\r\n<div class=\"dialog-actions\" mat-dialog-actions>\r\n  @if(isSearchOptionsExist) {\r\n    <button \r\n      class=\"active-btn submit-btn\" \r\n      mat-dialog-close=\"{{selectControl().getRawValue()}}\" \r\n      cdkFocusInitial>{{data.confirmBtn}}\r\n    </button>\r\n  }\r\n  <button class=\"active-btn alert-btn\" [mat-dialog-close]=cancelResponse>cancel</button>\r\n</div>", styles: [".dialog-actions{justify-content:space-evenly}.modal-content{display:flex;justify-content:center;min-height:8vh;align-items:center}select{padding:10px;border-radius:var(--ui-radius-md);border:1px solid var(--ui-border);box-shadow:var(--ui-shadow-sm);transition:box-shadow var(--ui-transition),border-color var(--ui-transition)}select:focus{outline:none;border-color:var(--ui-primary);box-shadow:var(--ui-focus-ring)}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class MediaPreviewModalComponent {
    constructor() {
        this.data = inject(MAT_DIALOG_DATA);
    }
    openFullscreen(event) {
        const el = event.target;
        if (el.requestFullscreen) {
            el.requestFullscreen();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MediaPreviewModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: MediaPreviewModalComponent, isStandalone: true, selector: "lib-media-preview-modal", ngImport: i0, template: "<header>\r\n  <h1 class=\"dialog-header\" >{{data.title}}</h1>\r\n</header>\r\n\r\n<main>\r\n    @if(data.media.type === 'image') {\r\n      <img\r\n        (dblclick)=\"openFullscreen($event)\"\r\n        [src]=\"data.media.url\"\r\n        alt=\"preview\"\r\n      />\r\n    }\r\n\r\n    @if(data.media.type === 'video') {\r\n      <video\r\n        [src]=\"data.media.url\"\r\n        controls\r\n        autoplay\r\n      ></video>\r\n    }\r\n</main>\r\n\r\n\r\n<lib-modal-footer-actions/>\r\n", styles: ["header{padding-left:20px}main{display:flex;justify-content:center;align-items:center;height:100%}main img,main video{max-width:20%;max-height:20%;border-radius:var(--ui-radius-md);box-shadow:var(--ui-shadow-lg)}\n"], dependencies: [{ kind: "component", type: ModalFooterActionsComponent, selector: "lib-modal-footer-actions", inputs: ["confirmAction", "onConfirmClick", "closeAction", "confirmTitle", "cancelTitle", "danger"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MediaPreviewModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-media-preview-modal', imports: [ModalFooterActionsComponent], template: "<header>\r\n  <h1 class=\"dialog-header\" >{{data.title}}</h1>\r\n</header>\r\n\r\n<main>\r\n    @if(data.media.type === 'image') {\r\n      <img\r\n        (dblclick)=\"openFullscreen($event)\"\r\n        [src]=\"data.media.url\"\r\n        alt=\"preview\"\r\n      />\r\n    }\r\n\r\n    @if(data.media.type === 'video') {\r\n      <video\r\n        [src]=\"data.media.url\"\r\n        controls\r\n        autoplay\r\n      ></video>\r\n    }\r\n</main>\r\n\r\n\r\n<lib-modal-footer-actions/>\r\n", styles: ["header{padding-left:20px}main{display:flex;justify-content:center;align-items:center;height:100%}main img,main video{max-width:20%;max-height:20%;border-radius:var(--ui-radius-md);box-shadow:var(--ui-shadow-lg)}\n"] }]
        }] });

const defaultModalProperties = {
    width: '340px',
    height: '230px',
    description: '',
    confirmBtn: 'confirm',
    title: 'Are you sure'
};
const modalHeights = {
    small: 170,
    medium: 200
};

class inputModal {
    constructor(data) {
        this.data = data;
        this.inputControl = signal(new FormControl(''), ...(ngDevMode ? [{ debugName: "inputControl" }] : /* istanbul ignore next */ []));
    }
    get confirmTitle() {
        return this.data.confirmBtn || '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: inputModal, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: inputModal, isStandalone: true, selector: "app-input-modal", ngImport: i0, template: "<h1 class=\"dialog-header\" mat-dialog-title>{{data.title}}</h1>\r\n<div mat-dialog-content>\r\n  <label [for]=\"'email'\">{{data.description}} </label>\r\n  <input id=\"email\" [formControl]=\"inputControl()\" type=\"text\">\r\n</div>\r\n\r\n<lib-modal-footer-actions\r\n  [confirmAction]=\"inputControl().getRawValue()\"\r\n  [confirmTitle]=\"confirmTitle\">\r\n</lib-modal-footer-actions>\r\n", styles: [""], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: ModalFooterActionsComponent, selector: "lib-modal-footer-actions", inputs: ["confirmAction", "onConfirmClick", "closeAction", "confirmTitle", "cancelTitle", "danger"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: inputModal, decorators: [{
            type: Component,
            args: [{ selector: 'app-input-modal', imports: [MatDialogTitle, CdkScrollable, MatDialogContent, FormsModule, ReactiveFormsModule, ModalFooterActionsComponent], template: "<h1 class=\"dialog-header\" mat-dialog-title>{{data.title}}</h1>\r\n<div mat-dialog-content>\r\n  <label [for]=\"'email'\">{{data.description}} </label>\r\n  <input id=\"email\" [formControl]=\"inputControl()\" type=\"text\">\r\n</div>\r\n\r\n<lib-modal-footer-actions\r\n  [confirmAction]=\"inputControl().getRawValue()\"\r\n  [confirmTitle]=\"confirmTitle\">\r\n</lib-modal-footer-actions>\r\n" }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

function setMessage(msg, ...args) {
    return args ? msg.replace(/\|/g, () => args.shift() || '') : msg;
}

const Messages = {
    cars: {
        errors: {
            missingCar: 'You must have a car, to add treatment',
            editFailed: 'car | can\'t be edited. please try later',
            deleteFailed: 'car | can\'t be deleted. please try later',
            addFailed: 'car | can\'t be added. please try later',
            myCarsFailed: 'can\'t get cars, please try again later',
            carDetailsFailed: 'can\'t get car info, please try again later',
            changeOwnerRequestFailed: 'can\'t change owner for car |, please try again later',
            cancelChangeOwnerFailed: 'can\'t decline the transfer for car |, please try again later',
            changeOwnerApproveFailed: 'can\'t complete the transfer for car |, please try again later',
        },
        addSuccessfully: 'car | was added successfully',
        changeOwnerReqAlert: 'By submit you will transfer car | to |',
        declineTransferAlert: `By decline car | will return to its original owner`,
        approveChangeOwnerAlert: 'By confirming car | will be in your ownership',
        transferredSuccessfully: 'Car | was transferred to | and waiting for his approval',
        editSuccessfully: 'car | edited successfully',
        deleteSuccessfully: 'car | was deleted successfully',
        declineTransfer: 'Transfer declined, car | is not in your own',
        transferSucceeded: 'Transfer succeeded, car | is in your own',
        chooseCar: 'please choose car from the list'
    },
    treatments: {
        errors: {
            deleteFailed: 'treatment cant be deleted, please try later',
            saveFailed: 'treatment cant be saved, please try later',
        },
        editSuccessfully: 'treatment was edited successfully',
        addSuccessfully: 'treatment was added successfully',
        deleteSuccessfully: 'treatment was deleted successfully',
    },
    files: {
        errors: {
            uploadFailedSize: 'Can\'t upload file larger then | mb',
            uploadFailedType: 'Can\'t upload type |',
            uploadFailedName: 'Illegal file name, change it and try again',
            noUploadedFiles: 'There is no uploaded file',
            downloadFailed: 'can\'t download this file',
            genericFail: 'can\'t upload file, please try again'
        }
    },
    user: {
        errors: {
            loginError: 'can\'t login, please try again later',
            logoutError: `opps something went wrong you are logged out`,
            registerError: `can\'t complete the registration, please try again later`,
        },
        hello: 'Hello |',
        logoutSuccess: 'you logged out successfully'
    },
    form: {
        required: 'this field is required',
        emailNotValid: 'not a valid email format',
    },
    modals: {
        areYouSure: 'Are you sure?'
    }
};

const uploadFileDefaultValues = {
    fileSize: 3000000,
    allowedTypes: ['application/pdf', 'image/jpeg', 'png']
};

var PopupType;
(function (PopupType) {
    PopupType["SUCCESS"] = "success";
    PopupType["ALERT"] = "alert";
    PopupType["WARNING"] = "warning";
})(PopupType || (PopupType = {}));

class PopupsService {
    constructor() {
        this.popupSubject = new Subject();
    }
    openPopup(data) {
        this.popupSubject.next(data);
    }
    addErrorPopOut(msg) {
        this.popupSubject.next({ message: msg, type: PopupType.ALERT });
    }
    addSuccessPopOut(msg) {
        this.popupSubject.next({ message: msg, type: PopupType.SUCCESS });
    }
    addWarningPopOut(msg) {
        this.popupSubject.next({ message: msg, type: PopupType.WARNING });
    }
    getPopup() {
        return this.popupSubject.asObservable();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PopupsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PopupsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PopupsService, decorators: [{
            type: Injectable
        }] });

class PopupsComponent {
    constructor() {
        this.customStyle = input(...(ngDevMode ? [undefined, { debugName: "customStyle" }] : /* istanbul ignore next */ []));
        this.popups = signal([], ...(ngDevMode ? [{ debugName: "popups" }] : /* istanbul ignore next */ []));
        this.popupService = inject(PopupsService);
        this.getStyleComputed = computed(() => {
            if (!this.customStyle() || Object.keys(this.customStyle() || {}).length === 0) {
                return { 'bottom': '1.5rem' };
            }
            return this.customStyle();
        }, ...(ngDevMode ? [{ debugName: "getStyleComputed" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.subscribePopups();
    }
    subscribePopups() {
        this.popupService.getPopup().subscribe({
            next: (popup) => {
                this.popups.set([...this.popups(), popup]);
                setTimeout(() => {
                    // @ts-ignore
                    this.popups.set([...this.popups().toSpliced(0, 1)]);
                }, 5000);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PopupsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: PopupsComponent, isStandalone: true, selector: "lib-popups", inputs: { customStyle: { classPropertyName: "customStyle", publicName: "customStyle", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div [ngStyle]=\"getStyleComputed()\" class=\"popups-container\">\r\n  @for(popup of popups(); track popup) {\r\n    <div class=\"popup\" [ngClass]=\"popup.type\">\r\n      {{ popup.message }}\r\n    </div>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";.popups-container{display:flex;flex-direction:column;align-items:center;position:fixed;z-index:1100}.popups-container .popup{display:flex;align-items:center;gap:10px;width:min(340px,100vw - 32px);margin:4px 0;padding:10px 14px;border-radius:10px;background:#1c2422;color:#fff;font-weight:500;font-size:.92rem;text-align:left;box-shadow:0 10px 28px #00000040;animation:popup-in .22s ease-out}.popups-container .popup:before{flex:none;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-size:13px;font-weight:700;color:#fff}.popups-container .popup.success:before{content:\"\\2713\";background:var(--ui-submit)}.popups-container .popup.alert:before{content:\"!\";background:var(--ui-alert)}.popups-container .popup.warning:before{content:\"!\";background:#e0a100;color:#1a1200}@keyframes popup-in{0%{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}@media(prefers-reduced-motion:reduce){.popups-container .popup{animation:none}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PopupsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-popups', imports: [CommonModule], standalone: true, template: "<div [ngStyle]=\"getStyleComputed()\" class=\"popups-container\">\r\n  @for(popup of popups(); track popup) {\r\n    <div class=\"popup\" [ngClass]=\"popup.type\">\r\n      {{ popup.message }}\r\n    </div>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";.popups-container{display:flex;flex-direction:column;align-items:center;position:fixed;z-index:1100}.popups-container .popup{display:flex;align-items:center;gap:10px;width:min(340px,100vw - 32px);margin:4px 0;padding:10px 14px;border-radius:10px;background:#1c2422;color:#fff;font-weight:500;font-size:.92rem;text-align:left;box-shadow:0 10px 28px #00000040;animation:popup-in .22s ease-out}.popups-container .popup:before{flex:none;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-size:13px;font-weight:700;color:#fff}.popups-container .popup.success:before{content:\"\\2713\";background:var(--ui-submit)}.popups-container .popup.alert:before{content:\"!\";background:var(--ui-alert)}.popups-container .popup.warning:before{content:\"!\";background:#e0a100;color:#1a1200}@keyframes popup-in{0%{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}@media(prefers-reduced-motion:reduce){.popups-container .popup{animation:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { customStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "customStyle", required: false }] }] } });

class AttachmentsService {
    emitDownloadEvent(event) {
        this._isDownloadClicked.next(event);
    }
    getIsDownloadClicked() {
        return this.isDownloadClicked;
    }
    constructor() {
        this._isDownloadClicked = new Subject();
        this.isDownloadClicked = this._isDownloadClicked.asObservable();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AttachmentsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AttachmentsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AttachmentsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class AttachmentsModalComponent {
    constructor(data, domSanitizer, popupsService, attachmentsService) {
        this.data = data;
        this.domSanitizer = domSanitizer;
        this.popupsService = popupsService;
        this.attachmentsService = attachmentsService;
        this.form = signal({}, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
        this.existingFileName = signal('', ...(ngDevMode ? [{ debugName: "existingFileName" }] : /* istanbul ignore next */ []));
        this.isPrevFileExist = signal(false, ...(ngDevMode ? [{ debugName: "isPrevFileExist" }] : /* istanbul ignore next */ []));
        this.chosenFileDetails = signal(null, ...(ngDevMode ? [{ debugName: "chosenFileDetails" }] : /* istanbul ignore next */ []));
        this.shouldShowRemoveButton = computed(() => this.isPrevFileExist() || this.chosenFileDetails() || this.existingFileName(), ...(ngDevMode ? [{ debugName: "shouldShowRemoveButton" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.form.set(this.data.formData?.form);
        this.isPrevFileExist.set(!!this.form()?.get('prevFile')?.value);
        const fileValue = this.form()?.get('file')?.value;
        if (fileValue) {
            const fileName = fileValue.get('file').name;
            this.existingFileName.set(fileName || '');
        }
        else {
            if (this.isPrevFileExist()) {
                this.existingFileName.set(this.form()?.get('prevFile')?.value.fileName);
            }
        }
        this.field = this.data.formData?.field;
        this.maxFileSize = this.field.fileSize || uploadFileDefaultValues.fileSize;
        this.allowedTypes = this.field.allowedTypes ? this.field.allowedTypes : uploadFileDefaultValues.allowedTypes;
    }
    onRemoveClicked() {
        const currentFileForm = this.form()?.get('file');
        if (this.isPrevFileExist() || (currentFileForm && currentFileForm.value)) {
            this.shouldRemoveExistingFileOnSave = true;
        }
        else {
            this.chosenFileDetails.set(null);
        }
        this.existingFileName.set('');
        // @ts-ignore
        this.inputFile.get(0).nativeElement.value = '';
    }
    onFileSelected(event) {
        const file = event.target.files[0];
        if (file) {
            if (this.isAllowed(file)) {
                this.chosenFileDetails.set(file);
            }
        }
    }
    isAllowed(selectedFile) {
        if (selectedFile.size > this.maxFileSize) {
            this.popupsService.addErrorPopOut(setMessage(Messages.files.errors.uploadFailedSize, `${this.maxFileSize / 1000000}`));
            return false;
        }
        if (this.allowedTypes.indexOf(selectedFile.type) === -1) {
            this.popupsService.addErrorPopOut(setMessage(Messages.files.errors.uploadFailedType, selectedFile.type));
            return false;
        }
        const sanitizedName = this.domSanitizer.sanitize(SecurityContext.URL, selectedFile.name);
        if (sanitizedName !== selectedFile.name) {
            this.popupsService.addErrorPopOut(Messages.files.errors.uploadFailedName);
            return false;
        }
        return true;
    }
    confirmFile() {
        if (this.chosenFileDetails()) {
            const formData = new FormData();
            formData.append('file', this.chosenFileDetails());
            this.form()?.get('file')?.setValue(formData);
            this.form()?.markAsDirty();
        }
        else { // there is no uploaded file
            if (this.shouldRemoveExistingFileOnSave) { // want to remove the prev file
                this.form()?.get('prevFile')?.setValue(null);
                this.form()?.get('file')?.setValue(null);
                this.popupsService.addErrorPopOut('By save the last file will be deleted');
                this.form()?.markAsDirty();
            }
        }
    }
    onPreviewClicked() {
        const field = this.form()?.get('prevFile')?.value;
        if (field) {
            this.attachmentsService.emitDownloadEvent({ fileId: field.fileId, entity: field.entity });
        }
        else {
            this.popupsService.addErrorPopOut(Messages.files.errors.downloadFailed);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AttachmentsModalComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$1.DomSanitizer }, { token: PopupsService }, { token: AttachmentsService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: AttachmentsModalComponent, isStandalone: true, selector: "lib-attachments-modal", viewQueries: [{ propertyName: "inputFile", predicate: ["inputFile"], descendants: true }], ngImport: i0, template: "<h1 class=\"dialog-header\" mat-dialog-title>{{data.title}}</h1>\r\n\r\n<div mat-dialog-content>\r\n  <form [formGroup]=\"form()\">\r\n    @if(existingFileName()) {\r\n      <label class=\"form-label\">{{field.alias}}:</label>\r\n      <label class=\"form-label file-name\">{{existingFileName()}}:</label>\r\n    }\r\n\r\n    <input #inputFile class=\"form-field input-field\" accept=\".pdf,.jpg\" type=\"file\" (change)=\"onFileSelected($event)\">\r\n  </form>\r\n\r\n  @if(shouldShowRemoveButton()) {\r\n    <button class=\"btn-mrg\" (click)=\"onRemoveClicked()\">remove</button>\r\n  }\r\n\r\n  @if(isPrevFileExist()) {\r\n    <button class=\"btn-mrg\" (click)=\"onPreviewClicked()\">preview last file</button>\r\n  }\r\n\r\n</div>\r\n\r\n<lib-modal-footer-actions [onConfirmClick]=\"confirmFile.bind(this)\"></lib-modal-footer-actions>\r\n", styles: [".input-field{margin-top:5px;margin-bottom:5px}.file-name{word-wrap:break-word}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: ModalFooterActionsComponent, selector: "lib-modal-footer-actions", inputs: ["confirmAction", "onConfirmClick", "closeAction", "confirmTitle", "cancelTitle", "danger"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AttachmentsModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-attachments-modal', imports: [MatDialogTitle, CdkScrollable, MatDialogContent, FormsModule, ReactiveFormsModule, ModalFooterActionsComponent], template: "<h1 class=\"dialog-header\" mat-dialog-title>{{data.title}}</h1>\r\n\r\n<div mat-dialog-content>\r\n  <form [formGroup]=\"form()\">\r\n    @if(existingFileName()) {\r\n      <label class=\"form-label\">{{field.alias}}:</label>\r\n      <label class=\"form-label file-name\">{{existingFileName()}}:</label>\r\n    }\r\n\r\n    <input #inputFile class=\"form-field input-field\" accept=\".pdf,.jpg\" type=\"file\" (change)=\"onFileSelected($event)\">\r\n  </form>\r\n\r\n  @if(shouldShowRemoveButton()) {\r\n    <button class=\"btn-mrg\" (click)=\"onRemoveClicked()\">remove</button>\r\n  }\r\n\r\n  @if(isPrevFileExist()) {\r\n    <button class=\"btn-mrg\" (click)=\"onPreviewClicked()\">preview last file</button>\r\n  }\r\n\r\n</div>\r\n\r\n<lib-modal-footer-actions [onConfirmClick]=\"confirmFile.bind(this)\"></lib-modal-footer-actions>\r\n", styles: [".input-field{margin-top:5px;margin-bottom:5px}.file-name{word-wrap:break-word}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$1.DomSanitizer }, { type: PopupsService }, { type: AttachmentsService }], propDecorators: { inputFile: [{
                type: ViewChildren,
                args: ['inputFile']
            }] } });

class ModalsService {
    constructor(dialog) {
        this.dialog = dialog;
    }
    openConfirmModal(dialogContent) {
        // @ts-ignore
        return this.dialog.open(ConfirmModalComponent, {
            width: dialogContent.width || defaultModalProperties.width,
            // No default height: the dialog grows with its title and description.
            height: dialogContent.height,
            maxWidth: 'calc(100vw - 32px)',
            panelClass: 'ui-confirm-dialog',
            autoFocus: false,
            data: {
                description: dialogContent.description || defaultModalProperties.description,
                confirmBtn: dialogContent.confirmBtn || defaultModalProperties.confirmBtn,
                danger: !!dialogContent.danger,
                title: dialogContent.title || defaultModalProperties.title
            }
        });
    }
    openSearchModal(page, dialogContent) {
        // @ts-ignore
        return this.dialog.open(SearchModalComponent, {
            width: dialogContent.width || defaultModalProperties.width,
            height: dialogContent.height || defaultModalProperties.height,
            autoFocus: false,
            data: {
                description: dialogContent.description || defaultModalProperties.description,
                confirmBtn: dialogContent.confirmBtn || defaultModalProperties.confirmBtn,
                title: dialogContent.title,
                ...dialogContent,
                ...page.modalData
            }
        });
    }
    openInputModal(dialogContent) {
        return this.dialog.open(inputModal, {
            data: {
                title: dialogContent.title || defaultModalProperties.title,
                description: dialogContent.description || defaultModalProperties.description,
                confirmBtn: dialogContent.confirmBtn || defaultModalProperties.confirmBtn,
            }
        });
    }
    openAttachmentsModal(dialogContent) {
        return this.dialog.open(AttachmentsModalComponent, {
            width: '400px',
            height: '250px',
            data: {
                title: dialogContent.title || defaultModalProperties.title,
                description: dialogContent.description || defaultModalProperties.description,
                confirmBtn: dialogContent.confirmBtn || defaultModalProperties.confirmBtn,
                formData: dialogContent.formData,
            }
        });
    }
    openComponentModal(component, dialogContent) {
        // @ts-ignore
        return this.dialog.open(component, {
            width: dialogContent.width || defaultModalProperties.width,
            height: dialogContent.height || defaultModalProperties.height,
        });
    }
    openMediaPreviewModal(dialogContent) {
        return this.dialog.open(MediaPreviewModalComponent, {
            data: {
                title: dialogContent.title || defaultModalProperties.title,
                description: dialogContent.description || defaultModalProperties.description,
                confirmBtn: dialogContent.confirmBtn || defaultModalProperties.confirmBtn,
                media: dialogContent.extraData
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ModalsService, deps: [{ token: i1$3.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ModalsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ModalsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$3.MatDialog }] });

class DynamicUploadComponent {
    constructor(modalsService, formGroupDirective) {
        this.modalsService = modalsService;
        this.formGroupDirective = formGroupDirective;
        this.field = input.required(...(ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []));
        this.form = signal({}, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.form.set(this.formGroupDirective.control);
    }
    openAttachmentsModal() {
        this.modalsService.openAttachmentsModal({
            title: 'Attachments modal',
            formData: {
                form: this.form(),
                field: this.field()
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicUploadComponent, deps: [{ token: ModalsService }, { token: i1.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.23", type: DynamicUploadComponent, isStandalone: true, selector: "app-dynamic-upload", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<form [formGroup]=\"form()\">\r\n  <button (click)=\"openAttachmentsModal()\">open attachments modal</button>\r\n</form>\r\n", styles: [""], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicUploadComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-dynamic-upload', imports: [FormsModule, ReactiveFormsModule], template: "<form [formGroup]=\"form()\">\r\n  <button (click)=\"openAttachmentsModal()\">open attachments modal</button>\r\n</form>\r\n" }]
        }], ctorParameters: () => [{ type: ModalsService }, { type: i1.FormGroupDirective }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: true }] }] } });

class HighlightSearchResultPipe {
    constructor() { }
    transform(value, searchTerm) {
        if (!searchTerm) {
            return value;
        }
        return value.replace(new RegExp(searchTerm, 'gi'), match => `<span class="highlight-search-result">${match}</span>`);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: HighlightSearchResultPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: HighlightSearchResultPipe, isStandalone: true, name: "highlightSearchResult" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: HighlightSearchResultPipe, decorators: [{
            type: Pipe,
            args: [{ standalone: true, name: 'highlightSearchResult' }]
        }], ctorParameters: () => [] });

class AutoCompleteComponent {
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.options = input.required(...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
        this.inputValue = input.required(...(ngDevMode ? [{ debugName: "inputValue" }] : /* istanbul ignore next */ [])); // handle input value in case of form refresh - set the prev value
        this.isDisabled = input(false, ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
        this.filteredOptions = signal([], ...(ngDevMode ? [{ debugName: "filteredOptions" }] : /* istanbul ignore next */ []));
        this.shouldShowOptions = signal(false, ...(ngDevMode ? [{ debugName: "shouldShowOptions" }] : /* istanbul ignore next */ []));
        this.freeText = signal('', ...(ngDevMode ? [{ debugName: "freeText" }] : /* istanbul ignore next */ []));
        this.textValue = signal('', ...(ngDevMode ? [{ debugName: "textValue" }] : /* istanbul ignore next */ []));
        this.activeIndex = signal(-1, ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
        this.firstTimeEntered = true;
        this.toched = false;
        this.optionSelected = output();
        this.optionCleaned = output();
    }
    ngOnChanges(changes) {
        if (changes['firstChange']) {
            return;
        }
        if (changes['options']) {
            const selectedOptionExist = this.options().some(option => option.alias === this.textValue().toString());
            if (!selectedOptionExist) {
                this.setValue();
            }
        }
    }
    onKeyDown(event) {
        const maxOptions = this.filteredOptions().length - 1;
        if (event.key === 'ArrowDown' && !this.shouldShowOptions()) {
            this.shouldShowOptions.set(true);
        }
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            this.activeIndex.set(this.activeIndex() < maxOptions ? this.activeIndex() + 1 : 0);
        }
        else if (event.key === 'ArrowUp') {
            event.preventDefault();
            this.activeIndex.set(this.activeIndex() > 0 ? this.activeIndex() - 1 : maxOptions);
        }
        else if (event.key === 'Enter' && this.activeIndex() >= 0) {
            event.preventDefault();
            this.onOptionClicked(this.filteredOptions()[this.activeIndex()]);
        }
    }
    ngOnInit() {
        if (this.inputValue()) {
            this.setValue({ alias: this.inputValue(), value: this.inputValue() }, false);
        }
        else {
            if (this.options().length === 1) {
                this.setValue(this.options()[0], false);
            }
        }
        // if creation happened mid-bubble of the click that triggered it (e.g. a *ngIf toggled by
        // a click), that same click can reach this document listener once it's attached; ignore only
        // that in-flight click, not the user's next real one.
        window.setTimeout(() => { this.firstTimeEntered = false; }, 0);
    }
    updateSearchFilter(val) {
        if (((val === '' && this.textValue() !== '') || (val === '' && this.toched))) {
            this.setValue();
        }
        this.freeText.set(val);
        const lowerVal = val.toLowerCase();
        const filteredOptions = this.options().filter((option) => {
            return option.alias.toLowerCase().includes(lowerVal);
        });
        this.filteredOptions.set(Array.from(filteredOptions));
    }
    onOptionClicked(option) {
        this.freeText.set(option.alias);
        window.setTimeout(() => {
            if (option.alias !== this.textValue()) {
                this.shouldShowOptions.set(false);
                this.setValue(option);
            }
            else {
                this.shouldShowOptions.set(false);
            }
            this.updateSearchFilter(option.alias);
        }, 0);
    }
    handleClicks(event) {
        if (this.firstTimeEntered) {
            return;
        }
        if (!this.elementRef.nativeElement.contains(event.target)) { // clicked outside
            this.handleOutsideClick();
        }
        else {
            this.handleInsideClick();
        }
    }
    handleOutsideClick() {
        this.activeIndex.set(-1);
        if (this.shouldShowOptions()) {
            this.shouldShowOptions.set(false);
        }
        const index = this.options().findIndex((option) => {
            return option.alias.toLowerCase() === this.freeText().toLowerCase();
        });
        if (index > -1) {
            this.setValue(this.options()[index]);
        }
        else {
            this.updateSearchFilter('');
        }
    }
    handleInsideClick() {
        this.toched = true;
        if (this.freeText() === '') {
            this.updateSearchFilter(this.freeText());
        }
        this.showOptionsIfExist();
    }
    setValue(option, isDirty = true) {
        if (option) {
            this.textValue.set(new String(option.alias));
            this.freeText.set(option.alias);
            this.optionSelected.emit({ ...option, isDirty }); // dont mark as dirty if its only initiated in onInit
        }
        else {
            this.textValue.set(new String(''));
            this.freeText.set('');
            this.optionCleaned.emit();
        }
        this.activeIndex.set(-1);
    }
    showOptionsIfExist() {
        this.shouldShowOptions.set(this.filteredOptions().length !== 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AutoCompleteComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: AutoCompleteComponent, isStandalone: true, selector: "app-auto-complete", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, inputValue: { classPropertyName: "inputValue", publicName: "inputValue", isSignal: true, isRequired: true, transformFunction: null }, isDisabled: { classPropertyName: "isDisabled", publicName: "isDisabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { optionSelected: "optionSelected", optionCleaned: "optionCleaned" }, host: { listeners: { "document:click": "handleClicks($event)" } }, usesOnChanges: true, ngImport: i0, template: "<div class=\"auto-complete-container\">\r\n<input\r\n[disabled]=\"isDisabled()\"\r\n  class=\"form-field\"\r\n  type=\"text\"\r\n(keydown)=\"onKeyDown($event)\"\r\n  [ngModel] = textValue()\r\n  (ngModelChange)=\"updateSearchFilter($event)\">\r\n\r\n  @if(shouldShowOptions()) {\r\n    <ul>\r\n      @for (option of filteredOptions(); track option; let index=$index) {\r\n        <li\r\n          [class.active]=\"index === activeIndex()\"\r\n          (click)=\"onOptionClicked(option)\" [innerHTML]=\"option.alias | highlightSearchResult : freeText()\"></li>\r\n      }\r\n    </ul>\r\n  }\r\n</div>\r\n", styles: [".auto-complete-container{position:relative;width:100%;max-width:100%;box-sizing:border-box}.auto-complete-container input{width:100%;box-sizing:border-box}.auto-complete-container ul{z-index:1;display:block;position:absolute;background:var(--ui-surface);border:1px solid var(--ui-border);border-radius:var(--ui-radius-md);box-shadow:var(--ui-shadow-lg);overflow:hidden;width:100%;max-width:100vw;padding:0;margin:4px 0 0;box-sizing:border-box}.auto-complete-container li{list-style-type:none;padding:5px 10px;cursor:pointer;word-break:break-word;overflow-wrap:anywhere;transition:background-color var(--ui-transition)}.auto-complete-container li:hover{background-color:var(--ui-surface-alt)}.auto-complete-container li.active{background:var(--ui-primary);color:#fff}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: HighlightSearchResultPipe, name: "highlightSearchResult" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AutoCompleteComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-auto-complete', imports: [FormsModule, HighlightSearchResultPipe], template: "<div class=\"auto-complete-container\">\r\n<input\r\n[disabled]=\"isDisabled()\"\r\n  class=\"form-field\"\r\n  type=\"text\"\r\n(keydown)=\"onKeyDown($event)\"\r\n  [ngModel] = textValue()\r\n  (ngModelChange)=\"updateSearchFilter($event)\">\r\n\r\n  @if(shouldShowOptions()) {\r\n    <ul>\r\n      @for (option of filteredOptions(); track option; let index=$index) {\r\n        <li\r\n          [class.active]=\"index === activeIndex()\"\r\n          (click)=\"onOptionClicked(option)\" [innerHTML]=\"option.alias | highlightSearchResult : freeText()\"></li>\r\n      }\r\n    </ul>\r\n  }\r\n</div>\r\n", styles: [".auto-complete-container{position:relative;width:100%;max-width:100%;box-sizing:border-box}.auto-complete-container input{width:100%;box-sizing:border-box}.auto-complete-container ul{z-index:1;display:block;position:absolute;background:var(--ui-surface);border:1px solid var(--ui-border);border-radius:var(--ui-radius-md);box-shadow:var(--ui-shadow-lg);overflow:hidden;width:100%;max-width:100vw;padding:0;margin:4px 0 0;box-sizing:border-box}.auto-complete-container li{list-style-type:none;padding:5px 10px;cursor:pointer;word-break:break-word;overflow-wrap:anywhere;transition:background-color var(--ui-transition)}.auto-complete-container li:hover{background-color:var(--ui-surface-alt)}.auto-complete-container li.active{background:var(--ui-primary);color:#fff}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }], inputValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputValue", required: true }] }], isDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isDisabled", required: false }] }], optionSelected: [{ type: i0.Output, args: ["optionSelected"] }], optionCleaned: [{ type: i0.Output, args: ["optionCleaned"] }], handleClicks: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class DynamicAutoCompleteComponent {
    constructor(formGroupDirective) {
        this.formGroupDirective = formGroupDirective;
        this.field = input.required(...(ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []));
        this.form = signal({}, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.options = computed(() => this.field().options || [], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
        this.isDisabled = computed(() => this.field().disabled || false, ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.form.set(this.formGroupDirective.control);
        this.value.set(this.form().get(this.field().name)?.value);
    }
    onOptionSelected(selectedOption) {
        if (selectedOption) {
            this.form().get(this.field().name)?.setValue(selectedOption.value);
            if (selectedOption.isDirty) { // dont mark as dirty if its only initiated in onInit
                this.form().get(this.field().name)?.markAsDirty();
            }
        }
        else {
            this.form().get(this.field().name)?.markAsTouched();
            this.form().get(this.field().name)?.setValue('');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicAutoCompleteComponent, deps: [{ token: i1.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.23", type: DynamicAutoCompleteComponent, isStandalone: true, selector: "lib-dynamic-auto-complete", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<form [formGroup]=\"form()\">\r\n  <label class=\"form-label\">{{field().alias}}</label>\r\n  <app-auto-complete [isDisabled]=\"isDisabled()\" [inputValue] = value() [options]=\"options()\" (optionCleaned)=\"onOptionSelected()\" (optionSelected)=\"onOptionSelected($event)\"/>\r\n</form>\r\n", styles: [""], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: AutoCompleteComponent, selector: "app-auto-complete", inputs: ["options", "inputValue", "isDisabled"], outputs: ["optionSelected", "optionCleaned"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicAutoCompleteComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-dynamic-auto-complete', imports: [FormsModule, ReactiveFormsModule, AutoCompleteComponent], template: "<form [formGroup]=\"form()\">\r\n  <label class=\"form-label\">{{field().alias}}</label>\r\n  <app-auto-complete [isDisabled]=\"isDisabled()\" [inputValue] = value() [options]=\"options()\" (optionCleaned)=\"onOptionSelected()\" (optionSelected)=\"onOptionSelected($event)\"/>\r\n</form>\r\n" }]
        }], ctorParameters: () => [{ type: i1.FormGroupDirective }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: true }] }] } });

class DynamicCheckboxComponent {
    constructor(formGroupDirective) {
        this.formGroupDirective = formGroupDirective;
        this.field = input.required(...(ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []));
        this.form = signal({}, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.form.set(this.formGroupDirective.control);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicCheckboxComponent, deps: [{ token: i1.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.23", type: DynamicCheckboxComponent, isStandalone: true, selector: "lib-dynamic-checkbox", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<form [formGroup]=\"form()\">\r\n  <label class=\"form-label\">{{field().alias}}</label>\r\n  <input type=\"checkbox\" [formControlName]=\"field().name\">\r\n</form>\r\n", styles: [""], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-dynamic-checkbox', imports: [FormsModule, ReactiveFormsModule], template: "<form [formGroup]=\"form()\">\r\n  <label class=\"form-label\">{{field().alias}}</label>\r\n  <input type=\"checkbox\" [formControlName]=\"field().name\">\r\n</form>\r\n" }]
        }], ctorParameters: () => [{ type: i1.FormGroupDirective }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: true }] }] } });

const DynamicComponentsMapper = {
    input: DynamicInputComponent,
    select: DynamicSelectComponent,
    date: DynamicDatePickerComponent,
    file: DynamicUploadComponent,
    // previewFileButton: DynamicPreviewUploadedFileComponent,
    autoComplete: DynamicAutoCompleteComponent,
    checkbox: DynamicCheckboxComponent,
};

class FormComponentLoaderComponent {
    constructor(changeDetectorRef) {
        this.changeDetectorRef = changeDetectorRef;
        this.field = input.required(...(ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []));
    }
    getComponentByType(type) {
        return DynamicComponentsMapper[type];
    }
    ngAfterViewInit() {
        const dynamicFieldComponent = this.field().dynamicComponent;
        if (dynamicFieldComponent) {
            const componentInstance = this.getComponentByType(dynamicFieldComponent);
            const dynamicComponent = this.dynamicInputContainer.createComponent(componentInstance);
            dynamicComponent.setInput('field', this.field());
            this.changeDetectorRef.detectChanges();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FormComponentLoaderComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.23", type: FormComponentLoaderComponent, isStandalone: true, selector: "app-form-component-loader", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: true, transformFunction: null } }, viewQueries: [{ propertyName: "dynamicInputContainer", first: true, predicate: ["dynamicInputContainer"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<ng-container #dynamicInputContainer>\r\n\r\n</ng-container>\r\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FormComponentLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-form-component-loader', standalone: true, template: "<ng-container #dynamicInputContainer>\r\n\r\n</ng-container>\r\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: true }] }], dynamicInputContainer: [{
                type: ViewChild,
                args: ['dynamicInputContainer', { read: ViewContainerRef }]
            }] } });

class DynamicErrorComponent {
    get errors() {
        const control = this.formControl();
        const controlErrors = control?.errors;
        if (control && controlErrors && (this.shouldCheckForErrors() || control.touched)) {
            return Object.keys(control?.errors);
        }
        return [];
    }
    constructor(formGroupDirective) {
        this.formGroupDirective = formGroupDirective;
        this.field = input.required(...(ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []));
        this.form = signal({}, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
        this.formValidators = input(...(ngDevMode ? [undefined, { debugName: "formValidators" }] : /* istanbul ignore next */ []));
        this.shouldCheckForErrors = input(...(ngDevMode ? [undefined, { debugName: "shouldCheckForErrors" }] : /* istanbul ignore next */ []));
        this.allValidators = computed(() => {
            return { ...this.field().validators, ...this.formValidators() };
        }, ...(ngDevMode ? [{ debugName: "allValidators" }] : /* istanbul ignore next */ []));
        this.formControl = computed(() => this.form().get(this.field().name), ...(ngDevMode ? [{ debugName: "formControl" }] : /* istanbul ignore next */ []));
    }
    ngOnInit() {
        this.form.set(this.formGroupDirective.control);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicErrorComponent, deps: [{ token: i1.FormGroupDirective }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: DynamicErrorComponent, isStandalone: true, selector: "app-dynamic-error", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: true, transformFunction: null }, formValidators: { classPropertyName: "formValidators", publicName: "formValidators", isSignal: true, isRequired: false, transformFunction: null }, shouldCheckForErrors: { classPropertyName: "shouldCheckForErrors", publicName: "shouldCheckForErrors", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<ul>\r\n   @for(error of errors; track error) {\r\n      <li class=\"error-msg\">\r\n         {{this.allValidators()[error]?.errorMsg}}\r\n      </li>\r\n   }\r\n</ul>\r\n", styles: [".error-msg{display:block;color:var(--ui-alert);margin-top:3px;white-space:break-spaces}ul{list-style:none;margin-left:-40px}ul li:before{content:\"X - \"}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DynamicErrorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-dynamic-error', standalone: true, template: "<ul>\r\n   @for(error of errors; track error) {\r\n      <li class=\"error-msg\">\r\n         {{this.allValidators()[error]?.errorMsg}}\r\n      </li>\r\n   }\r\n</ul>\r\n", styles: [".error-msg{display:block;color:var(--ui-alert);margin-top:3px;white-space:break-spaces}ul{list-style:none;margin-left:-40px}ul li:before{content:\"X - \"}\n"] }]
        }], ctorParameters: () => [{ type: i1.FormGroupDirective }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: true }] }], formValidators: [{ type: i0.Input, args: [{ isSignal: true, alias: "formValidators", required: false }] }], shouldCheckForErrors: [{ type: i0.Input, args: [{ isSignal: true, alias: "shouldCheckForErrors", required: false }] }] } });

class GenericFormComponent {
    constructor(formBuilder) {
        this.formBuilder = formBuilder;
        this.formFields = input.required(...(ngDevMode ? [{ debugName: "formFields" }] : /* istanbul ignore next */ []));
        this.formValidators = input(...(ngDevMode ? [undefined, { debugName: "formValidators" }] : /* istanbul ignore next */ []));
        this.title = input(...(ngDevMode ? [undefined, { debugName: "title" }] : /* istanbul ignore next */ []));
        this.isLoading = input(...(ngDevMode ? [undefined, { debugName: "isLoading" }] : /* istanbul ignore next */ []));
        this.additionalTemplate = input(...(ngDevMode ? [undefined, { debugName: "additionalTemplate" }] : /* istanbul ignore next */ []));
        this.isSubmitted = signal(false, ...(ngDevMode ? [{ debugName: "isSubmitted" }] : /* istanbul ignore next */ []));
        this.shouldCheckForErrors = signal(false, ...(ngDevMode ? [{ debugName: "shouldCheckForErrors" }] : /* istanbul ignore next */ []));
        this.form = computed(() => {
            const formControlsConfig = {};
            this.formFields().forEach((field) => {
                let fieldValidators = [];
                let fieldAsyncValidators = [];
                if (field.name) {
                    for (const validatorName in field.validators) {
                        const validator = field.validators[validatorName];
                        if (validator.isAsync) {
                            fieldAsyncValidators.push(validator.validatorFn);
                        }
                        else {
                            if (validatorName === 'required') {
                                // @ts-ignore
                                this.requiredMap[field.name] = true;
                            }
                            fieldValidators.push(validator.validatorFn);
                        }
                    }
                    // @ts-ignore
                    const controlConfig = {
                        validators: fieldValidators,
                        asyncValidators: fieldAsyncValidators,
                        updateOn: field.updateOn || 'change'
                    };
                    formControlsConfig[field.name] = [{ value: field.value, disabled: field.disabled }, controlConfig];
                }
            });
            const formValidators = this.createFormValidatorsArray();
            return this.formBuilder.group(formControlsConfig, { updateOn: 'blur', validators: formValidators.regularValidators, asyncValidators: formValidators.asyncValidators });
        }, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
        this.formSubmit = output();
        this.requiredMap = {};
    }
    onSubmit() {
        if (this.form().valid) {
            this.formSubmit.emit(this.form());
            this.isSubmitted.set(true);
            this.shouldCheckForErrors.set(false);
        }
        else {
            this.isSubmitted.set(false);
            this.shouldCheckForErrors.set(true);
            console.error(this.form().errors);
        }
    }
    createFormValidatorsArray() {
        const formValidatorsArray = [];
        const asyncFormValidatorsArray = [];
        const formValidatorsValue = this.formValidators();
        for (const validatorKey in formValidatorsValue) {
            const validator = formValidatorsValue[validatorKey];
            if (validator.isAsync) {
                asyncFormValidatorsArray.push(validator.validatorFn);
            }
            else {
                formValidatorsArray.push(validator.validatorFn);
            }
        }
        return {
            regularValidators: formValidatorsArray,
            asyncValidators: asyncFormValidatorsArray
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GenericFormComponent, deps: [{ token: i1.FormBuilder }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: GenericFormComponent, isStandalone: true, selector: "app-generic-form", inputs: { formFields: { classPropertyName: "formFields", publicName: "formFields", isSignal: true, isRequired: true, transformFunction: null }, formValidators: { classPropertyName: "formValidators", publicName: "formValidators", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, isLoading: { classPropertyName: "isLoading", publicName: "isLoading", isSignal: true, isRequired: false, transformFunction: null }, additionalTemplate: { classPropertyName: "additionalTemplate", publicName: "additionalTemplate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { formSubmit: "formSubmit" }, ngImport: i0, template: "@if (isLoading()) {\r\n  <app-spinner></app-spinner>\r\n} @else {\r\n  <div>\r\n    @if(title()) {\r\n      <h3 class=\"center\">{{title()}}</h3>\r\n    }\r\n      <div class=\"form-container\">\r\n      <form (ngSubmit)=\"onSubmit()\" (keyup.enter)=\"onSubmit()\" [formGroup]=\"form()\">\r\n        <div class=\"form-fields\">\r\n          @for (field of formFields(); track field) {\r\n              @if(!field.hidden && field.dynamicComponent) {\r\n                <div class=\"form-group\">\r\n                <app-form-component-loader [ngClass]=\"{'required': requiredMap[field.name]}\" [field]=\"field\"></app-form-component-loader>\r\n                <app-dynamic-error  [formValidators]=\"formValidators()\"\r\n                                   [shouldCheckForErrors]=\"isSubmitted()\" [field]=\"field\"></app-dynamic-error>\r\n                </div>\r\n              }\r\n          }\r\n        </div>\r\n        <div>\r\n          <ng-container *ngTemplateOutlet=\"additionalTemplate()\"></ng-container>\r\n        </div>\r\n        <button\r\n          [disabled]=\"!form().dirty || (form().dirty && form().invalid)\"\r\n          class=\"active-btn submit-btn submit-btn\" type=\"submit\">submit</button>\r\n      </form>\r\n    </div>\r\n  </div>\r\n}\r\n\r\n\r\n", styles: [".form-container{border:1px solid var(--ui-border);border-radius:15%;background-color:var(--ui-surface);box-shadow:var(--ui-shadow-md);display:flex;justify-content:center;margin:auto;max-width:22rem;padding:.5rem}.form-container .form-group{margin-top:10px}.form-container .form-group .required{display:flex}.form-container .form-group .required:before{content:\"*\";color:#f97272;margin-left:-8px;margin-right:1px}.form-container .form-group .form-label{display:block}.form-container .submit-btn{margin-top:35px}\n"], dependencies: [{ kind: "component", type: SpinnerComponent, selector: "app-spinner", inputs: ["additionalTemplate", "autoLocate"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: FormComponentLoaderComponent, selector: "app-form-component-loader", inputs: ["field"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: DynamicErrorComponent, selector: "app-dynamic-error", inputs: ["field", "formValidators", "shouldCheckForErrors"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GenericFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-generic-form', standalone: true, imports: [JsonPipe, SpinnerComponent, FormsModule, ReactiveFormsModule, FormComponentLoaderComponent, NgClass, DynamicErrorComponent, NgTemplateOutlet], template: "@if (isLoading()) {\r\n  <app-spinner></app-spinner>\r\n} @else {\r\n  <div>\r\n    @if(title()) {\r\n      <h3 class=\"center\">{{title()}}</h3>\r\n    }\r\n      <div class=\"form-container\">\r\n      <form (ngSubmit)=\"onSubmit()\" (keyup.enter)=\"onSubmit()\" [formGroup]=\"form()\">\r\n        <div class=\"form-fields\">\r\n          @for (field of formFields(); track field) {\r\n              @if(!field.hidden && field.dynamicComponent) {\r\n                <div class=\"form-group\">\r\n                <app-form-component-loader [ngClass]=\"{'required': requiredMap[field.name]}\" [field]=\"field\"></app-form-component-loader>\r\n                <app-dynamic-error  [formValidators]=\"formValidators()\"\r\n                                   [shouldCheckForErrors]=\"isSubmitted()\" [field]=\"field\"></app-dynamic-error>\r\n                </div>\r\n              }\r\n          }\r\n        </div>\r\n        <div>\r\n          <ng-container *ngTemplateOutlet=\"additionalTemplate()\"></ng-container>\r\n        </div>\r\n        <button\r\n          [disabled]=\"!form().dirty || (form().dirty && form().invalid)\"\r\n          class=\"active-btn submit-btn submit-btn\" type=\"submit\">submit</button>\r\n      </form>\r\n    </div>\r\n  </div>\r\n}\r\n\r\n\r\n", styles: [".form-container{border:1px solid var(--ui-border);border-radius:15%;background-color:var(--ui-surface);box-shadow:var(--ui-shadow-md);display:flex;justify-content:center;margin:auto;max-width:22rem;padding:.5rem}.form-container .form-group{margin-top:10px}.form-container .form-group .required{display:flex}.form-container .form-group .required:before{content:\"*\";color:#f97272;margin-left:-8px;margin-right:1px}.form-container .form-group .form-label{display:block}.form-container .submit-btn{margin-top:35px}\n"] }]
        }], ctorParameters: () => [{ type: i1.FormBuilder }], propDecorators: { formFields: [{ type: i0.Input, args: [{ isSignal: true, alias: "formFields", required: true }] }], formValidators: [{ type: i0.Input, args: [{ isSignal: true, alias: "formValidators", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], isLoading: [{ type: i0.Input, args: [{ isSignal: true, alias: "isLoading", required: false }] }], additionalTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "additionalTemplate", required: false }] }], formSubmit: [{ type: i0.Output, args: ["formSubmit"] }] } });

class ValidatorsService {
    constructor() { }
    deleteError(control, error) {
        const controlErrors = control.errors;
        if (controlErrors && controlErrors[error]) {
            delete control.errors[error];
            if (JSON.stringify(controlErrors) == JSON.stringify({})) {
                control.setErrors(null);
            }
        }
    }
    setError(control, error) {
        if (!control?.getError(error)) {
            control?.setErrors({ ...control?.errors, ...{ [error]: true } });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ValidatorsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ValidatorsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ValidatorsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

const genericValidators = {
    positiveNumber: {
        'min': {
            validatorFn: Validators.min(0),
            errorMsg: 'must be positive number'
        }
    },
    required: {
        'required': {
            validatorFn: Validators.required,
            errorMsg: 'this field is required'
        },
    }
};

class LandingPageService {
    constructor(modalsService, router) {
        this.modalsService = modalsService;
        this.router = router;
    }
    openNavigationModal(page, dialogContent) {
        const options = page.modalData?.extraData;
        this.modalsService.openSearchModal(page, dialogContent).afterClosed().pipe(take(1)).subscribe((chosenOption) => {
            if (chosenOption && options && options.findIndex((option) => option === chosenOption) > -1) {
                this.router.navigate([page.link, chosenOption]);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LandingPageService, deps: [{ token: ModalsService }, { token: i1$4.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LandingPageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LandingPageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ModalsService }, { type: i1$4.Router }] });

var NavigationItemType;
(function (NavigationItemType) {
    NavigationItemType["LINK"] = "link";
    NavigationItemType["MODAL"] = "modal";
})(NavigationItemType || (NavigationItemType = {}));

const userIcon = `<svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <title>profile_round [#1342]</title> <desc>Created with Sketch.</desc> <defs> </defs> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Dribbble-Light-Preview" transform="translate(-140.000000, -2159.000000)" fill="#000000"> <g id="icons" transform="translate(56.000000, 160.000000)"> <path d="M100.562548,2016.99998 L87.4381713,2016.99998 C86.7317804,2016.99998 86.2101535,2016.30298 86.4765813,2015.66198 C87.7127655,2012.69798 90.6169306,2010.99998 93.9998492,2010.99998 C97.3837885,2010.99998 100.287954,2012.69798 101.524138,2015.66198 C101.790566,2016.30298 101.268939,2016.99998 100.562548,2016.99998 M89.9166645,2004.99998 C89.9166645,2002.79398 91.7489936,2000.99998 93.9998492,2000.99998 C96.2517256,2000.99998 98.0830339,2002.79398 98.0830339,2004.99998 C98.0830339,2007.20598 96.2517256,2008.99998 93.9998492,2008.99998 C91.7489936,2008.99998 89.9166645,2007.20598 89.9166645,2004.99998 M103.955674,2016.63598 C103.213556,2013.27698 100.892265,2010.79798 97.837022,2009.67298 C99.4560048,2008.39598 100.400241,2006.33098 100.053171,2004.06998 C99.6509769,2001.44698 97.4235996,1999.34798 94.7348224,1999.04198 C91.0232075,1998.61898 87.8750721,2001.44898 87.8750721,2004.99998 C87.8750721,2006.88998 88.7692896,2008.57398 90.1636971,2009.67298 C87.1074334,2010.79798 84.7871636,2013.27698 84.044024,2016.63598 C83.7745338,2017.85698 84.7789973,2018.99998 86.0539717,2018.99998 L101.945727,2018.99998 C103.221722,2018.99998 104.226185,2017.85698 103.955674,2016.63598" id="profile_round-[#1342]"> </path> </g> </g> </g> </g></svg>`;
const menuIcon = `<svg width="30px" height="30px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M4 6H20M4 12H20M4 18H20" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>`;

class IconComponent {
    constructor(domSanitizer) {
        this.domSanitizer = domSanitizer;
        this.icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
        this.sanitizedIcon = computed(() => this.domSanitizer.bypassSecurityTrustHtml(this.icon()), ...(ngDevMode ? [{ debugName: "sanitizedIcon" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: IconComponent, deps: [{ token: i1$1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.23", type: IconComponent, isStandalone: true, selector: "app-icon", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div [innerHTML]=\"sanitizedIcon()\"></div>", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-icon', standalone: true, template: "<div [innerHTML]=\"sanitizedIcon()\"></div>" }]
        }], ctorParameters: () => [{ type: i1$1.DomSanitizer }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }] } });

class MenuComponent {
    constructor() {
        this.icon = input.required(...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
        this.items = input.required(...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
        this.menuOpen = signal(false, ...(ngDevMode ? [{ debugName: "menuOpen" }] : /* istanbul ignore next */ []));
        this.menuPosition = signal({ top: 0, left: 0 }, ...(ngDevMode ? [{ debugName: "menuPosition" }] : /* istanbul ignore next */ []));
        this.menuActionClicked = output();
    }
    onMenuActionClicked(item) {
        this.menuActionClicked.emit(item);
    }
    toggleMenu() {
        this.menuOpen.set(!this.menuOpen());
        if (this.menuOpen()) {
            requestAnimationFrame(() => this.setMenuPosition()); // wait the menu to be visible before taking the position
        }
    }
    closeMenu() {
        this.menuOpen.set(false);
    }
    setMenuPosition() {
        if (this.menuTrigger?.nativeElement) {
            const triggerRect = this.menuTrigger.nativeElement.getBoundingClientRect();
            const menuWidth = 160; // Adjust based on actual menu width
            const menuHeight = this.items.length * 40; // Approximate height based on items
            const screenWidth = window.innerWidth;
            const screenHeight = window.innerHeight;
            let left = triggerRect.left;
            let top = triggerRect.bottom + 4; // below button
            // 🔹 Prevent right overflow
            if (left + menuWidth > screenWidth) {
                left = triggerRect.right - menuWidth; // Align menu to the button's right edge
            }
            // 🔹 Prevent left overflow
            if (left < 10) {
                left = 10; // Keep margin from the left edge
            }
            // 🔹 Prevent bottom overflow
            if (top + menuHeight > screenHeight) {
                top = triggerRect.top - menuHeight - 4; // Open above the button
            }
            // 🔹 Prevent top overflow
            if (top < 10) {
                top = 10; // Keep at least 10px margin from the top edge
            }
            this.menuPosition.set({ top, left });
        }
    }
    onDocumentClick(event) {
        if (!event.target.closest('.icon-button.active-btn') &&
            !event.target.closest('.custom-menu')) {
            this.menuOpen.set(false);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: MenuComponent, isStandalone: true, selector: "app-menu", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { menuActionClicked: "menuActionClicked" }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, viewQueries: [{ propertyName: "menuTrigger", first: true, predicate: ["menuTrigger"], descendants: true, static: true }], ngImport: i0, template: "<button class=\"icon-button active-btn menu-trigger-btn\" (click)=\"toggleMenu()\" #menuTrigger>\r\n  <app-icon [icon]=\"icon()\"></app-icon>\r\n</button>\r\n\r\n@if(menuOpen()) {\r\n  <div class=\"menu-overlay\"(click)=\"closeMenu()\"></div>\r\n\r\n  <div class=\"custom-menu\"  [style.top.px]=\"menuPosition().top\" [style.left.px]=\"menuPosition().left\">\r\n    @for(item of items(); track item.alias) {\r\n      @if(item.show) {\r\n        <div class=\"menu-item\">\r\n          @if(item.link) {\r\n            <a class=\"nav-item\" [routerLinkActive]=\"['active']\" [routerLink]=\"item.link\" (click)=\"closeMenu()\">{{item.alias}}</a>\r\n          } @else {\r\n            <button class=\"nav-item\" (click)=\"onMenuActionClicked(item); closeMenu()\">{{item.alias}}</button>\r\n          }\r\n        </div>\r\n      }\r\n\r\n    }\r\n  </div>\r\n}\r\n", styles: [".menu-overlay{position:fixed;inset:0;background:#0000004d;z-index:999}.custom-menu{position:absolute;background:var(--ui-surface);border:1px solid var(--ui-border);border-radius:var(--ui-radius-md);box-shadow:var(--ui-shadow-lg);padding:8px 0;z-index:1000;min-width:160px}.menu-item+.menu-item{margin-top:4px}.custom-menu .nav-item{display:block;padding:10px 14px;text-align:left;background:none;border:none;cursor:pointer;text-decoration:none;color:inherit;border-radius:4px;transition:background .2s;font-size:14px;font-family:auto,serif}.custom-menu button.nav-item{width:100%}.custom-menu .nav-item:hover{background:#f5f5f5}\n"], dependencies: [{ kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-menu', standalone: true, imports: [MatMenuTrigger, IconComponent, MatMenu, MatMenuItem, RouterLinkActive, RouterLink], template: "<button class=\"icon-button active-btn menu-trigger-btn\" (click)=\"toggleMenu()\" #menuTrigger>\r\n  <app-icon [icon]=\"icon()\"></app-icon>\r\n</button>\r\n\r\n@if(menuOpen()) {\r\n  <div class=\"menu-overlay\"(click)=\"closeMenu()\"></div>\r\n\r\n  <div class=\"custom-menu\"  [style.top.px]=\"menuPosition().top\" [style.left.px]=\"menuPosition().left\">\r\n    @for(item of items(); track item.alias) {\r\n      @if(item.show) {\r\n        <div class=\"menu-item\">\r\n          @if(item.link) {\r\n            <a class=\"nav-item\" [routerLinkActive]=\"['active']\" [routerLink]=\"item.link\" (click)=\"closeMenu()\">{{item.alias}}</a>\r\n          } @else {\r\n            <button class=\"nav-item\" (click)=\"onMenuActionClicked(item); closeMenu()\">{{item.alias}}</button>\r\n          }\r\n        </div>\r\n      }\r\n\r\n    }\r\n  </div>\r\n}\r\n", styles: [".menu-overlay{position:fixed;inset:0;background:#0000004d;z-index:999}.custom-menu{position:absolute;background:var(--ui-surface);border:1px solid var(--ui-border);border-radius:var(--ui-radius-md);box-shadow:var(--ui-shadow-lg);padding:8px 0;z-index:1000;min-width:160px}.menu-item+.menu-item{margin-top:4px}.custom-menu .nav-item{display:block;padding:10px 14px;text-align:left;background:none;border:none;cursor:pointer;text-decoration:none;color:inherit;border-radius:4px;transition:background .2s;font-size:14px;font-family:auto,serif}.custom-menu button.nav-item{width:100%}.custom-menu .nav-item:hover{background:#f5f5f5}\n"] }]
        }], propDecorators: { menuTrigger: [{
                type: ViewChild,
                args: ['menuTrigger', { static: true }]
            }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: true }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], menuActionClicked: [{ type: i0.Output, args: ["menuActionClicked"] }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class NavigationBarComponent {
    get menuIcon() {
        return menuIcon;
    }
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
        this.navItems = input.required(...(ngDevMode ? [{ debugName: "navItems" }] : /* istanbul ignore next */ []));
        this.showMenuInSmallScreens = input(true, ...(ngDevMode ? [{ debugName: "showMenuInSmallScreens" }] : /* istanbul ignore next */ []));
        // @Input() navItems!: MenuItem[];
        this.title = input(...(ngDevMode ? [undefined, { debugName: "title" }] : /* istanbul ignore next */ []));
        this.logo = input(...(ngDevMode ? [undefined, { debugName: "logo" }] : /* istanbul ignore next */ []));
        this.redirectBrandLink = input(...(ngDevMode ? [undefined, { debugName: "redirectBrandLink" }] : /* istanbul ignore next */ []));
        this.sanitizedLogo = computed(() => this.logo() ? this.sanitizer.bypassSecurityTrustHtml(this.logo()) : '', ...(ngDevMode ? [{ debugName: "sanitizedLogo" }] : /* istanbul ignore next */ []));
        this.showLogo = computed(() => !!this.sanitizedLogo() && this.sanitizedLogo() != '', ...(ngDevMode ? [{ debugName: "showLogo" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: NavigationBarComponent, deps: [{ token: i1$1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: NavigationBarComponent, isStandalone: true, selector: "app-navigation-bar", inputs: { navItems: { classPropertyName: "navItems", publicName: "navItems", isSignal: true, isRequired: true, transformFunction: null }, showMenuInSmallScreens: { classPropertyName: "showMenuInSmallScreens", publicName: "showMenuInSmallScreens", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, logo: { classPropertyName: "logo", publicName: "logo", isSignal: true, isRequired: false, transformFunction: null }, redirectBrandLink: { classPropertyName: "redirectBrandLink", publicName: "redirectBrandLink", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"in-row align-center\">\r\n  <div class=\"brand\">\r\n    @if(showLogo()) {\r\n      <a  [routerLink]=\"[redirectBrandLink() || '/']\" >\r\n        <div style=\"width: 60px; height: 60px;\" [innerHTML]=\"sanitizedLogo()\"></div>\r\n      </a>\r\n    } @else {\r\n      <a class=\"navbar-brand\" [routerLink]=\"[redirectBrandLink() || '/']\" >{{title()}}</a>\r\n    }\r\n</div>\r\n\r\n    @for(nav of navItems(); track nav.link) {\r\n        @if(nav.show) {\r\n            <nav [ngClass]=\"{'nav-panel': showMenuInSmallScreens()}\">\r\n                <a class=\"nav-item\"\r\n                   [routerLink]=\"nav.link\" [routerLinkActive]=\"['active']\">\r\n                    {{nav.alias}}\r\n                </a>\r\n            </nav>\r\n        }\r\n    }\r\n\r\n  @if(showMenuInSmallScreens()) {\r\n    <div class=\"nav-button\">\r\n      <app-menu [icon]=\"menuIcon\" [items]=\"navItems()\"></app-menu>\r\n    </div>\r\n  }\r\n</div>\r\n", styles: ["app-navigation-bar .brand{margin-right:10px}app-navigation-bar a{text-decoration:none}app-navigation-bar .nav-item{color:#2424a5;margin:.6rem;padding:1rem;background-color:#ededed;border-radius:25%;background-image:var(--ui-gloss);box-shadow:var(--ui-shadow-sm),var(--ui-highlight);transition:opacity var(--ui-transition),box-shadow var(--ui-transition),transform var(--ui-transition)}app-navigation-bar .nav-item:hover{opacity:.8;box-shadow:var(--ui-shadow-md),var(--ui-highlight);transform:translateY(-1px)}app-navigation-bar .nav-item:active{box-shadow:var(--ui-shadow-inset);transform:translateY(0)}app-navigation-bar .navbar-brand{color:#000}app-navigation-bar .mat-tab-link-container{width:480px!important}app-navigation-bar .mat-mdc-tab-link{min-width:80px!important}@media only screen and (max-width:1050px){app-navigation-bar .nav-panel{display:none;transition:display 1s ease-out}}@media only screen and (min-width:1050px){app-navigation-bar .nav-button{display:none}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i1$4.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i1$4.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: MenuComponent, selector: "app-menu", inputs: ["icon", "items"], outputs: ["menuActionClicked"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: NavigationBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-navigation-bar', encapsulation: ViewEncapsulation.None, standalone: true, imports: [CommonModule, RouterModule, MenuComponent], template: "<div class=\"in-row align-center\">\r\n  <div class=\"brand\">\r\n    @if(showLogo()) {\r\n      <a  [routerLink]=\"[redirectBrandLink() || '/']\" >\r\n        <div style=\"width: 60px; height: 60px;\" [innerHTML]=\"sanitizedLogo()\"></div>\r\n      </a>\r\n    } @else {\r\n      <a class=\"navbar-brand\" [routerLink]=\"[redirectBrandLink() || '/']\" >{{title()}}</a>\r\n    }\r\n</div>\r\n\r\n    @for(nav of navItems(); track nav.link) {\r\n        @if(nav.show) {\r\n            <nav [ngClass]=\"{'nav-panel': showMenuInSmallScreens()}\">\r\n                <a class=\"nav-item\"\r\n                   [routerLink]=\"nav.link\" [routerLinkActive]=\"['active']\">\r\n                    {{nav.alias}}\r\n                </a>\r\n            </nav>\r\n        }\r\n    }\r\n\r\n  @if(showMenuInSmallScreens()) {\r\n    <div class=\"nav-button\">\r\n      <app-menu [icon]=\"menuIcon\" [items]=\"navItems()\"></app-menu>\r\n    </div>\r\n  }\r\n</div>\r\n", styles: ["app-navigation-bar .brand{margin-right:10px}app-navigation-bar a{text-decoration:none}app-navigation-bar .nav-item{color:#2424a5;margin:.6rem;padding:1rem;background-color:#ededed;border-radius:25%;background-image:var(--ui-gloss);box-shadow:var(--ui-shadow-sm),var(--ui-highlight);transition:opacity var(--ui-transition),box-shadow var(--ui-transition),transform var(--ui-transition)}app-navigation-bar .nav-item:hover{opacity:.8;box-shadow:var(--ui-shadow-md),var(--ui-highlight);transform:translateY(-1px)}app-navigation-bar .nav-item:active{box-shadow:var(--ui-shadow-inset);transform:translateY(0)}app-navigation-bar .navbar-brand{color:#000}app-navigation-bar .mat-tab-link-container{width:480px!important}app-navigation-bar .mat-mdc-tab-link{min-width:80px!important}@media only screen and (max-width:1050px){app-navigation-bar .nav-panel{display:none;transition:display 1s ease-out}}@media only screen and (min-width:1050px){app-navigation-bar .nav-button{display:none}}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.DomSanitizer }], propDecorators: { navItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "navItems", required: true }] }], showMenuInSmallScreens: [{ type: i0.Input, args: [{ isSignal: true, alias: "showMenuInSmallScreens", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], logo: [{ type: i0.Input, args: [{ isSignal: true, alias: "logo", required: false }] }], redirectBrandLink: [{ type: i0.Input, args: [{ isSignal: true, alias: "redirectBrandLink", required: false }] }] } });

class LandingPageComponent {
    get navigationItemType() {
        return NavigationItemType;
    }
    constructor() {
        this.pages = input.required(...(ngDevMode ? [{ debugName: "pages" }] : /* istanbul ignore next */ []));
        this.openModalClicked = output();
    }
    openModal(page) {
        this.openModalClicked.emit(page);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LandingPageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: LandingPageComponent, isStandalone: true, selector: "app-landing-page", inputs: { pages: { classPropertyName: "pages", publicName: "pages", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { openModalClicked: "openModalClicked" }, ngImport: i0, template: "<div class=\"landing-page-container\">\n        @for (page of pages(); track page.link) {\n          @if(!page.hide) {\n            @if(page.disabled) {\n              <div class=\"link-box\">\n                <h3 class=\"disabled-page\" [matTooltip]=\"page.tooltip\">{{page.alias}}</h3>\n              </div>\n            } @else if(page.type === navigationItemType.LINK) {\n              <div class=\"link-box clickable\" [matTooltip]=\"page.tooltip\" [routerLink]=\"page.link\">\n                <h3>{{page.alias}}</h3>\n              </div>\n            } @else {\n              <div class=\"link-box clickable\" [matTooltip]=\"page.tooltip\" (click)=\"openModal(page)\">\n                <h3>{{page.alias}}</h3>\n              </div>\n            }\n          }\n\n        }\n</div>\n", styles: [".landing-page-container{margin-top:5rem;display:flex;justify-content:center;align-items:center;flex-wrap:wrap}.landing-page-container .disabled-page{opacity:.2;cursor:not-allowed;text-decoration:line-through}.landing-page-container .link-box{height:5rem;background-color:#f0f0f0;background-image:var(--ui-gloss);box-shadow:var(--ui-shadow-md),var(--ui-highlight);transition:box-shadow var(--ui-transition),transform var(--ui-transition);margin:10px;border-radius:35px}.landing-page-container .link-box:hover{box-shadow:var(--ui-shadow-lg),var(--ui-highlight);transform:translateY(-2px)}.landing-page-container .link-box{display:flex;justify-content:center;align-items:center;padding:.5rem;flex-basis:30%;text-align:center}.landing-page-container .link-box.clickable{cursor:pointer}.landing-page-container .link-box :hover{opacity:.2}.landing-page-container .link-box :active{opacity:1}@media(max-width:1200px){.landing-page-container .link-box{flex-basis:45%}}\n"], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LandingPageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-landing-page', imports: [RouterLink, MatTooltip], template: "<div class=\"landing-page-container\">\n        @for (page of pages(); track page.link) {\n          @if(!page.hide) {\n            @if(page.disabled) {\n              <div class=\"link-box\">\n                <h3 class=\"disabled-page\" [matTooltip]=\"page.tooltip\">{{page.alias}}</h3>\n              </div>\n            } @else if(page.type === navigationItemType.LINK) {\n              <div class=\"link-box clickable\" [matTooltip]=\"page.tooltip\" [routerLink]=\"page.link\">\n                <h3>{{page.alias}}</h3>\n              </div>\n            } @else {\n              <div class=\"link-box clickable\" [matTooltip]=\"page.tooltip\" (click)=\"openModal(page)\">\n                <h3>{{page.alias}}</h3>\n              </div>\n            }\n          }\n\n        }\n</div>\n", styles: [".landing-page-container{margin-top:5rem;display:flex;justify-content:center;align-items:center;flex-wrap:wrap}.landing-page-container .disabled-page{opacity:.2;cursor:not-allowed;text-decoration:line-through}.landing-page-container .link-box{height:5rem;background-color:#f0f0f0;background-image:var(--ui-gloss);box-shadow:var(--ui-shadow-md),var(--ui-highlight);transition:box-shadow var(--ui-transition),transform var(--ui-transition);margin:10px;border-radius:35px}.landing-page-container .link-box:hover{box-shadow:var(--ui-shadow-lg),var(--ui-highlight);transform:translateY(-2px)}.landing-page-container .link-box{display:flex;justify-content:center;align-items:center;padding:.5rem;flex-basis:30%;text-align:center}.landing-page-container .link-box.clickable{cursor:pointer}.landing-page-container .link-box :hover{opacity:.2}.landing-page-container .link-box :active{opacity:1}@media(max-width:1200px){.landing-page-container .link-box{flex-basis:45%}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { pages: [{ type: i0.Input, args: [{ isSignal: true, alias: "pages", required: true }] }], openModalClicked: [{ type: i0.Output, args: ["openModalClicked"] }] } });

var GridActionType;
(function (GridActionType) {
    GridActionType["EDIT"] = "edit";
    GridActionType["DELETE"] = "delete";
    GridActionType["NAVIGATE"] = "navigate";
    GridActionType["DOWNLOAD"] = "download";
})(GridActionType || (GridActionType = {}));

const rotate = {
    asc: 'desc',
    desc: '',
    '': 'asc',
};
const compare = (val1, val2) => {
    if ((typeof val1) === 'object' && (typeof val2) === 'object') {
        val1 = val1.getTime();
        val2 = val2.getTime();
    }
    return (val1 < val2 ? -1 : val1 > val2 ? 1 : 0);
};
class SortableHeaderDirective {
    constructor() {
        this.sortable = input.required(...(ngDevMode ? [{ debugName: "sortable" }] : /* istanbul ignore next */ []));
        this.direction = signal('', ...(ngDevMode ? [{ debugName: "direction" }] : /* istanbul ignore next */ []));
        this.isSortable = input(true, ...(ngDevMode ? [{ debugName: "isSortable" }] : /* istanbul ignore next */ []));
        this.sort = new EventEmitter();
    }
    rotate() {
        if (this.isSortable()) {
            this.direction.set(rotate[this.direction()]);
            this.sort.emit({ column: this.sortable(), direction: this.direction() });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SortableHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.23", type: SortableHeaderDirective, isStandalone: true, selector: "[appSortableHeader]", inputs: { sortable: { classPropertyName: "sortable", publicName: "sortable", isSignal: true, isRequired: true, transformFunction: null }, isSortable: { classPropertyName: "isSortable", publicName: "isSortable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { sort: "sort" }, host: { listeners: { "click": "rotate()" }, properties: { "class.asc": "direction() === \"asc\"", "class.desc": "direction() === \"desc\"" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SortableHeaderDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[appSortableHeader]',
                    standalone: true,
                    host: {
                        '[class.asc]': 'direction() === "asc"',
                        '[class.desc]': 'direction() === "desc"',
                        '(click)': 'rotate()',
                    }
                }]
        }], propDecorators: { sortable: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortable", required: true }] }], isSortable: [{ type: i0.Input, args: [{ isSignal: true, alias: "isSortable", required: false }] }], sort: [{
                type: Output
            }] } });

class GridRowValueDirective {
    constructor(el, datePipe) {
        this.el = el;
        this.datePipe = datePipe;
        this.appGridRow = input(...(ngDevMode ? [undefined, { debugName: "appGridRow" }] : /* istanbul ignore next */ []));
        this.config = input(...(ngDevMode ? [undefined, { debugName: "config" }] : /* istanbul ignore next */ []));
    }
    ngAfterViewInit() {
        switch (this.appGridRow().key) {
            case 'date': {
                this.el.nativeElement.innerHTML = this.datePipe.transform(this.el.nativeElement.innerHTML, this.config().dateFormat);
                break;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GridRowValueDirective, deps: [{ token: i0.ElementRef }, { token: i1$2.DatePipe }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.23", type: GridRowValueDirective, isStandalone: true, selector: "[appGridRow]", inputs: { appGridRow: { classPropertyName: "appGridRow", publicName: "appGridRow", isSignal: true, isRequired: false, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GridRowValueDirective, decorators: [{
            type: Directive,
            args: [{ standalone: true, selector: '[appGridRow]' }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i1$2.DatePipe }], propDecorators: { appGridRow: [{ type: i0.Input, args: [{ isSignal: true, alias: "appGridRow", required: false }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: false }] }] } });

class PaginatorComponent {
    get firstPageNumber() {
        return 1;
    }
    constructor() {
        this.currentPage = input.required(...(ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []));
        this.totalItems = input.required(...(ngDevMode ? [{ debugName: "totalItems" }] : /* istanbul ignore next */ []));
        this.itemsPerPage = signal(5, ...(ngDevMode ? [{ debugName: "itemsPerPage" }] : /* istanbul ignore next */ []));
        this.sizeOptions = [5, 10];
        this.pageNumbers = [];
        this.visiblePagesRange = 5;
        this.startVisiblePage = computed(() => Math.max(1, this.currentPageIndex() - this.visiblePagesRange), ...(ngDevMode ? [{ debugName: "startVisiblePage" }] : /* istanbul ignore next */ []));
        this.endVisiblePage = computed(() => Math.min(this.startVisiblePage() + 2 * this.visiblePagesRange, this.lastPageNumber()), ...(ngDevMode ? [{ debugName: "endVisiblePage" }] : /* istanbul ignore next */ []));
        this.getVisiblePageNumbers = computed(() => Array.from({ length: this.endVisiblePage() - this.startVisiblePage() + 1 }, (_, index) => this.startVisiblePage() + index), ...(ngDevMode ? [{ debugName: "getVisiblePageNumbers" }] : /* istanbul ignore next */ []));
        this.lastPageNumber = computed(() => Math.max(Math.ceil(this.totalItems() / this.itemsPerPage()), 1), ...(ngDevMode ? [{ debugName: "lastPageNumber" }] : /* istanbul ignore next */ []));
        this.currentPageIndex = signal(0, ...(ngDevMode ? [{ debugName: "currentPageIndex" }] : /* istanbul ignore next */ []));
        this.pageEvent = output();
        effect(() => {
            this.pageNumbers = Array.from({ length: this.lastPageNumber() }, (_, i) => i + 1);
            if (this.currentPage() > this.pageNumbers.length) {
                this.onPageChanged(this.currentPage() - 1);
            }
            else {
                this.currentPageIndex.set(this.currentPage());
            }
        }, { allowSignalWrites: true });
    }
    onPageChanged(index) {
        this.currentPageIndex.set(index);
        this.pageEvent.emit({ pageNumber: this.currentPageIndex(), itemsPerPage: this.itemsPerPage() });
    }
    onPageSizeChanged(itemsPerPage) {
        this.itemsPerPage.set(itemsPerPage.value);
        this.pageNumbers = Array.from({ length: this.lastPageNumber() }, (_, i) => i + 1);
        this.currentPageIndex.set(this.firstPageNumber);
        this.pageEvent.emit({ pageNumber: this.currentPageIndex(), itemsPerPage: this.itemsPerPage() });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PaginatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: PaginatorComponent, isStandalone: true, selector: "app-paginator", inputs: { currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: true, transformFunction: null }, totalItems: { classPropertyName: "totalItems", publicName: "totalItems", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { pageEvent: "pageEvent" }, ngImport: i0, template: "\r\n<nav class=\"paginator-container\">\r\n  <button class=\"nav-button\" [disabled]=\"currentPageIndex() === firstPageNumber\" (click)=\"onPageChanged(firstPageNumber)\">\r\n    <<\r\n  </button>\r\n      <button class=\"nav-button\" [disabled]=\"currentPageIndex() === firstPageNumber\" (click)=\"onPageChanged(currentPageIndex() -1)\">\r\n        <\r\n      </button>\r\n\r\n      @if(startVisiblePage() > firstPageNumber) {\r\n        <div class=\"more-pages\">...</div>\r\n      }\r\n\r\n      <div class=\"in-row\">\r\n        @for( num of getVisiblePageNumbers(); track num) {\r\n          <button class=\"page-num\"\r\n            [ngClass]=\"{'selected' : num == currentPageIndex()}\"\r\n            [disabled]=\"currentPageIndex() === num\"\r\n            (click)=\"onPageChanged(num)\">{{num}}\r\n          </button>\r\n        }\r\n      </div>\r\n\r\n      @if(endVisiblePage() < lastPageNumber()) {\r\n        <div class=\"more-pages\">...</div>\r\n      }\r\n\r\n       <button class=\"nav-button\" [disabled]=\"currentPageIndex() === lastPageNumber()\" (click)=\"onPageChanged(currentPageIndex() + 1)\">\r\n        >\r\n      </button>\r\n      <button class=\"nav-button\" [disabled]=\"currentPageIndex() === lastPageNumber()\" (click)=\"onPageChanged(lastPageNumber())\">\r\n         >>\r\n       </button>\r\n\r\n  <div class=\"column-center btn-mrg\">\r\n    <div>Items: </div>\r\n  <select (change)=\"onPageSizeChanged($event.target)\">\r\n    @for(option of sizeOptions; track option) {\r\n      <option >\r\n        {{option}}\r\n    </option>\r\n    }\r\n  </select>\r\n  </div>\r\n</nav>\r\n", styles: [".paginator-container{display:flex}.paginator-container .page-num{border:none;color:#00f;margin:5px;background:none;border-radius:50%;cursor:pointer;transition:background-color var(--ui-transition),box-shadow var(--ui-transition)}.paginator-container .page-num:hover{background-color:#0000000d}.paginator-container .more-pages{display:flex;flex-direction:column;justify-content:center}.paginator-container .selected{border-radius:50%;border:1px solid #d5e6f1;background-color:azure;box-shadow:var(--ui-shadow-sm)}.paginator-container .nav-button{border-radius:50%;margin:10px;background-color:azure;background-image:var(--ui-gloss);border:1px solid #d5e6f1;box-shadow:var(--ui-shadow-sm),var(--ui-highlight);cursor:pointer;transition:box-shadow var(--ui-transition),transform var(--ui-transition)}.paginator-container .nav-button:hover:not(:disabled){box-shadow:var(--ui-shadow-md),var(--ui-highlight);transform:translateY(-1px)}.paginator-container .nav-button:active:not(:disabled){box-shadow:var(--ui-shadow-inset);transform:translateY(0)}.paginator-container select{border-radius:20px;padding:5px;border:1px solid var(--ui-border);box-shadow:var(--ui-shadow-sm)}@media(max-width:1200px){.paginator-container{display:flex;justify-content:center}.paginator-container .nav-button{margin:5px}}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PaginatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-paginator', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgClass], template: "\r\n<nav class=\"paginator-container\">\r\n  <button class=\"nav-button\" [disabled]=\"currentPageIndex() === firstPageNumber\" (click)=\"onPageChanged(firstPageNumber)\">\r\n    <<\r\n  </button>\r\n      <button class=\"nav-button\" [disabled]=\"currentPageIndex() === firstPageNumber\" (click)=\"onPageChanged(currentPageIndex() -1)\">\r\n        <\r\n      </button>\r\n\r\n      @if(startVisiblePage() > firstPageNumber) {\r\n        <div class=\"more-pages\">...</div>\r\n      }\r\n\r\n      <div class=\"in-row\">\r\n        @for( num of getVisiblePageNumbers(); track num) {\r\n          <button class=\"page-num\"\r\n            [ngClass]=\"{'selected' : num == currentPageIndex()}\"\r\n            [disabled]=\"currentPageIndex() === num\"\r\n            (click)=\"onPageChanged(num)\">{{num}}\r\n          </button>\r\n        }\r\n      </div>\r\n\r\n      @if(endVisiblePage() < lastPageNumber()) {\r\n        <div class=\"more-pages\">...</div>\r\n      }\r\n\r\n       <button class=\"nav-button\" [disabled]=\"currentPageIndex() === lastPageNumber()\" (click)=\"onPageChanged(currentPageIndex() + 1)\">\r\n        >\r\n      </button>\r\n      <button class=\"nav-button\" [disabled]=\"currentPageIndex() === lastPageNumber()\" (click)=\"onPageChanged(lastPageNumber())\">\r\n         >>\r\n       </button>\r\n\r\n  <div class=\"column-center btn-mrg\">\r\n    <div>Items: </div>\r\n  <select (change)=\"onPageSizeChanged($event.target)\">\r\n    @for(option of sizeOptions; track option) {\r\n      <option >\r\n        {{option}}\r\n    </option>\r\n    }\r\n  </select>\r\n  </div>\r\n</nav>\r\n", styles: [".paginator-container{display:flex}.paginator-container .page-num{border:none;color:#00f;margin:5px;background:none;border-radius:50%;cursor:pointer;transition:background-color var(--ui-transition),box-shadow var(--ui-transition)}.paginator-container .page-num:hover{background-color:#0000000d}.paginator-container .more-pages{display:flex;flex-direction:column;justify-content:center}.paginator-container .selected{border-radius:50%;border:1px solid #d5e6f1;background-color:azure;box-shadow:var(--ui-shadow-sm)}.paginator-container .nav-button{border-radius:50%;margin:10px;background-color:azure;background-image:var(--ui-gloss);border:1px solid #d5e6f1;box-shadow:var(--ui-shadow-sm),var(--ui-highlight);cursor:pointer;transition:box-shadow var(--ui-transition),transform var(--ui-transition)}.paginator-container .nav-button:hover:not(:disabled){box-shadow:var(--ui-shadow-md),var(--ui-highlight);transform:translateY(-1px)}.paginator-container .nav-button:active:not(:disabled){box-shadow:var(--ui-shadow-inset);transform:translateY(0)}.paginator-container select{border-radius:20px;padding:5px;border:1px solid var(--ui-border);box-shadow:var(--ui-shadow-sm)}@media(max-width:1200px){.paginator-container{display:flex;justify-content:center}.paginator-container .nav-button{margin:5px}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: true }] }], totalItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalItems", required: true }] }], pageEvent: [{ type: i0.Output, args: ["pageEvent"] }] } });

class DeleteHiddenColumnsPipe {
    transform(currentGridRow, ...args) {
        const gridRow = { ...currentGridRow };
        for (const key in gridRow) { // gridRows[key] is GridRow
            if (gridRow[key].isHidden) {
                delete gridRow[key];
            }
        }
        return gridRow;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DeleteHiddenColumnsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: DeleteHiddenColumnsPipe, isStandalone: true, name: "deleteHiddenColumns" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DeleteHiddenColumnsPipe, decorators: [{
            type: Pipe,
            args: [{ standalone: true, name: 'deleteHiddenColumns' }]
        }] });

class GridComponent {
    constructor(datePipe) {
        this.datePipe = datePipe;
        this.columns = input.required(...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
        this.dataRows = input.required(...(ngDevMode ? [{ debugName: "dataRows" }] : /* istanbul ignore next */ []));
        this.actions = input.required(...(ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []));
        this.config = input(...(ngDevMode ? [undefined, { debugName: "config" }] : /* istanbul ignore next */ []));
        this.isLoading = input(...(ngDevMode ? [undefined, { debugName: "isLoading" }] : /* istanbul ignore next */ []));
        this.title = input(...(ngDevMode ? [undefined, { debugName: "title" }] : /* istanbul ignore next */ []));
        this.showPaginator = input(true, ...(ngDevMode ? [{ debugName: "showPaginator" }] : /* istanbul ignore next */ []));
        this.changeToListInSmallScreens = input(true, ...(ngDevMode ? [{ debugName: "changeToListInSmallScreens" }] : /* istanbul ignore next */ []));
        this.emptyMessage = input('No results found', ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
        this.scrollable = input(false, ...(ngDevMode ? [{ debugName: "scrollable" }] : /* istanbul ignore next */ []));
        this.legacy = input(false, ...(ngDevMode ? [{ debugName: "legacy" }] : /* istanbul ignore next */ []));
        this.currentPageIndex = signal(0, ...(ngDevMode ? [{ debugName: "currentPageIndex" }] : /* istanbul ignore next */ []));
        this.pageSize = signal(5, ...(ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []));
        this.lastSort = signal({}, ...(ngDevMode ? [{ debugName: "lastSort" }] : /* istanbul ignore next */ []));
        this.filters = signal({}, ...(ngDevMode ? [{ debugName: "filters" }] : /* istanbul ignore next */ []));
        this.filteredData = signal([], ...(ngDevMode ? [{ debugName: "filteredData" }] : /* istanbul ignore next */ []));
        this.slicedData = computed(() => this.showPaginator() ? this.filteredData().slice(this.currentPageIndex() * this.pageSize(), this.pageSize() * (this.currentPageIndex() + 1)) : this.filteredData(), ...(ngDevMode ? [{ debugName: "slicedData" }] : /* istanbul ignore next */ []));
        this.refineColumns = computed(() => this.columns().filter((column) => column.isFilterDisabled == null || !column.isFilterDisabled), ...(ngDevMode ? [{ debugName: "refineColumns" }] : /* istanbul ignore next */ []));
        this.numberOfColumns = computed(() => {
            const numberOfColumns = this.config().numberOfColumns;
            return numberOfColumns ? numberOfColumns : 0;
        }, ...(ngDevMode ? [{ debugName: "numberOfColumns" }] : /* istanbul ignore next */ []));
        this.actionClicked = output();
        this.sortClicked = output();
        this.originalOrder = (a, b) => {
            return 0;
        };
    }
    ngOnInit() {
        this.filteredData.set([...this.dataRows()]);
    }
    isDisabledActionButton(disabledActions, action) {
        return disabledActions?.value && disabledActions.value[action.action]?.disabled;
    }
    onActionClicked(action, data) {
        this.actionClicked.emit({ ...action, data });
    }
    sortColumn(event) {
        if (event && event.column) {
            // resetting other headers
            this.headers.forEach((header) => {
                if (header.sortable() !== event.column) {
                    header.direction.set('');
                }
            });
            // sorting columns
            if (event.direction === '' || event.column === '') {
                this.filteredData.set(this.filterData(this.dataRows()));
            }
            else {
                this.filteredData.set([...this.filteredData()].sort((a, b) => {
                    let res;
                    if (typeof a[event.column].value === 'string') {
                        res = compare(a[event.column].value.toString().toLowerCase(), b[event.column].value.toString().toLowerCase());
                    }
                    else {
                        res = compare(a[event.column].value, b[event.column].value);
                    }
                    return event.direction === 'asc' ? res : -res;
                }));
            }
            this.lastSort.set(event);
        }
    }
    ngOnChanges(changes) {
        const updatedDataRows = changes['dataRows'];
        if (updatedDataRows && !updatedDataRows.firstChange) {
            this.filteredData.set(this.filterData(this.dataRows()));
            this.headers.forEach((header) => {
                header.direction.set('');
            });
        }
    }
    onFilterChange(event, column) {
        this.filters.update((filters) => {
            event.value !== '' ? filters[column.property] = event.value : delete filters[column.property];
            return filters;
        });
        this.currentPageIndex.set(0);
        this.filteredData.set(this.filterData(this.dataRows()));
        this.sortColumn(this.lastSort());
    }
    onPageChanged(pageEvent) {
        this.currentPageIndex.set(pageEvent.pageNumber - 1);
        this.pageSize.set(pageEvent.itemsPerPage);
    }
    filterData(data) {
        if (Object.keys(this.filters()).length > 0) {
            return [...data].filter((row) => {
                for (const key in row) {
                    if (this.filters().hasOwnProperty(key) && this.filters()[key] != '') {
                        if (key === 'date') {
                            if (!this.datePipe.transform(row[key].value, this.config().dateFormat)?.includes(this.filters()[key])) {
                                return false;
                            }
                        }
                        else {
                            if (!row[key].value?.toString().toLowerCase().includes(this.filters()[key].toLowerCase())) {
                                return false;
                            }
                        }
                    }
                }
                return true;
            });
        }
        return [...data];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GridComponent, deps: [{ token: i1$2.DatePipe }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: GridComponent, isStandalone: true, selector: "app-grid", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, dataRows: { classPropertyName: "dataRows", publicName: "dataRows", isSignal: true, isRequired: true, transformFunction: null }, actions: { classPropertyName: "actions", publicName: "actions", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: false, transformFunction: null }, isLoading: { classPropertyName: "isLoading", publicName: "isLoading", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, showPaginator: { classPropertyName: "showPaginator", publicName: "showPaginator", isSignal: true, isRequired: false, transformFunction: null }, changeToListInSmallScreens: { classPropertyName: "changeToListInSmallScreens", publicName: "changeToListInSmallScreens", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, scrollable: { classPropertyName: "scrollable", publicName: "scrollable", isSignal: true, isRequired: false, transformFunction: null }, legacy: { classPropertyName: "legacy", publicName: "legacy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { actionClicked: "actionClicked", sortClicked: "sortClicked" }, viewQueries: [{ propertyName: "headers", predicate: SortableHeaderDirective, descendants: true }], usesOnChanges: true, ngImport: i0, template: "@if (isLoading()) {\n  <app-spinner></app-spinner>\n} @else {\n\n  @if(title()) {\n    <h3 class=\"center\">{{title()}}</h3>\n  }\n\n  <div [ngClass]=\"changeToListInSmallScreens() ? 'list-grid-small-screen-style' : 'grid-small-screen'\" [class.grid-legacy]=\"legacy()\">\n\n\n  <div class=\"refine-board\">\n    @for(column of refineColumns(); track column.alias) {\n      <div class=\"refine-item\">\n        <div appSortableHeader\n        [isSortable]=\"!column.isSortDisabled\"\n        [sortable]=\"column['property']\"\n        (sort)=\"sortColumn($event)\"\n        [ngClass]=\"{'sortable-column-name': !column.isSortDisabled}\" class=\"filter-input\">\n          {{ column.alias }}\n        </div>\n          <div>\n            <input class=\"filter-input\" [(ngModel)]=\"filters()[column.property]\"  type=\"text\" placeholder=\"filter...\" (input)=\"onFilterChange($event.target, column)\">\n          </div>\n      </div>\n    }\n\n  </div>\n\n  <div [class.grid-scroll]=\"scrollable()\">\n  <div class=\"main-page-container\">\n  <div [ngStyle]=\"{ '--number-of-columns': numberOfColumns() }\" class=\"grid-container\" >\n    @for(column of columns(); track column.alias) {\n      <div class=\"grid-item column\">\n        <div appSortableHeader\n             [isSortable]=\"!column.isSortDisabled\"\n             [sortable]=\"column['property']\"\n             (sort)=\"sortColumn($event)\"\n             [ngClass]=\"{'sortable-column-name': !column.isSortDisabled}\">\n          {{ column.alias }}\n        </div>\n        @if(!column.isFilterDisabled) {\n          <div>\n            <input [(ngModel)]=\"filters()[column.property]\" class=\"filter-input\" type=\"text\" placeholder=\"filter...\" (input)=\"onFilterChange($event.target, column)\">\n          </div>\n        }\n        </div>\n    }\n\n\n    @for(data of slicedData(); track data; let i = $index) {\n\n      @for(prop of data | deleteHiddenColumns | keyvalue : originalOrder; track prop.key) {\n        <div [ngClass]=\"{'grid-item': true, 'limited-item': data['isLimited']?.value}\"\n        [matTooltip]=\"data['tooltip']?.value || ''\">\n          <label class=\"prop-label\">{{prop.key}}:</label>\n          @if(prop.key==='link') {\n            <span class=\"prop-value\" [routerLink]=\"[prop.value.value]\">\n              @if(prop.value.icon) {\n                <app-icon [icon]=\"prop.value.icon\"></app-icon>\n              } @else {\n                <app-icon [icon]=\"prop.value.icon\">subdirectory_arrow_right</app-icon>\n              }\n            </span>\n          }\n\n          @if(!prop.value.isHidden && prop.key !=='link') {\n            <span class=\"prop-value\" [appGridRow]=prop [config]=\"config\" [innerHTML]=\"prop.value.value | safeHtml\"></span>\n          }\n        </div>\n      }\n\n      @if(actions() && actions().length > 0) {\n        <div class=\"actions flex\">\n          @for(action of actions(); track action.action) {\n            <button\n            class=\"btn-mrg active-btn\"\n            [ngClass]=\"{'grid-item': legacy(), 'btn-mrg': true, 'active-btn': true, 'disabled-btn': isDisabledActionButton(data['disabledActions'], action)}\"\n            [attr.data-action]=\"action.action\"\n            [disabled]=\"isDisabledActionButton(data['disabledActions'], action)\"\n            [matTooltip]=\"data['disabledActions']?.value[action.action]?.tooltip || ''\"\n            (click)=\"onActionClicked(action, data)\" >\n              {{action.alias}}\n          </button>\n          }\n        </div>\n      }\n\n      <div class=\"grid-row-spacer\"></div>\n    } @empty {\n      <div class=\"grid-empty\">{{ emptyMessage() }}</div>\n    }\n  </div>\n  </div>\n  </div>\n\n@if(showPaginator()) {\n  <div class=\"grid-footer\">\n    <app-paginator\n      [totalItems]=\"filteredData().length\"\n      [currentPage]=\"currentPageIndex() + 1\"\n      (pageEvent)=\"onPageChanged($event)\"\n      aria-label=\"Select page\">\n    </app-paginator>\n  </div>\n}\n\n  </div>\n\n}\n\n\n\n", styles: [".refine-board{display:none}.asc:after{content:\"^\";width:15px;height:15px}.desc:after{content:\"V\";width:15px;height:15px;position:relative;bottom:3px;font-size:10px}.asc:after,.desc:after{color:var(--grid-accent, #156b3a)}input.filter-input{box-sizing:border-box;max-width:100%;margin-top:4px;padding:3px 8px;font-size:13px;font-weight:400;color:var(--ui-text);background-color:var(--ui-surface);border:1px solid var(--ui-border);border-radius:var(--ui-radius-sm);box-shadow:inset 0 1px 2px #00000014;transition:border-color var(--ui-transition),box-shadow var(--ui-transition)}input.filter-input::placeholder{color:var(--ui-text-muted);opacity:.7}input.filter-input:focus{outline:none;border-color:var(--ui-primary);box-shadow:var(--ui-focus-ring)}.main-page-container{min-height:0}.main-page-container .grid-container{display:grid;grid-template-columns:repeat(var(--number-of-columns, 10),1fr);grid-gap:0}.main-page-container .grid-container .column{flex-direction:column;position:sticky;top:0;z-index:1;background-color:var(--grid-surface-raised, #e6ede0);font-family:var(--grid-font-display, inherit);font-size:1rem;font-weight:600;line-height:1.2;box-shadow:var(--grid-light-edge, inset 0 1px 0 rgba(255, 255, 255, .8))}.main-page-container .grid-container .column .sortable-column-name:hover{cursor:pointer}.main-page-container .grid-container .grid-row-spacer{display:none}.main-page-container .grid-container .grid-item{border:0;border-bottom:1px solid var(--grid-border, rgba(19, 36, 26, .12));background-color:var(--grid-surface, #ffffff);color:var(--grid-text, #13241a);font-variant-numeric:tabular-nums;padding:.5rem;align-items:center;justify-content:center;text-align:center;display:flex;flex-direction:column;min-width:0;max-width:100%;word-break:break-all;overflow-wrap:anywhere}.main-page-container .grid-container .grid-item .prop-label{display:none}.main-page-container .grid-container .disabled-btn{text-decoration:line-through}.main-page-container .grid-container .limited-item{opacity:.45}.main-page-container .grid-container .filter-input{margin-top:.25rem;padding:.25rem .5rem;color:var(--grid-text, #13241a);background:var(--grid-surface, #ffffff);border:1px solid var(--grid-border-strong, rgba(19, 36, 26, .28));border-radius:var(--grid-radius, .5rem)}.main-page-container .grid-container .actions{justify-content:center;align-items:center;flex-wrap:wrap;gap:.375rem;padding:.375rem .5rem;border-bottom:1px solid var(--grid-border, rgba(19, 36, 26, .12));background-color:var(--grid-surface, #ffffff)}.main-page-container .grid-container .actions .active-btn:not(.grid-item){--tone: var(--grid-accent, #156b3a);--btn-color: color-mix(in srgb, var(--tone) 10%, var(--grid-surface, #ffffff));--btn-text: var(--tone);--btn-border: color-mix(in srgb, var(--tone) 24%, transparent);--btn-glow: color-mix(in srgb, var(--tone) 45%, transparent);--btn-ring: var(--tone);margin:0;min-height:1.875rem;padding:.3125rem .875rem;font-size:.8125rem;border-radius:999px;background-image:none;text-shadow:none}.main-page-container .grid-container .actions .active-btn:not(.grid-item)[data-action=delete]{--tone: var(--grid-danger, #c62828)}.main-page-container .grid-container .actions .active-btn:not(.grid-item):disabled:hover{background-color:var(--btn-color)}.main-page-container .grid-container .grid-empty{grid-column:1/-1;padding:2rem 1rem;text-align:center;color:var(--ui-text-muted);background-color:var(--ui-surface);border:1px dashed var(--ui-border);border-radius:var(--ui-radius-md)}.grid-legacy .asc:after,.grid-legacy .desc:after{color:red}.grid-legacy .main-page-container{min-height:calc(96vh - 180px)!important}.grid-legacy .main-page-container .grid-container{grid-gap:10px}.grid-legacy .main-page-container .grid-container .column{position:static;z-index:auto;background-color:#cdc9c9!important;background-image:var(--ui-gloss);font-family:inherit;font-size:inherit;line-height:inherit;box-shadow:var(--ui-shadow-md),var(--ui-highlight)}.grid-legacy .main-page-container .grid-container .grid-item{border:1px solid rgba(0,0,0,.45);border-radius:var(--ui-radius-sm);background-color:var(--ui-surface-alt);color:inherit;font-variant-numeric:normal;box-shadow:var(--ui-shadow-sm);transition:box-shadow var(--ui-transition),background-color var(--ui-transition)}.grid-legacy .main-page-container .grid-container .limited-item{opacity:.3}.grid-legacy .main-page-container .grid-container .actions{gap:0;padding:0;border-bottom:0;background-color:transparent}.grid-legacy .main-page-container .grid-container .filter-input{margin-top:4px;padding:3px 8px;color:var(--ui-text);background:var(--ui-surface);border:1px solid var(--ui-border);border-radius:var(--ui-radius-sm)}.grid-legacy .main-page-container .grid-container .active-btn.grid-item:hover:not(:disabled){background-color:var(--ui-surface);box-shadow:var(--ui-shadow-md)}.grid-scroll{max-height:var(--grid-scroll-max-height, 70vh);overflow:auto;background:var(--grid-surface, #ffffff);border:1px solid var(--grid-border, rgba(19, 36, 26, .12));border-radius:.875rem;box-shadow:var(--grid-light-edge, inset 0 1px 0 rgba(255, 255, 255, .8)),0 1px 2px #13241a1f;-webkit-mask-image:linear-gradient(to right,#000 calc(100% - 1.5rem),transparent);mask-image:linear-gradient(to right,#000 calc(100% - 1.5rem),transparent)}.grid-scroll .main-page-container{min-width:22rem}@media(min-width:40rem){.grid-scroll{-webkit-mask-image:none;mask-image:none}}@media(max-width:1200px){.list-grid-small-screen-style .main-page-container{min-height:calc(83vh - 129px)!important;display:flex;justify-content:end;margin-right:2rem}.list-grid-small-screen-style .main-page-container .grid-container{grid-template-columns:repeat(auto-fill,minmax(100%,1fr))!important;width:50%}.list-grid-small-screen-style .main-page-container .grid-container .prop-label{display:flex!important;text-decoration-line:underline;margin-bottom:.3rem}.list-grid-small-screen-style .main-page-container .grid-container .grid-row-spacer{display:block;border:1px solid rgba(0,0,0,.45);margin:15px}.list-grid-small-screen-style .main-page-container .grid-container .prop-value{text-align:center;word-break:break-all;overflow-wrap:anywhere}.list-grid-small-screen-style .main-page-container .grid-container .actions .active-btn{padding:10px}.list-grid-small-screen-style .column{display:none!important}.list-grid-small-screen-style .refine-board{display:flex;flex-wrap:wrap;width:45%;position:fixed}.list-grid-small-screen-style .refine-board .refine-item{flex:65%;margin-top:5px;overflow-wrap:break-word}.list-grid-small-screen-style .refine-board .refine-item .filter-input{width:50%}.grid-small-screen .main-page-container .grid-container{grid-template-columns:repeat(var(--number-of-columns, 10),1fr);grid-gap:0}.grid-small-screen .main-page-container .grid-container .filter-input{width:3rem}}\n"], dependencies: [{ kind: "component", type: SpinnerComponent, selector: "app-spinner", inputs: ["additionalTemplate", "autoLocate"] }, { kind: "directive", type: SortableHeaderDirective, selector: "[appSortableHeader]", inputs: ["sortable", "isSortable"], outputs: ["sort"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon"] }, { kind: "directive", type: GridRowValueDirective, selector: "[appGridRow]", inputs: ["appGridRow", "config"] }, { kind: "component", type: PaginatorComponent, selector: "app-paginator", inputs: ["currentPage", "totalItems"], outputs: ["pageEvent"] }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }, { kind: "pipe", type: DeleteHiddenColumnsPipe, name: "deleteHiddenColumns" }, { kind: "pipe", type: SafeHtmlPipe, name: "safeHtml" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GridComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-grid', standalone: true, imports: [SpinnerComponent, SortableHeaderDirective, NgClass, FormsModule, NgStyle, MatTooltip, RouterLink, IconComponent, GridRowValueDirective, PaginatorComponent, KeyValuePipe, DeleteHiddenColumnsPipe, SafeHtmlPipe], template: "@if (isLoading()) {\n  <app-spinner></app-spinner>\n} @else {\n\n  @if(title()) {\n    <h3 class=\"center\">{{title()}}</h3>\n  }\n\n  <div [ngClass]=\"changeToListInSmallScreens() ? 'list-grid-small-screen-style' : 'grid-small-screen'\" [class.grid-legacy]=\"legacy()\">\n\n\n  <div class=\"refine-board\">\n    @for(column of refineColumns(); track column.alias) {\n      <div class=\"refine-item\">\n        <div appSortableHeader\n        [isSortable]=\"!column.isSortDisabled\"\n        [sortable]=\"column['property']\"\n        (sort)=\"sortColumn($event)\"\n        [ngClass]=\"{'sortable-column-name': !column.isSortDisabled}\" class=\"filter-input\">\n          {{ column.alias }}\n        </div>\n          <div>\n            <input class=\"filter-input\" [(ngModel)]=\"filters()[column.property]\"  type=\"text\" placeholder=\"filter...\" (input)=\"onFilterChange($event.target, column)\">\n          </div>\n      </div>\n    }\n\n  </div>\n\n  <div [class.grid-scroll]=\"scrollable()\">\n  <div class=\"main-page-container\">\n  <div [ngStyle]=\"{ '--number-of-columns': numberOfColumns() }\" class=\"grid-container\" >\n    @for(column of columns(); track column.alias) {\n      <div class=\"grid-item column\">\n        <div appSortableHeader\n             [isSortable]=\"!column.isSortDisabled\"\n             [sortable]=\"column['property']\"\n             (sort)=\"sortColumn($event)\"\n             [ngClass]=\"{'sortable-column-name': !column.isSortDisabled}\">\n          {{ column.alias }}\n        </div>\n        @if(!column.isFilterDisabled) {\n          <div>\n            <input [(ngModel)]=\"filters()[column.property]\" class=\"filter-input\" type=\"text\" placeholder=\"filter...\" (input)=\"onFilterChange($event.target, column)\">\n          </div>\n        }\n        </div>\n    }\n\n\n    @for(data of slicedData(); track data; let i = $index) {\n\n      @for(prop of data | deleteHiddenColumns | keyvalue : originalOrder; track prop.key) {\n        <div [ngClass]=\"{'grid-item': true, 'limited-item': data['isLimited']?.value}\"\n        [matTooltip]=\"data['tooltip']?.value || ''\">\n          <label class=\"prop-label\">{{prop.key}}:</label>\n          @if(prop.key==='link') {\n            <span class=\"prop-value\" [routerLink]=\"[prop.value.value]\">\n              @if(prop.value.icon) {\n                <app-icon [icon]=\"prop.value.icon\"></app-icon>\n              } @else {\n                <app-icon [icon]=\"prop.value.icon\">subdirectory_arrow_right</app-icon>\n              }\n            </span>\n          }\n\n          @if(!prop.value.isHidden && prop.key !=='link') {\n            <span class=\"prop-value\" [appGridRow]=prop [config]=\"config\" [innerHTML]=\"prop.value.value | safeHtml\"></span>\n          }\n        </div>\n      }\n\n      @if(actions() && actions().length > 0) {\n        <div class=\"actions flex\">\n          @for(action of actions(); track action.action) {\n            <button\n            class=\"btn-mrg active-btn\"\n            [ngClass]=\"{'grid-item': legacy(), 'btn-mrg': true, 'active-btn': true, 'disabled-btn': isDisabledActionButton(data['disabledActions'], action)}\"\n            [attr.data-action]=\"action.action\"\n            [disabled]=\"isDisabledActionButton(data['disabledActions'], action)\"\n            [matTooltip]=\"data['disabledActions']?.value[action.action]?.tooltip || ''\"\n            (click)=\"onActionClicked(action, data)\" >\n              {{action.alias}}\n          </button>\n          }\n        </div>\n      }\n\n      <div class=\"grid-row-spacer\"></div>\n    } @empty {\n      <div class=\"grid-empty\">{{ emptyMessage() }}</div>\n    }\n  </div>\n  </div>\n  </div>\n\n@if(showPaginator()) {\n  <div class=\"grid-footer\">\n    <app-paginator\n      [totalItems]=\"filteredData().length\"\n      [currentPage]=\"currentPageIndex() + 1\"\n      (pageEvent)=\"onPageChanged($event)\"\n      aria-label=\"Select page\">\n    </app-paginator>\n  </div>\n}\n\n  </div>\n\n}\n\n\n\n", styles: [".refine-board{display:none}.asc:after{content:\"^\";width:15px;height:15px}.desc:after{content:\"V\";width:15px;height:15px;position:relative;bottom:3px;font-size:10px}.asc:after,.desc:after{color:var(--grid-accent, #156b3a)}input.filter-input{box-sizing:border-box;max-width:100%;margin-top:4px;padding:3px 8px;font-size:13px;font-weight:400;color:var(--ui-text);background-color:var(--ui-surface);border:1px solid var(--ui-border);border-radius:var(--ui-radius-sm);box-shadow:inset 0 1px 2px #00000014;transition:border-color var(--ui-transition),box-shadow var(--ui-transition)}input.filter-input::placeholder{color:var(--ui-text-muted);opacity:.7}input.filter-input:focus{outline:none;border-color:var(--ui-primary);box-shadow:var(--ui-focus-ring)}.main-page-container{min-height:0}.main-page-container .grid-container{display:grid;grid-template-columns:repeat(var(--number-of-columns, 10),1fr);grid-gap:0}.main-page-container .grid-container .column{flex-direction:column;position:sticky;top:0;z-index:1;background-color:var(--grid-surface-raised, #e6ede0);font-family:var(--grid-font-display, inherit);font-size:1rem;font-weight:600;line-height:1.2;box-shadow:var(--grid-light-edge, inset 0 1px 0 rgba(255, 255, 255, .8))}.main-page-container .grid-container .column .sortable-column-name:hover{cursor:pointer}.main-page-container .grid-container .grid-row-spacer{display:none}.main-page-container .grid-container .grid-item{border:0;border-bottom:1px solid var(--grid-border, rgba(19, 36, 26, .12));background-color:var(--grid-surface, #ffffff);color:var(--grid-text, #13241a);font-variant-numeric:tabular-nums;padding:.5rem;align-items:center;justify-content:center;text-align:center;display:flex;flex-direction:column;min-width:0;max-width:100%;word-break:break-all;overflow-wrap:anywhere}.main-page-container .grid-container .grid-item .prop-label{display:none}.main-page-container .grid-container .disabled-btn{text-decoration:line-through}.main-page-container .grid-container .limited-item{opacity:.45}.main-page-container .grid-container .filter-input{margin-top:.25rem;padding:.25rem .5rem;color:var(--grid-text, #13241a);background:var(--grid-surface, #ffffff);border:1px solid var(--grid-border-strong, rgba(19, 36, 26, .28));border-radius:var(--grid-radius, .5rem)}.main-page-container .grid-container .actions{justify-content:center;align-items:center;flex-wrap:wrap;gap:.375rem;padding:.375rem .5rem;border-bottom:1px solid var(--grid-border, rgba(19, 36, 26, .12));background-color:var(--grid-surface, #ffffff)}.main-page-container .grid-container .actions .active-btn:not(.grid-item){--tone: var(--grid-accent, #156b3a);--btn-color: color-mix(in srgb, var(--tone) 10%, var(--grid-surface, #ffffff));--btn-text: var(--tone);--btn-border: color-mix(in srgb, var(--tone) 24%, transparent);--btn-glow: color-mix(in srgb, var(--tone) 45%, transparent);--btn-ring: var(--tone);margin:0;min-height:1.875rem;padding:.3125rem .875rem;font-size:.8125rem;border-radius:999px;background-image:none;text-shadow:none}.main-page-container .grid-container .actions .active-btn:not(.grid-item)[data-action=delete]{--tone: var(--grid-danger, #c62828)}.main-page-container .grid-container .actions .active-btn:not(.grid-item):disabled:hover{background-color:var(--btn-color)}.main-page-container .grid-container .grid-empty{grid-column:1/-1;padding:2rem 1rem;text-align:center;color:var(--ui-text-muted);background-color:var(--ui-surface);border:1px dashed var(--ui-border);border-radius:var(--ui-radius-md)}.grid-legacy .asc:after,.grid-legacy .desc:after{color:red}.grid-legacy .main-page-container{min-height:calc(96vh - 180px)!important}.grid-legacy .main-page-container .grid-container{grid-gap:10px}.grid-legacy .main-page-container .grid-container .column{position:static;z-index:auto;background-color:#cdc9c9!important;background-image:var(--ui-gloss);font-family:inherit;font-size:inherit;line-height:inherit;box-shadow:var(--ui-shadow-md),var(--ui-highlight)}.grid-legacy .main-page-container .grid-container .grid-item{border:1px solid rgba(0,0,0,.45);border-radius:var(--ui-radius-sm);background-color:var(--ui-surface-alt);color:inherit;font-variant-numeric:normal;box-shadow:var(--ui-shadow-sm);transition:box-shadow var(--ui-transition),background-color var(--ui-transition)}.grid-legacy .main-page-container .grid-container .limited-item{opacity:.3}.grid-legacy .main-page-container .grid-container .actions{gap:0;padding:0;border-bottom:0;background-color:transparent}.grid-legacy .main-page-container .grid-container .filter-input{margin-top:4px;padding:3px 8px;color:var(--ui-text);background:var(--ui-surface);border:1px solid var(--ui-border);border-radius:var(--ui-radius-sm)}.grid-legacy .main-page-container .grid-container .active-btn.grid-item:hover:not(:disabled){background-color:var(--ui-surface);box-shadow:var(--ui-shadow-md)}.grid-scroll{max-height:var(--grid-scroll-max-height, 70vh);overflow:auto;background:var(--grid-surface, #ffffff);border:1px solid var(--grid-border, rgba(19, 36, 26, .12));border-radius:.875rem;box-shadow:var(--grid-light-edge, inset 0 1px 0 rgba(255, 255, 255, .8)),0 1px 2px #13241a1f;-webkit-mask-image:linear-gradient(to right,#000 calc(100% - 1.5rem),transparent);mask-image:linear-gradient(to right,#000 calc(100% - 1.5rem),transparent)}.grid-scroll .main-page-container{min-width:22rem}@media(min-width:40rem){.grid-scroll{-webkit-mask-image:none;mask-image:none}}@media(max-width:1200px){.list-grid-small-screen-style .main-page-container{min-height:calc(83vh - 129px)!important;display:flex;justify-content:end;margin-right:2rem}.list-grid-small-screen-style .main-page-container .grid-container{grid-template-columns:repeat(auto-fill,minmax(100%,1fr))!important;width:50%}.list-grid-small-screen-style .main-page-container .grid-container .prop-label{display:flex!important;text-decoration-line:underline;margin-bottom:.3rem}.list-grid-small-screen-style .main-page-container .grid-container .grid-row-spacer{display:block;border:1px solid rgba(0,0,0,.45);margin:15px}.list-grid-small-screen-style .main-page-container .grid-container .prop-value{text-align:center;word-break:break-all;overflow-wrap:anywhere}.list-grid-small-screen-style .main-page-container .grid-container .actions .active-btn{padding:10px}.list-grid-small-screen-style .column{display:none!important}.list-grid-small-screen-style .refine-board{display:flex;flex-wrap:wrap;width:45%;position:fixed}.list-grid-small-screen-style .refine-board .refine-item{flex:65%;margin-top:5px;overflow-wrap:break-word}.list-grid-small-screen-style .refine-board .refine-item .filter-input{width:50%}.grid-small-screen .main-page-container .grid-container{grid-template-columns:repeat(var(--number-of-columns, 10),1fr);grid-gap:0}.grid-small-screen .main-page-container .grid-container .filter-input{width:3rem}}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.DatePipe }], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], dataRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataRows", required: true }] }], actions: [{ type: i0.Input, args: [{ isSignal: true, alias: "actions", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: false }] }], isLoading: [{ type: i0.Input, args: [{ isSignal: true, alias: "isLoading", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], showPaginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPaginator", required: false }] }], changeToListInSmallScreens: [{ type: i0.Input, args: [{ isSignal: true, alias: "changeToListInSmallScreens", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], scrollable: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollable", required: false }] }], legacy: [{ type: i0.Input, args: [{ isSignal: true, alias: "legacy", required: false }] }], actionClicked: [{ type: i0.Output, args: ["actionClicked"] }], sortClicked: [{ type: i0.Output, args: ["sortClicked"] }], headers: [{
                type: ViewChildren,
                args: [SortableHeaderDirective]
            }] } });

class FilterDataRowsPipe {
    constructor(datePipe) {
        this.datePipe = datePipe;
    }
    transform(currentGridRows, filters, config, ...args) {
        if (Object.keys(filters).length > 0) {
            return [...currentGridRows].filter((row) => {
                for (const key in row) {
                    if (filters.hasOwnProperty(key) && filters[key] != '') {
                        if (key === 'date') {
                            if (!this.datePipe.transform(row[key].value, config.dateFormat)?.includes(filters[key])) {
                                return false;
                            }
                        }
                        else {
                            if (!row[key].value?.toString().includes(filters[key])) {
                                return false;
                            }
                        }
                    }
                }
                return true;
            });
        }
        return [...currentGridRows];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FilterDataRowsPipe, deps: [{ token: i1$2.DatePipe }], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: FilterDataRowsPipe, isStandalone: true, name: "filterDataRows", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FilterDataRowsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'filterDataRows',
                    pure: false
                }]
        }], ctorParameters: () => [{ type: i1$2.DatePipe }] });

var NotificationActionType;
(function (NotificationActionType) {
    NotificationActionType["LINK"] = "link";
    NotificationActionType["NAVIGATE"] = "navigateTo";
    NotificationActionType["INFO"] = "info";
})(NotificationActionType || (NotificationActionType = {}));
var NotificationType;
(function (NotificationType) {
    NotificationType["CAR_SWAP"] = "carSwap";
    NotificationType["INFO"] = "info";
})(NotificationType || (NotificationType = {}));
const notificationBasedColor = {
    [NotificationType.CAR_SWAP]: 'aqua',
    [NotificationType.INFO]: 'lawngreen',
};

class NotificationComponent {
    constructor() {
        this.notificationBasedColor = notificationBasedColor;
        this.notification = input.required(...(ngDevMode ? [{ debugName: "notification" }] : /* istanbul ignore next */ []));
        this.notificationId = input.required(...(ngDevMode ? [{ debugName: "notificationId" }] : /* istanbul ignore next */ []));
        this.newNotificationClicked = output();
    }
    onNotificationClicked() {
        this.newNotificationClicked.emit({
            key: this.notificationId(),
            value: this.notification()
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: NotificationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.23", type: NotificationComponent, isStandalone: true, selector: "app-notification", inputs: { notification: { classPropertyName: "notification", publicName: "notification", isSignal: true, isRequired: true, transformFunction: null }, notificationId: { classPropertyName: "notificationId", publicName: "notificationId", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { newNotificationClicked: "newNotificationClicked" }, ngImport: i0, template: "<div (click)=\"onNotificationClicked()\" class=\"notification-wrapper animate\" [ngStyle]=\"{'background-color': notificationBasedColor[notification().type]}\">\r\n<div class=\"notification-title\"> {{notification().title}}</div>\r\n<div> {{notification().description}}</div>\r\n</div>\r\n", styles: [".notification-wrapper{min-height:40px;word-wrap:break-word;width:300px;padding:5px;border-radius:10px;background-image:var(--ui-gloss);box-shadow:var(--ui-shadow-lg),var(--ui-highlight);transition:opacity var(--ui-transition)}.notification-wrapper:hover{opacity:.85;cursor:pointer}.notification-wrapper:active{opacity:1}.notification-wrapper .notification-title{text-decoration:underline}.animate{position:absolute;animation:linear;animation-name:run;animation-duration:2.5s}@keyframes run{0%{right:0}25%{right:25%}50%{right:50%}75%{right:75%}to{right:calc(100% - 320px)}}\n"], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: NotificationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-notification', imports: [NgStyle], template: "<div (click)=\"onNotificationClicked()\" class=\"notification-wrapper animate\" [ngStyle]=\"{'background-color': notificationBasedColor[notification().type]}\">\r\n<div class=\"notification-title\"> {{notification().title}}</div>\r\n<div> {{notification().description}}</div>\r\n</div>\r\n", styles: [".notification-wrapper{min-height:40px;word-wrap:break-word;width:300px;padding:5px;border-radius:10px;background-image:var(--ui-gloss);box-shadow:var(--ui-shadow-lg),var(--ui-highlight);transition:opacity var(--ui-transition)}.notification-wrapper:hover{opacity:.85;cursor:pointer}.notification-wrapper:active{opacity:1}.notification-wrapper .notification-title{text-decoration:underline}.animate{position:absolute;animation:linear;animation-name:run;animation-duration:2.5s}@keyframes run{0%{right:0}25%{right:25%}50%{right:50%}75%{right:75%}to{right:calc(100% - 320px)}}\n"] }]
        }], propDecorators: { notification: [{ type: i0.Input, args: [{ isSignal: true, alias: "notification", required: true }] }], notificationId: [{ type: i0.Input, args: [{ isSignal: true, alias: "notificationId", required: true }] }], newNotificationClicked: [{ type: i0.Output, args: ["newNotificationClicked"] }] } });

class NotificationsBarComponent {
    constructor() {
        this.icon = input.required(...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
        this.items = input.required(...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
        this.notify = input(...(ngDevMode ? [undefined, { debugName: "notify" }] : /* istanbul ignore next */ []));
        this.isItemsEmpty = computed(() => Object.keys(this.items()).length === 0, ...(ngDevMode ? [{ debugName: "isItemsEmpty" }] : /* istanbul ignore next */ []));
        this.notificationClicked = output();
        this.notificationBasedColor = notificationBasedColor;
    }
    onNotificationActionClicked(item) {
        this.notificationClicked.emit(item);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: NotificationsBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: NotificationsBarComponent, isStandalone: true, selector: "app-notifications-bar", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, notify: { classPropertyName: "notify", publicName: "notify", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { notificationClicked: "notificationClicked" }, ngImport: i0, template: "<button [disabled]=\"isItemsEmpty()\"  [ngClass]=\"{'notify': notify()}\" class=\"icon-button active-btn\" [matMenuTriggerFor]=\"menu\">\r\n    <app-icon [icon]=\"icon()\"></app-icon>\r\n</button>\r\n<mat-menu #menu=\"matMenu\">\r\n  @for(item of items() | keyvalue; track item.key) {\r\n    <div [ngStyle]=\"{'background-color': notificationBasedColor[item.value.type]}\">\r\n      @if(item.value.actionType === 'link' && item.value.link) {\r\n        <a class=nav-item [routerLinkActive]=\"['active']\"  mat-menu-item [routerLink]=item.value.link>{{item.value.alias}} </a>\r\n      } @else {\r\n        <button class=nav-item  mat-menu-item (click)=\"onNotificationActionClicked(item)\">{{item.value.alias}} </button>\r\n      }\r\n    </div>\r\n  }\r\n</mat-menu>\r\n", styles: [".notify{animation:shake .5s;animation-iteration-count:infinite}@keyframes shake{0%{transform:translate(1px,1px) rotate(0)}10%{transform:translate(-1px,-2px) rotate(-1deg)}20%{transform:translate(-3px) rotate(1deg)}30%{transform:translate(3px,2px) rotate(0)}40%{transform:translate(1px,-1px) rotate(1deg)}50%{transform:translate(-1px,2px) rotate(-1deg)}60%{transform:translate(-3px,1px) rotate(0)}70%{transform:translate(3px,1px) rotate(-1deg)}80%{transform:translate(-1px,-1px) rotate(1deg)}90%{transform:translate(1px,2px) rotate(0)}to{transform:translate(1px,-2px) rotate(-1deg)}}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["icon"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: NotificationsBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-notifications-bar', imports: [NgClass, MatMenuTrigger, IconComponent, MatMenu, NgStyle, MatMenuItem, RouterLinkActive, RouterLink, KeyValuePipe], template: "<button [disabled]=\"isItemsEmpty()\"  [ngClass]=\"{'notify': notify()}\" class=\"icon-button active-btn\" [matMenuTriggerFor]=\"menu\">\r\n    <app-icon [icon]=\"icon()\"></app-icon>\r\n</button>\r\n<mat-menu #menu=\"matMenu\">\r\n  @for(item of items() | keyvalue; track item.key) {\r\n    <div [ngStyle]=\"{'background-color': notificationBasedColor[item.value.type]}\">\r\n      @if(item.value.actionType === 'link' && item.value.link) {\r\n        <a class=nav-item [routerLinkActive]=\"['active']\"  mat-menu-item [routerLink]=item.value.link>{{item.value.alias}} </a>\r\n      } @else {\r\n        <button class=nav-item  mat-menu-item (click)=\"onNotificationActionClicked(item)\">{{item.value.alias}} </button>\r\n      }\r\n    </div>\r\n  }\r\n</mat-menu>\r\n", styles: [".notify{animation:shake .5s;animation-iteration-count:infinite}@keyframes shake{0%{transform:translate(1px,1px) rotate(0)}10%{transform:translate(-1px,-2px) rotate(-1deg)}20%{transform:translate(-3px) rotate(1deg)}30%{transform:translate(3px,2px) rotate(0)}40%{transform:translate(1px,-1px) rotate(1deg)}50%{transform:translate(-1px,2px) rotate(-1deg)}60%{transform:translate(-3px,1px) rotate(0)}70%{transform:translate(3px,1px) rotate(-1deg)}80%{transform:translate(-1px,-1px) rotate(1deg)}90%{transform:translate(1px,2px) rotate(0)}to{transform:translate(1px,-2px) rotate(-1deg)}}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: true }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], notify: [{ type: i0.Input, args: [{ isSignal: true, alias: "notify", required: false }] }], notificationClicked: [{ type: i0.Output, args: ["notificationClicked"] }] } });

var MenuActionType;
(function (MenuActionType) {
    MenuActionType["LINK"] = "link";
    MenuActionType["MODAL"] = "modal";
    MenuActionType["DOWNLOAD"] = "download";
    MenuActionType["GENERATE_PDF"] = "generatePdf";
})(MenuActionType || (MenuActionType = {}));
var MenuAction;
(function (MenuAction) {
    MenuAction["NAVIGATE"] = "navigate";
    MenuAction["TRANSFER"] = "transfer";
    MenuAction["CANCEL_TRANSFER"] = "cancelTransfer";
    MenuAction["DELETE"] = "delete";
    MenuAction["DOWNLOAD"] = "download";
    MenuAction["GENERATE_PDF"] = "generatePdf";
})(MenuAction || (MenuAction = {}));

class AuthenticationButtonsComponent {
    get userIcon() {
        return userIcon;
    }
    constructor() {
        this.authenticationButtons = input.required(...(ngDevMode ? [{ debugName: "authenticationButtons" }] : /* istanbul ignore next */ []));
        this.isAuthenticated = input.required(...(ngDevMode ? [{ debugName: "isAuthenticated" }] : /* istanbul ignore next */ []));
        this.userMenuButtons = input.required(...(ngDevMode ? [{ debugName: "userMenuButtons" }] : /* istanbul ignore next */ []));
        this.userName = input(...(ngDevMode ? [undefined, { debugName: "userName" }] : /* istanbul ignore next */ []));
        this.menuItemClicked = output();
    }
    performAuthAction(item) {
        this.menuItemClicked.emit(item);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AuthenticationButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: AuthenticationButtonsComponent, isStandalone: true, selector: "app-authentication-buttons", inputs: { authenticationButtons: { classPropertyName: "authenticationButtons", publicName: "authenticationButtons", isSignal: true, isRequired: true, transformFunction: null }, isAuthenticated: { classPropertyName: "isAuthenticated", publicName: "isAuthenticated", isSignal: true, isRequired: true, transformFunction: null }, userMenuButtons: { classPropertyName: "userMenuButtons", publicName: "userMenuButtons", isSignal: true, isRequired: true, transformFunction: null }, userName: { classPropertyName: "userName", publicName: "userName", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { menuItemClicked: "menuItemClicked" }, ngImport: i0, template: "\r\n@if(isAuthenticated()) {\r\n  <div class=\"column-center\">\r\n    <app-menu\r\n              [items]=\"userMenuButtons()\"\r\n              [icon]=\"userIcon\"\r\n              (menuActionClicked)=\"performAuthAction($event) \">\r\n    </app-menu>\r\n    \r\n    @if(isAuthenticated() && userName()) {\r\n      <span class= \"center\"> {{userName()}}</span>\r\n    }\r\n    </div>\r\n} @else {\r\n  @for(button of authenticationButtons(); track button) {\r\n    <button class=\"active-btn link-btn mrg\" [routerLink]=\"button.link\">{{button.alias}}</button>\r\n  }\r\n}\r\n\r\n\r\n\r\n", styles: ["@media only screen and (max-width:700px){.mrg{margin:0}}.user-buttons{display:block;margin:auto}.link-btn{width:62px;border:none}\n"], dependencies: [{ kind: "component", type: MenuComponent, selector: "app-menu", inputs: ["icon", "items"], outputs: ["menuActionClicked"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AuthenticationButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-authentication-buttons', imports: [MenuComponent, RouterLink], template: "\r\n@if(isAuthenticated()) {\r\n  <div class=\"column-center\">\r\n    <app-menu\r\n              [items]=\"userMenuButtons()\"\r\n              [icon]=\"userIcon\"\r\n              (menuActionClicked)=\"performAuthAction($event) \">\r\n    </app-menu>\r\n    \r\n    @if(isAuthenticated() && userName()) {\r\n      <span class= \"center\"> {{userName()}}</span>\r\n    }\r\n    </div>\r\n} @else {\r\n  @for(button of authenticationButtons(); track button) {\r\n    <button class=\"active-btn link-btn mrg\" [routerLink]=\"button.link\">{{button.alias}}</button>\r\n  }\r\n}\r\n\r\n\r\n\r\n", styles: ["@media only screen and (max-width:700px){.mrg{margin:0}}.user-buttons{display:block;margin:auto}.link-btn{width:62px;border:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { authenticationButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "authenticationButtons", required: true }] }], isAuthenticated: [{ type: i0.Input, args: [{ isSignal: true, alias: "isAuthenticated", required: true }] }], userMenuButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "userMenuButtons", required: true }] }], userName: [{ type: i0.Input, args: [{ isSignal: true, alias: "userName", required: false }] }], menuItemClicked: [{ type: i0.Output, args: ["menuItemClicked"] }] } });

var EventStatus;
(function (EventStatus) {
    EventStatus["DONE"] = "done";
    EventStatus["PENDING"] = "pending";
})(EventStatus || (EventStatus = {}));
var EventType;
(function (EventType) {
    EventType["CIRCLE"] = "circle";
    EventType["LINE"] = "line";
})(EventType || (EventType = {}));

class TimelineComponent {
    get eventTypes() {
        return EventType;
    }
    constructor() {
        this.events = input.required(...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: TimelineComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: TimelineComponent, isStandalone: true, selector: "app-timeline", inputs: { events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<div class=\"timeline-container\">\r\n  @for(event of events(); track event) {\r\n    <div class=\"event-container\">\r\n      <div class=\"point-track-container\">\r\n        @if(event.type == eventTypes.LINE) {\r\n          <div class=\"line\"></div>\r\n        } @else {\r\n          <div class=\"circle\"></div>\r\n        }\r\n        <div class=\"track\"></div>\r\n      </div>\r\n       <div class=\"content\">\r\n         <div>{{event.name}}</div>\r\n         <div class=\"event-date\">{{event.date | date :'shortDate'}} </div>\r\n       </div>\r\n     </div>\r\n  }\r\n  </div>\r\n", styles: [".timeline-container{display:flex;flex-wrap:wrap}.timeline-container .event-container:last-child .track{display:none}.timeline-container .event-container{display:flex;flex-direction:column;height:6rem}.timeline-container .event-container .point-track-container{display:flex;flex:1;align-items:center}.timeline-container .event-container .point-track-container .circle{width:1rem;height:1rem;border:2px solid dodgerblue;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff,#dbeeff 70%);box-shadow:0 0 6px #1e90ff8c}.timeline-container .event-container .point-track-container .line{border:2px solid darkslategrey;height:10px;padding:1px}.timeline-container .event-container .point-track-container .track{flex-grow:1;border:1px solid black}.timeline-container .event-container .content{flex:1;padding-right:2rem}.timeline-container .event-container .content .event-date{font-size:16px}@media(max-width:1200px){.timeline-container{flex-direction:column;margin-top:2rem}.timeline-container .event-container{flex-direction:row}.timeline-container .event-container .point-track-container{flex-direction:column}}\n"], dependencies: [{ kind: "pipe", type: DatePipe, name: "date" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: TimelineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-timeline', imports: [DatePipe], template: "<div class=\"timeline-container\">\r\n  @for(event of events(); track event) {\r\n    <div class=\"event-container\">\r\n      <div class=\"point-track-container\">\r\n        @if(event.type == eventTypes.LINE) {\r\n          <div class=\"line\"></div>\r\n        } @else {\r\n          <div class=\"circle\"></div>\r\n        }\r\n        <div class=\"track\"></div>\r\n      </div>\r\n       <div class=\"content\">\r\n         <div>{{event.name}}</div>\r\n         <div class=\"event-date\">{{event.date | date :'shortDate'}} </div>\r\n       </div>\r\n     </div>\r\n  }\r\n  </div>\r\n", styles: [".timeline-container{display:flex;flex-wrap:wrap}.timeline-container .event-container:last-child .track{display:none}.timeline-container .event-container{display:flex;flex-direction:column;height:6rem}.timeline-container .event-container .point-track-container{display:flex;flex:1;align-items:center}.timeline-container .event-container .point-track-container .circle{width:1rem;height:1rem;border:2px solid dodgerblue;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fff,#dbeeff 70%);box-shadow:0 0 6px #1e90ff8c}.timeline-container .event-container .point-track-container .line{border:2px solid darkslategrey;height:10px;padding:1px}.timeline-container .event-container .point-track-container .track{flex-grow:1;border:1px solid black}.timeline-container .event-container .content{flex:1;padding-right:2rem}.timeline-container .event-container .content .event-date{font-size:16px}@media(max-width:1200px){.timeline-container{flex-direction:column;margin-top:2rem}.timeline-container .event-container{flex-direction:row}.timeline-container .event-container .point-track-container{flex-direction:column}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { events: [{ type: i0.Input, args: [{ isSignal: true, alias: "events", required: true }] }] } });

class InnerNavPanelComponent {
    constructor(router, activatedRoute) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.selectedIndex = signal(0, ...(ngDevMode ? [{ debugName: "selectedIndex" }] : /* istanbul ignore next */ []));
        this.horizontal = input(false, ...(ngDevMode ? [{ debugName: "horizontal" }] : /* istanbul ignore next */ []));
        this.items = input.required(...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
        this.itemClicked = output();
        this.currentIndex = signal(this.selectedIndex(), ...(ngDevMode ? [{ debugName: "currentIndex" }] : /* istanbul ignore next */ []));
    }
    onItemClicked(item, index) {
        if (this.currentIndex() !== index) {
            const itemLink = item.link;
            if (itemLink) {
                this.router.navigate([itemLink], { relativeTo: this.activatedRoute });
            }
            else {
                this.itemClicked.emit(item);
            }
            this.currentIndex.set(index);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InnerNavPanelComponent, deps: [{ token: i1$4.Router }, { token: i1$4.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: InnerNavPanelComponent, isStandalone: true, selector: "app-inner-nav-panel", inputs: { horizontal: { classPropertyName: "horizontal", publicName: "horizontal", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { itemClicked: "itemClicked" }, ngImport: i0, template: "\n\n<div [ngClass]=\"{'horizontal': horizontal()}\" class=\"panel\">\n@for(item of items(); track item.alias; let index = $index) {\n    <div [ngClass]=\"{'selected': index === currentIndex()}\" class=\"item\" (click)=\"onItemClicked(item, index)\">{{item.alias}}</div>\n}\n</div>", styles: [".panel{display:flex;flex-direction:column;border:1px solid rgba(0,0,0,.45);border-radius:var(--ui-radius-md);box-shadow:var(--ui-shadow-md);align-items:center;padding:.6rem .2rem;flex-wrap:wrap}.panel .item{margin:.2rem;border:1px solid rgba(0,0,0,.35);border-radius:var(--ui-radius-sm);background-color:#f0f8ff;background-image:var(--ui-gloss);box-shadow:var(--ui-shadow-sm),var(--ui-highlight);padding:1rem;width:50px;text-align:center;text-wrap:wrap;cursor:pointer;transition:background-color .5s ease-in-out,box-shadow var(--ui-transition),transform var(--ui-transition)}.panel .item:hover{box-shadow:var(--ui-shadow-md),var(--ui-highlight);transform:translateY(-1px)}.panel .selected{background-color:#bcd2ed;box-shadow:var(--ui-shadow-inset);transform:none}.panel .selected:hover{box-shadow:var(--ui-shadow-inset);transform:none}.horizontal{flex-direction:row!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: RouterModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InnerNavPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-inner-nav-panel', imports: [CommonModule, RouterModule], template: "\n\n<div [ngClass]=\"{'horizontal': horizontal()}\" class=\"panel\">\n@for(item of items(); track item.alias; let index = $index) {\n    <div [ngClass]=\"{'selected': index === currentIndex()}\" class=\"item\" (click)=\"onItemClicked(item, index)\">{{item.alias}}</div>\n}\n</div>", styles: [".panel{display:flex;flex-direction:column;border:1px solid rgba(0,0,0,.45);border-radius:var(--ui-radius-md);box-shadow:var(--ui-shadow-md);align-items:center;padding:.6rem .2rem;flex-wrap:wrap}.panel .item{margin:.2rem;border:1px solid rgba(0,0,0,.35);border-radius:var(--ui-radius-sm);background-color:#f0f8ff;background-image:var(--ui-gloss);box-shadow:var(--ui-shadow-sm),var(--ui-highlight);padding:1rem;width:50px;text-align:center;text-wrap:wrap;cursor:pointer;transition:background-color .5s ease-in-out,box-shadow var(--ui-transition),transform var(--ui-transition)}.panel .item:hover{box-shadow:var(--ui-shadow-md),var(--ui-highlight);transform:translateY(-1px)}.panel .selected{background-color:#bcd2ed;box-shadow:var(--ui-shadow-inset);transform:none}.panel .selected:hover{box-shadow:var(--ui-shadow-inset);transform:none}.horizontal{flex-direction:row!important}\n"] }]
        }], ctorParameters: () => [{ type: i1$4.Router }, { type: i1$4.ActivatedRoute }], propDecorators: { horizontal: [{ type: i0.Input, args: [{ isSignal: true, alias: "horizontal", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], itemClicked: [{ type: i0.Output, args: ["itemClicked"] }] } });

class FlipCardOnClickDirective {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.isFlipped = false;
        this.cardClicked = output(); // OutputEmitterRef<string>
        this.initCardStyle();
    }
    initCardStyle() {
        const element = this.el.nativeElement;
        this.renderer.setStyle(element, 'transition', 'transform 0.6s');
    }
    onClick() {
        const rotation = this.isFlipped ? 'rotateY(0deg)' : 'rotateY(180deg)';
        this.renderer.setStyle(this.el.nativeElement, 'transform', rotation);
        this.isFlipped = !this.isFlipped;
        this.cardClicked.emit(this.isFlipped);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FlipCardOnClickDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: FlipCardOnClickDirective, isStandalone: true, selector: "[appFlipCardOnClick]", outputs: { cardClicked: "cardClicked" }, host: { listeners: { "click": "onClick()" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FlipCardOnClickDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[appFlipCardOnClick]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { cardClicked: [{ type: i0.Output, args: ["cardClicked"] }], onClick: [{
                type: HostListener,
                args: ['click']
            }] } });

class FlipCardComponent {
    constructor() {
        this.isFlipped = signal(false, ...(ngDevMode ? [{ debugName: "isFlipped" }] : /* istanbul ignore next */ []));
        this.width = input(...(ngDevMode ? [undefined, { debugName: "width" }] : /* istanbul ignore next */ []));
        this.height = input(...(ngDevMode ? [undefined, { debugName: "height" }] : /* istanbul ignore next */ []));
        this.frontStyle = input(...(ngDevMode ? [undefined, { debugName: "frontStyle" }] : /* istanbul ignore next */ []));
        this.backStyle = input(...(ngDevMode ? [undefined, { debugName: "backStyle" }] : /* istanbul ignore next */ []));
        this.frontContent = input(...(ngDevMode ? [undefined, { debugName: "frontContent" }] : /* istanbul ignore next */ []));
        this.backContent = input(...(ngDevMode ? [undefined, { debugName: "backContent" }] : /* istanbul ignore next */ []));
        this.isFrontDataObject = computed(() => typeof this.frontContent() === 'object', ...(ngDevMode ? [{ debugName: "isFrontDataObject" }] : /* istanbul ignore next */ []));
        this.isBackDataObject = computed(() => typeof this.backContent() === 'object', ...(ngDevMode ? [{ debugName: "isBackDataObject" }] : /* istanbul ignore next */ []));
    }
    flipCard(isFlipped) {
        this.isFlipped.set(isFlipped);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FlipCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: FlipCardComponent, isStandalone: true, selector: "lib-flip-card", inputs: { width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, frontStyle: { classPropertyName: "frontStyle", publicName: "frontStyle", isSignal: true, isRequired: false, transformFunction: null }, backStyle: { classPropertyName: "backStyle", publicName: "backStyle", isSignal: true, isRequired: false, transformFunction: null }, frontContent: { classPropertyName: "frontContent", publicName: "frontContent", isSignal: true, isRequired: false, transformFunction: null }, backContent: { classPropertyName: "backContent", publicName: "backContent", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"card-container\" [ngStyle]=\"{width: width(), height: height()}\"\r\n  appFlipCardOnClick\r\n  (cardClicked) = flipCard($event)>\r\n\r\n    <!-- Front Side -->\r\n    @if(!isFlipped()) {\r\n        <div [ngStyle]=\"frontStyle()\" class=\"cardContent front-color\">\r\n\r\n            @if(isFrontDataObject()) {\r\n                <div class=\"object-content\">\r\n                    @for(row of frontContent() | keyvalue; track row.key) {\r\n                        <div class=\"in-row row-content\">\r\n                            <span class=\"key\">{{row.key}}</span>\r\n                            <span>{{row.value}}</span>\r\n                        </div>\r\n                    }\r\n                </div>\r\n            } @else{\r\n                <div class=\"string-content\">\r\n                    {{frontContent()}}\r\n                </div>\r\n            }\r\n        </div>\r\n    }\r\n\r\n    <!-- Back Side -->\r\n    @if(isFlipped()) {\r\n        <div [ngStyle]=\"backStyle()\" class=\"cardContent back-color\">\r\n            @if(isBackDataObject()) {\r\n                <div class=\"object-content flipped\">\r\n                    @for(row of backContent() | keyvalue; track row.key) {\r\n                        <div class=\"in-row row-content\">\r\n                            <span class=\"key\">{{row.key}}</span>\r\n                            <span>{{row.value}}</span>\r\n                        </div>\r\n                    }\r\n                </div>\r\n            } @else{\r\n                <div class=\"flipped string-content\">\r\n                    {{backContent()}}\r\n                </div>\r\n            }\r\n        </div>\r\n    }\r\n\r\n</div>\r\n", styles: [".card-container{width:100%;min-height:300px;perspective:1000px}.card-container .cardContent{width:100%;min-height:300px;backface-visibility:hidden;display:flex;justify-content:center;align-items:center;border-radius:15%;box-shadow:var(--ui-shadow-md),var(--ui-highlight);padding:10px;box-sizing:border-box;overflow:hidden}.card-container .string-content{display:flex;justify-content:center;align-items:center;width:100%;text-align:center;word-wrap:break-word;overflow-wrap:break-word;word-break:break-word}.card-container .object-content{width:100%}.card-container .object-content .row-content{display:flex;justify-content:space-between;flex-wrap:wrap;gap:4px;font-size:20px;margin:10px}.card-container .object-content .row-content .key{font-weight:700}.card-container .object-content .row-content span{word-wrap:break-word;overflow-wrap:break-word;word-break:break-word;min-width:0}.card-container .flipped{transform:rotateY(180deg)}\n"], dependencies: [{ kind: "directive", type: FlipCardOnClickDirective, selector: "[appFlipCardOnClick]", outputs: ["cardClicked"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FlipCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-flip-card', imports: [FlipCardOnClickDirective, NgStyle, KeyValuePipe], template: "<div class=\"card-container\" [ngStyle]=\"{width: width(), height: height()}\"\r\n  appFlipCardOnClick\r\n  (cardClicked) = flipCard($event)>\r\n\r\n    <!-- Front Side -->\r\n    @if(!isFlipped()) {\r\n        <div [ngStyle]=\"frontStyle()\" class=\"cardContent front-color\">\r\n\r\n            @if(isFrontDataObject()) {\r\n                <div class=\"object-content\">\r\n                    @for(row of frontContent() | keyvalue; track row.key) {\r\n                        <div class=\"in-row row-content\">\r\n                            <span class=\"key\">{{row.key}}</span>\r\n                            <span>{{row.value}}</span>\r\n                        </div>\r\n                    }\r\n                </div>\r\n            } @else{\r\n                <div class=\"string-content\">\r\n                    {{frontContent()}}\r\n                </div>\r\n            }\r\n        </div>\r\n    }\r\n\r\n    <!-- Back Side -->\r\n    @if(isFlipped()) {\r\n        <div [ngStyle]=\"backStyle()\" class=\"cardContent back-color\">\r\n            @if(isBackDataObject()) {\r\n                <div class=\"object-content flipped\">\r\n                    @for(row of backContent() | keyvalue; track row.key) {\r\n                        <div class=\"in-row row-content\">\r\n                            <span class=\"key\">{{row.key}}</span>\r\n                            <span>{{row.value}}</span>\r\n                        </div>\r\n                    }\r\n                </div>\r\n            } @else{\r\n                <div class=\"flipped string-content\">\r\n                    {{backContent()}}\r\n                </div>\r\n            }\r\n        </div>\r\n    }\r\n\r\n</div>\r\n", styles: [".card-container{width:100%;min-height:300px;perspective:1000px}.card-container .cardContent{width:100%;min-height:300px;backface-visibility:hidden;display:flex;justify-content:center;align-items:center;border-radius:15%;box-shadow:var(--ui-shadow-md),var(--ui-highlight);padding:10px;box-sizing:border-box;overflow:hidden}.card-container .string-content{display:flex;justify-content:center;align-items:center;width:100%;text-align:center;word-wrap:break-word;overflow-wrap:break-word;word-break:break-word}.card-container .object-content{width:100%}.card-container .object-content .row-content{display:flex;justify-content:space-between;flex-wrap:wrap;gap:4px;font-size:20px;margin:10px}.card-container .object-content .row-content .key{font-weight:700}.card-container .object-content .row-content span{word-wrap:break-word;overflow-wrap:break-word;word-break:break-word;min-width:0}.card-container .flipped{transform:rotateY(180deg)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], frontStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "frontStyle", required: false }] }], backStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "backStyle", required: false }] }], frontContent: [{ type: i0.Input, args: [{ isSignal: true, alias: "frontContent", required: false }] }], backContent: [{ type: i0.Input, args: [{ isSignal: true, alias: "backContent", required: false }] }] } });

class ChatComponent {
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.customStyle = input(...(ngDevMode ? [undefined, { debugName: "customStyle" }] : /* istanbul ignore next */ []));
        this.messages = input(...(ngDevMode ? [undefined, { debugName: "messages" }] : /* istanbul ignore next */ []));
        this.notify = input(false, ...(ngDevMode ? [{ debugName: "notify" }] : /* istanbul ignore next */ []));
        this.showChat = signal(false, ...(ngDevMode ? [{ debugName: "showChat" }] : /* istanbul ignore next */ []));
        this.newMessage = '';
        this.normalScreenStyle = computed(() => {
            const normalScreenStyle = this.customStyle()?.normalScreen;
            if (!normalScreenStyle || Object.keys(normalScreenStyle || {}).length === 0) {
                return { 'top': '50px', right: '50px' };
            }
            return normalScreenStyle;
        }, ...(ngDevMode ? [{ debugName: "normalScreenStyle" }] : /* istanbul ignore next */ []));
        this.smallScreenStyle = computed(() => {
            const smallScreenStyle = this.customStyle()?.smallScreen;
            if (!smallScreenStyle || Object.keys(smallScreenStyle || {}).length === 0) {
                return { 'top': '20px', right: '10px' };
            }
            return smallScreenStyle;
        }, ...(ngDevMode ? [{ debugName: "smallScreenStyle" }] : /* istanbul ignore next */ []));
        this.messageSent = output();
        effect(() => {
            const msgs = this.messages();
            if (msgs && msgs.length > 0) {
                this.scrollBottom();
            }
        });
    }
    openChat() {
        if (this.showChat()) {
            this.showChat.set(false);
            return;
        }
        this.showChat.set(true);
        this.scrollBottom();
    }
    scrollBottom() {
        window.setTimeout(() => {
            if (this.showChat()) {
                this.scrollAnchor.nativeElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }
    sendMessage() {
        this.messageSent.emit(this.newMessage);
        this.newMessage = '';
    }
    handleClicks(event) {
        if (!this.elementRef.nativeElement.contains(event.target)) { // clicked outside
            this.showChat.set(false);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ChatComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: ChatComponent, isStandalone: true, selector: "lib-chat", inputs: { customStyle: { classPropertyName: "customStyle", publicName: "customStyle", isSignal: true, isRequired: false, transformFunction: null }, messages: { classPropertyName: "messages", publicName: "messages", isSignal: true, isRequired: false, transformFunction: null }, notify: { classPropertyName: "notify", publicName: "notify", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { messageSent: "messageSent" }, host: { listeners: { "document:click": "handleClicks($event)" } }, viewQueries: [{ propertyName: "scrollAnchor", first: true, predicate: ["scrollAnchor"], descendants: true }], ngImport: i0, template: "@if(showChat()) {\r\n  <div class=\"chat-box\">\r\n    <div class=\"messages\">\r\n      @for(message of messages(); track message) {\r\n        <div>\r\n          <strong>{{ message.senderName }}</strong>: {{ message.text }}\r\n        </div>\r\n      }\r\n      <div #scrollAnchor></div>\r\n\r\n    </div>\r\n\r\n    <form (ngSubmit)=\"sendMessage()\">\r\n      <input [(ngModel)]=\"newMessage\" name=\"msg\" placeholder=\"Type a message...\" required />\r\n      <button type=\"submit\">Send</button>\r\n    </form>\r\n\r\n  </div>\r\n}\r\n\r\n<button [class.notify]=\"notify()\" (click)=\"openChat()\" class=\"icon-button chat-btn normal-screen\" [ngStyle]=\"normalScreenStyle()\">\r\n  <img alt=\"chat\" width=\"30\" height=\"30\" src=\"assets/icons/chat.svg\">\r\n</button>\r\n\r\n\r\n<button [class.notify]=\"notify()\" (click)=\"openChat()\" class=\"icon-button chat-btn small-screen\" [ngStyle]=\"smallScreenStyle()\">\r\n  <img alt=\"chat\" width=\"30\" height=\"30\" src=\"assets/icons/chat.svg\">\r\n</button>\r\n", styles: [".chat-box{position:absolute;bottom:50px;width:300px;display:flex;flex-direction:column;height:300px;border:1px solid var(--ui-border);border-radius:var(--ui-radius-lg);box-shadow:var(--ui-shadow-lg);overflow:hidden;font-family:Arial,sans-serif;background-color:#f9f9f9;right:20px}.chat-box .messages{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:12px}.chat-box form{display:flex;border-top:1px solid #ccc;padding:10px;background:#fff}.chat-box form input{flex:1;padding:10px;font-size:14px;border:1px solid #ccc;border-radius:var(--ui-radius-md);margin-right:8px;outline:none;box-shadow:inset 0 1px 2px #0000000f;transition:border-color var(--ui-transition),box-shadow var(--ui-transition)}.chat-box form input:focus{border-color:var(--ui-primary);box-shadow:var(--ui-focus-ring)}.chat-box form button{background-color:var(--ui-primary);background-image:var(--ui-gloss);color:#fff;border:none;border-radius:var(--ui-radius-md);padding:10px 16px;font-size:14px;cursor:pointer;box-shadow:var(--ui-shadow-sm),var(--ui-highlight);transition:background-color var(--ui-transition),box-shadow var(--ui-transition)}.chat-box form button:hover{background-color:var(--ui-primary-dark);box-shadow:var(--ui-shadow-md),var(--ui-highlight)}.chat-box form button:active{box-shadow:var(--ui-shadow-inset)}.icon-button{border:none;cursor:pointer}.chat-btn{position:absolute}.notify{animation:shake .5s;animation-iteration-count:infinite}@keyframes shake{0%{transform:translate(1px,1px) rotate(0)}10%{transform:translate(-1px,-2px) rotate(-1deg)}20%{transform:translate(-3px) rotate(1deg)}30%{transform:translate(3px,2px) rotate(0)}40%{transform:translate(1px,-1px) rotate(1deg)}50%{transform:translate(-1px,2px) rotate(-1deg)}60%{transform:translate(-3px,1px) rotate(0)}70%{transform:translate(3px,1px) rotate(-1deg)}80%{transform:translate(-1px,-1px) rotate(1deg)}90%{transform:translate(1px,2px) rotate(0)}to{transform:translate(1px,-2px) rotate(-1deg)}}@media(max-width:700px){.normal-screen{display:none}}@media(min-width:700px){.small-screen{display:none}}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ChatComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-chat', imports: [FormsModule, CommonModule], template: "@if(showChat()) {\r\n  <div class=\"chat-box\">\r\n    <div class=\"messages\">\r\n      @for(message of messages(); track message) {\r\n        <div>\r\n          <strong>{{ message.senderName }}</strong>: {{ message.text }}\r\n        </div>\r\n      }\r\n      <div #scrollAnchor></div>\r\n\r\n    </div>\r\n\r\n    <form (ngSubmit)=\"sendMessage()\">\r\n      <input [(ngModel)]=\"newMessage\" name=\"msg\" placeholder=\"Type a message...\" required />\r\n      <button type=\"submit\">Send</button>\r\n    </form>\r\n\r\n  </div>\r\n}\r\n\r\n<button [class.notify]=\"notify()\" (click)=\"openChat()\" class=\"icon-button chat-btn normal-screen\" [ngStyle]=\"normalScreenStyle()\">\r\n  <img alt=\"chat\" width=\"30\" height=\"30\" src=\"assets/icons/chat.svg\">\r\n</button>\r\n\r\n\r\n<button [class.notify]=\"notify()\" (click)=\"openChat()\" class=\"icon-button chat-btn small-screen\" [ngStyle]=\"smallScreenStyle()\">\r\n  <img alt=\"chat\" width=\"30\" height=\"30\" src=\"assets/icons/chat.svg\">\r\n</button>\r\n", styles: [".chat-box{position:absolute;bottom:50px;width:300px;display:flex;flex-direction:column;height:300px;border:1px solid var(--ui-border);border-radius:var(--ui-radius-lg);box-shadow:var(--ui-shadow-lg);overflow:hidden;font-family:Arial,sans-serif;background-color:#f9f9f9;right:20px}.chat-box .messages{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:12px}.chat-box form{display:flex;border-top:1px solid #ccc;padding:10px;background:#fff}.chat-box form input{flex:1;padding:10px;font-size:14px;border:1px solid #ccc;border-radius:var(--ui-radius-md);margin-right:8px;outline:none;box-shadow:inset 0 1px 2px #0000000f;transition:border-color var(--ui-transition),box-shadow var(--ui-transition)}.chat-box form input:focus{border-color:var(--ui-primary);box-shadow:var(--ui-focus-ring)}.chat-box form button{background-color:var(--ui-primary);background-image:var(--ui-gloss);color:#fff;border:none;border-radius:var(--ui-radius-md);padding:10px 16px;font-size:14px;cursor:pointer;box-shadow:var(--ui-shadow-sm),var(--ui-highlight);transition:background-color var(--ui-transition),box-shadow var(--ui-transition)}.chat-box form button:hover{background-color:var(--ui-primary-dark);box-shadow:var(--ui-shadow-md),var(--ui-highlight)}.chat-box form button:active{box-shadow:var(--ui-shadow-inset)}.icon-button{border:none;cursor:pointer}.chat-btn{position:absolute}.notify{animation:shake .5s;animation-iteration-count:infinite}@keyframes shake{0%{transform:translate(1px,1px) rotate(0)}10%{transform:translate(-1px,-2px) rotate(-1deg)}20%{transform:translate(-3px) rotate(1deg)}30%{transform:translate(3px,2px) rotate(0)}40%{transform:translate(1px,-1px) rotate(1deg)}50%{transform:translate(-1px,2px) rotate(-1deg)}60%{transform:translate(-3px,1px) rotate(0)}70%{transform:translate(3px,1px) rotate(-1deg)}80%{transform:translate(-1px,-1px) rotate(1deg)}90%{transform:translate(1px,2px) rotate(0)}to{transform:translate(1px,-2px) rotate(-1deg)}}@media(max-width:700px){.normal-screen{display:none}}@media(min-width:700px){.small-screen{display:none}}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { customStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "customStyle", required: false }] }], messages: [{ type: i0.Input, args: [{ isSignal: true, alias: "messages", required: false }] }], notify: [{ type: i0.Input, args: [{ isSignal: true, alias: "notify", required: false }] }], scrollAnchor: [{
                type: ViewChild,
                args: ['scrollAnchor']
            }], messageSent: [{ type: i0.Output, args: ["messageSent"] }], handleClicks: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class BreadcrumbsComponent {
    constructor() {
        this.breadcrumbs = input([], ...(ngDevMode ? [{ debugName: "breadcrumbs" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: BreadcrumbsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: BreadcrumbsComponent, isStandalone: true, selector: "lib-breadcrumbs", inputs: { breadcrumbs: { classPropertyName: "breadcrumbs", publicName: "breadcrumbs", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if(breadcrumbs().length > 1) {\r\n  <nav class=\"breadcrumb\">\r\n    @for(crumb of breadcrumbs(); let last=$last; track crumb.url) {\r\n      @if(!last) {\r\n        <a [routerLink]=\"crumb.url\">{{ crumb.label }}</a>\r\n        <span class=\"separator\">/</span>\r\n      }\r\n      @if(last) {\r\n        <span>{{ crumb.label }}</span>\r\n      }\r\n    }\r\n  </nav>\r\n}\r\n", styles: ["nav{font-size:14px;margin-bottom:1rem}nav a{text-decoration:none;color:var(--ui-link)}nav a:hover{text-decoration:underline}nav .separator{margin:0 .5rem;color:#999}\n"], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: BreadcrumbsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-breadcrumbs', imports: [RouterLink], template: "@if(breadcrumbs().length > 1) {\r\n  <nav class=\"breadcrumb\">\r\n    @for(crumb of breadcrumbs(); let last=$last; track crumb.url) {\r\n      @if(!last) {\r\n        <a [routerLink]=\"crumb.url\">{{ crumb.label }}</a>\r\n        <span class=\"separator\">/</span>\r\n      }\r\n      @if(last) {\r\n        <span>{{ crumb.label }}</span>\r\n      }\r\n    }\r\n  </nav>\r\n}\r\n", styles: ["nav{font-size:14px;margin-bottom:1rem}nav a{text-decoration:none;color:var(--ui-link)}nav a:hover{text-decoration:underline}nav .separator{margin:0 .5rem;color:#999}\n"] }]
        }], propDecorators: { breadcrumbs: [{ type: i0.Input, args: [{ isSignal: true, alias: "breadcrumbs", required: false }] }] } });

/*
 * Public API Surface of ui
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AttachmentsModalComponent, AttachmentsService, AuthenticationButtonsComponent, AutoCompleteComponent, BreadcrumbsComponent, ChatComponent, ConfirmModalComponent, DeleteHiddenColumnsPipe, DialogResponse, DynamicComponentsTypes, EventStatus, EventType, FilterDataRowsPipe, FlipCardComponent, GenericFormComponent, GridActionType, GridComponent, GridRowValueDirective, HighlightSearchResultPipe, IconComponent, InnerNavPanelComponent, LandingPageComponent, LandingPageService, MediaPreviewModalComponent, MenuAction, MenuActionType, MenuComponent, ModalsService, NavigationBarComponent, NavigationItemType, NotificationActionType, NotificationComponent, NotificationType, NotificationsBarComponent, PaginatorComponent, PopupType, PopupsComponent, PopupsService, SearchModalComponent, SortableHeaderDirective, SpinnerComponent, TimelineComponent, ValidatorsService, compare, defaultModalProperties, genericValidators, inputModal, menuIcon, modalHeights, notificationBasedColor, subInputType, uploadFileDefaultValues, userIcon };
//# sourceMappingURL=ui.mjs.map
