# Ui

This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 16.0.0.

## Code scaffolding

Run `ng generate component component-name --project ui` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module --project ui`.
> Note: Don't forget to add `--project ui` or else it will be added to the default project in your `angular.json` file. 

## Build

Run `ng build ui` to build the project. The build artifacts will be stored in the `dist/` directory.

## Publishing

After building your library with `ng build ui`, go to the dist folder `cd dist/ui` and run `npm publish`.

## Running unit tests

Run `ng test ui` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.

## Theming

`styles.scss` defines CSS variables (`--ui-primary`, `--ui-submit`, `--ui-alert`, `--ui-shadow-md`, `--ui-radius-md`, ...) on `:root`, and all components use them.
Import `styles.scss` in your app, then override any variable to re-theme:

```css
:root {
  --ui-primary: #6200ee;
  --ui-radius-sm: 6px;
}
```

### Grid

`app-grid` reads its colors and header font from `--grid-*` variables. Every one has a fallback, so the grid looks right
with no setup. Set them on `app-grid` or `:root` to re-theme it, including a dark theme:

| Variable | Default | Used for |
|---|---|---|
| `--grid-surface` | `#ffffff` | cell background |
| `--grid-surface-raised` | `#e6ede0` | header background |
| `--grid-border` | `rgb(19 36 26 / 0.12)` | row lines |
| `--grid-border-strong` | `rgb(19 36 26 / 0.28)` | filter input border |
| `--grid-text` | `#13241a` | cell text |
| `--grid-accent` | `#156b3a` | sort arrows, action buttons |
| `--grid-danger` | `#c62828` | delete action button |
| `--grid-light-edge` | `inset 0 1px 0 rgb(255 255 255 / 0.8)` | header highlight |
| `--grid-font-display` | `inherit` | header font |
| `--grid-radius` | `0.5rem` | filter input corners |
| `--grid-scroll-max-height` | `70vh` | height of the scroll box when `[scrollable]="true"` |

The lib does not load fonts; load one in your app and set `--grid-font-display` to use it.

```css
app-grid.dark {
  --grid-surface: #15251c;
  --grid-surface-raised: #1d3226;
  --grid-border: rgb(238 243 234 / 0.12);
  --grid-border-strong: rgb(238 243 234 / 0.24);
  --grid-text: #eef3ea;
  --grid-accent: #3ddc84;
  --grid-danger: #ff6b6b;
  --grid-light-edge: inset 0 1px 0 rgb(255 233 168 / 0.16);
  --grid-font-display: 'Barlow Condensed', system-ui, sans-serif;
}
```

Set `[scrollable]="true"` to put the grid in its own scroll box: wide grids scroll sideways on phones and the header
stays sticky inside the box. Without it the header sticks to the page, and stops sticking if an ancestor sets `overflow`.

Set `[legacy]="true"` to get the old look back (bordered grey boxes, 10px gap, `min-height`). It is temporary and
will be removed once the row look is settled.

## Changelog

### 0.1.0

- `app-grid` has a new default look: rows separated by lines instead of bordered grey boxes, a sticky header, and
  colors from `--grid-*` variables. The container no longer has a `min-height` and cells have no gap or box, so
  layouts that relied on the old look may need adjusting.
- `app-grid` action buttons no longer carry the `grid-item` class.
- Buttons (`active-btn`, `action-btn`, `submit-btn`, `alert-btn`) have a new look: rounder, softer depth, hover lift,
  pressed scale, focus outline. The color variants now work without `active-btn`.
- New `app-grid` inputs `scrollable` and `legacy` (old look, temporary).

## Storybook

Browse and check every component one by one:

```bash
npm run storybook        # dev server on http://localhost:6006
npm run build-storybook  # static build in dist/storybook/ui
```

Stories live in `projects/ui/src/stories`, config in `projects/ui/.storybook`.
